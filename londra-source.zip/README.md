# Londra Transfers — Integration 05 / Frontend 04.1 Development Source

**STATUS: UPDATED DEVELOPMENT SOURCE, WITH PHPMailer TRANSPORT AND TABLE-BASED EMAILS; NOT A VERIFIED OR ONE-CLICK HOSTINGER DEPLOYMENT.**

This project contains the current Laravel application source, Filament administration definitions, MySQL migration and initial-content scripts, public presentation templates, three-language content, approved responsive WebP photographs, logo/artwork variants and verification evidence. A matching standalone HTML preview is packaged alongside the source in the complete review ZIP.

## Website experience

Frontend 04 replaces the earlier conventional landing-page compositions with a more restrained editorial presentation: chauffeur-focused opening, coordinated split photography, finely spaced sections, image-led services, four-vehicle showcase, comparison and gallery views, a side-opening enquiry interface and integrated English/Italian/Spanish navigation. View `docs/FRONTEND_04_REVIEW.md` and `docs/RELEASE_AUDIT_04_1.md`.

The approved colour tokens are `#000000`, `#0B0B0B`, `#FFFFFF`, `#F7F7F5`, `#BDA177`, `#F1ECD9`. Dark mode is default, with optional light mode. The confirmed fleet capacities are 3 / 3 / 7 / 8 guests for E-Class / S-Class / V-Class / Vito. The 13 unchanged PNG photograph masters are held in the separately supplied final-image archive. The build source includes all 39 approved responsive WebP versions.

## Public preview

Open `PREVIEW/index.html` from the extracted complete bundle. The preview contains 32 published-content page identities in each of three languages (96 HTML pages), plus an English entry page. It requires no PHP, network connection, MySQL, login or Node server. The navigation, themes, service selector, vehicle tabs and comparison, gallery and enquiry drawer can be reviewed. Submitting enquiries is intentionally disabled; the preview does not store customer data or send emails.

## Application source

The Laravel source includes `app/`, `bootstrap/`, `config/`, `database/`, `lang/`, `public/`, `resources/`, `routes/`, `tests/`, `docs/` and `reports/`. MySQL is the intended live data source; JSON content under `database/content/` is initial seed material rather than a parallel editable database.

The declared application dependencies are Laravel 13.x, Filament 5.x, Livewire 4.x, PHPMailer 7.1.x and PHP `~8.5.4`. These are intended version ranges, **not installed or tested package versions**. No vendor directory, Composer lock file, NPM lock file, compiled public/admin Vite assets, production installer, configured application key or SMTP credentials are included. External package repositories could not be accessed from this workspace, and PHP 8.5 plus MySQL are unavailable here.

## Safety and scope

The single administrator's CMS is English-only; public pages are English, Italian and Spanish. The public website supports enquiry capture as source code only. No booking engine, pricing engine, quotation engine, payment gateway, driver dispatch or customer login was added.

Five policy pages intentionally remain unpublished because the business's final operating/legal rules are missing. Form submission, notification sending and indexing default to disabled. Country geolocation has a fallback implementation but no real lookup data source. The live website is not modified by this package.

**Do not extract the Laravel source directory into `public_html`.** A secure Hostinger release requires a private application directory, a compatible PHP 8.5 build, resolved packages and compiled assets, MySQL migration/integration tests, a no-SSH installer, completed policy content, administrator setup and SMTP verification. See `docs/HOSTINGER_DEPLOYMENT_PENDING.md` for the proposed account layout and verification needs.

## Repeatable review commands

- `php tools/render-preview.php /path/to/output` regenerates the standalone preview using the source templates.
- `php tests/domain-checks.php` runs dependency-free domain checks.
- `LONDRA_PREVIEW_DIR=/path/to/output LONDRA_BASELINE_ZIP=/path/to/previous-baseline.zip python tests/frontend-04/audit.py` checks static content, links and asset provenance.
- `PYTHONPATH=tests/frontend-03 LONDRA_PREVIEW_DIR=/path/to/output python tests/frontend-04/browser_matrix.py 0 16` runs the first responsive preview batch if Playwright and Chromium are available. Other page batches use the same command with the corresponding indices.
- `sha256sum -c SHA256SUMS.txt` verifies the complete source tree against its packaged hashes from the source root.

These checks do not test a deployed Laravel application or guarantee visual consistency across every browser, resolution or assistive technology.

## Integration 05 note

The mail service now uses PHPMailer through the existing queued delivery workflow. Read `docs/INTEGRATION_05_STATUS.md` and `docs/ZOHO_EMAIL_DELIVERABILITY.md`. Temporary secrets have not been added to this package.

## GitHub single-file source distribution
The 13 original PNG photographs are not in this compact GitHub-upload variant. Their hashes and dimensions are retained in reports/archived-photo-masters.json. All 39 WebP variants and approved transparent branding assets remain. CMS photo paths now resolve to an included high-resolution WebP. The workflow still requires independent verification and is not an installed Hostinger application.
