<?php
use App\Http\Controllers\{DiscoveryController,InquiryController,LocaleController,MediaController,PreviewController,PublicPageController};
use Illuminate\Support\Facades\Route;
Route::get('/', [LocaleController::class, 'entry']);
Route::get('/preview', [PreviewController::class, 'show']);
Route::post('/preview', [PreviewController::class, 'login'])->middleware('throttle:preview-login');
Route::get('/language/{locale}/{key}', [LocaleController::class, 'choose'])->whereIn('locale', ['en','it','es'])->where('key','[a-z0-9-]+')->name('language.choose');
Route::get('/media/{path}', [MediaController::class, 'show'])->where('path','[a-f0-9-]{36}\.(png|jpg|jpeg|webp)')->name('media');
Route::get('/robots.txt', [DiscoveryController::class, 'robots']);
Route::get('/sitemap.xml', [DiscoveryController::class, 'sitemap']);
Route::get('/llms.txt', [DiscoveryController::class, 'llms']);
Route::get('/llms-full.txt', [DiscoveryController::class, 'llmsFull']);
Route::prefix('{locale}')->where(['locale'=>'en|it|es'])->middleware('locale.public')->group(function (): void {
    Route::post('/inquiries', [InquiryController::class, 'store'])->middleware('throttle:inquiries')->name('inquiries.store');
    Route::get('/llms.txt', [DiscoveryController::class, 'llms']);
    Route::get('/{slug?}', [PublicPageController::class, 'show'])->where('slug', '[a-z0-9]+(?:[-/][a-z0-9]+)*')->name('public.page');
});
