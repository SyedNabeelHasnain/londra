# Londra Transfers — Bespoke Frontend 03

8 October 2026 · public-design implementation and review release

**This is a new public frontend, not a production deployment package.** It supersedes Frontend 02 for visual review. The existing Laravel, MySQL, Filament, SMTP and hosting integration status is not changed by this UI work. Neither the static preview nor the source archive should replace the live website.

## 1. The design change

Frontend 02 still divided the opening into a typographic introduction followed by a photograph, with a predominantly list-and-panel treatment below. Frontend 03 changes that composition, not only the colour or spacing.

The homepage now opens directly into an approved, full-viewport photograph. A transparent, centred brand masthead sits above the journey/excellence headline, with a quiet inset frame and a compact enquiry/service strip. Three scene controls let the visitor select a city/fleet view, an aviation view or a private-transfer view. They do not advance automatically.

The remainder is a sequence of different compositions: a short centred introduction; three deliberately offset photographic service panels; an interactive vehicle showcase; a champagne editorial section; a full-width London destination photograph; an aviation/airport index; and a split closing invitation. The design is intentionally not an unbroken series of identical cards.

The reference prototype has not been used as a layout constraint. The exact six-colour palette, approved graphic artwork, photographs and business scope remain the constraints.

### Visible differences

| Area | Frontend 03 implementation |
|---|---|
| Opening | Full-screen approved photograph, restrained overlay, large roman/italic headline, inset frame and service/enquiry dock. |
| Typography | Bodoni/Didot-family display stack with a restrained system sans-serif interface, narrower reading widths and deliberately different heading scales. |
| Navigation | Full-screen native dialog, editorial image changes on desktop link focus/hover, large destination links, and a separate mobile composition. |
| Services | Offset photographic panels on home; numbered, alternating image-and-copy chapters on the services overview. |
| Fleet | Four keyboard-operable categories, large selected model, approved capacity, full-width image, previous/next controls and photograph viewing. |
| Fleet comparison | A separate comparison dialog showing the four categories and their approved capacities. It does not calculate price, availability or suitability from invented specifications. |
| Enquiries | Right-side champagne drawer on desktop and a full-width internally scrollable mobile panel. Only the established three booking-enquiry fields are required. |
| Inner pages | Full-width photographic headers for service/vehicle/destination details; reading columns and contextual enquiry links; dedicated collection, FAQ and contact layouts. |
| Themes | Default black/onyx; optional porcelain/white theme with dark text. Photographic sections and footer intentionally retain dark treatments where appropriate. |
| Detail | Coordinated hairlines, tab numbering, inset image frames, arrow movement, focus states and short entrance transitions; no scroll hijacking or forced introduction. |

These are design choices for review, not a claim that luxury can be certified by an automated test or that the design has been evaluated by a UHNWI user panel.

## 2. Research basis

The following primary references were reviewed for the design and interaction approach. No competitor copy, code, photograph or artwork was imported into the website. The external websites were researched through their available web content; this was not a comprehensive live-browser visual audit of them.

| Reference | Principle considered | Application here |
|---|---|---|
| Aman official website — https://www.aman.com/ | Place and experience can lead the presentation rather than a dense feature inventory. | Large approved photography, shorter introductory copy and a separate route to the details. |
| The Lanesborough, Oetker Hotels — https://www.oetkerhotels.com/hotels/the-lanesborough/ | A location-led hospitality presentation can combine a strong arrival image with a clear service path. | Photographic opening and a direct personal-enquiry action, without a simulated reservation engine. |
| Rolls-Royce Bespoke — https://www.rolls-roycemotorcars.com/en_US/bespoke/discover.html | The vehicle and the individual experience merit deliberate presentation. | Selected-vehicle showcase, focused image viewing and a comparison limited to established facts. |
| W3C modal-dialog pattern — https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/ | A modal needs a name, contained focus, a clear exit and focus restoration. | Labelled native navigation, enquiry, comparison and photograph dialogs; keyboard and closing checks. |
| W3C tabs pattern — https://www.w3.org/WAI/ARIA/apg/patterns/tabs/ | Selected state, associated panels and predictable keyboard controls. | Fleet tabs with roving focus, arrows, Home/End and one active panel. |
| MDN reduced-motion documentation — https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion | Motion preferences must be respected. | No automatic scene changes; reduced-motion mode disables CSS movement and reveal animations. |

Design-plugin availability was checked. The relevant discovered integrations were not connected; no plugin-based design, paid service, independent human review or separate professional agent was used or is claimed. The implementation and checks were performed in the working environment.

## 3. Scope and content preservation

There are 32 substantive public page identities in English, Italian and Spanish: 96 connected HTML pages plus an English index entry. The five policy identities remain unpublished because their business rules are still unresolved. They have not been filled with generic or invented terms.

The underlying page-body seed records, service scope, contact information and vehicle data remain unchanged from Frontend 02. Additional presentation/navigation strings are stored in all three UI dictionaries. Spanish presentation copy uses a consistent formal mode of address.

The passenger values remain E-Class 3, S-Class 3, V-Class 7 and Vito 8. No luggage allowance, price, waiting period, cancellation condition, operating hour, review score or new commercial partnership has been added.

The English and Italian final V2 flyers remain the business-source documents. This revision does not independently verify the flyers' licensing or experience claims and does not resolve the previously recorded differences in special-service wording.

The single English-only administrator, MySQL storage, enquiry CRM, no-SSH hosting approach and eventual notification workflow remain unchanged. No booking engine, quotation engine, payment integration, dispatch system, customer account or multi-role system has been introduced.

## 4. Images, typography and performance boundaries

All 13 approved original PNG photographs match the previous source archive byte-for-byte. The existing 39 WebP display derivatives and 17 transparent artwork PNGs are retained. No additional photograph was generated and no approved logo or wing geometry was redesigned in this revision.

The imagery is cropped by layout, not destructively edited. The full-width opening, destination and fleet image slots now declare full-viewport responsive image sizes instead of inheriting a half-width image hint. Original source resolution still limits the detail available on very large displays.

The original generated-image limitations remain: approval does not establish photographic authenticity or repair pre-existing model, signage or architectural details. The previously disclosed Ritz crop remains an upscaled source. This frontend work does not convert it into a native higher-resolution photograph.

The serif stack is `Bodoni 72`, `Bodoni MT`, `Didot`, `GFS Didot`, `Times New Roman`, then serif. The sans-serif stack uses `Helvetica Neue`, Arial, then sans-serif. No font binary is included and no external font request is made. The reference environment selected an available local font; Times New Roman/Arial fallback geometry was separately checked. Font shape, text metrics and antialiasing can vary by operating system, so universal pixel-identical rendering is not claimed.

The public preview has no external animation library, font service, advertising pixel, analytics call or AI API. The public JavaScript is scoped to the actual interactions. This does not establish a production Core Web Vitals, Lighthouse or hosting-performance result; none has been invented.

## 5. Functional review details

The opening scene controls are explicit visitor choices. The fleet tabs also never auto-advance. All four fleet panels remain available without JavaScript, and the enquiry and menu anchors retain their full-page fallbacks.

Fleet comparison includes the four category images, descriptions and approved passenger capacities. The photograph viewer follows the currently selected vehicle and preserves its alternative text. Both are labelled dialogs rather than visual overlays without keyboard handling.

The enquiry drawer retains service context when opened from a service page. In the delivered preview, all submission buttons remain disabled and a visible message explains that the preview does not send or store enquiries. Separate tests temporarily enable client-side handling with injected responses; those are not live submissions.

Mobile navigation is not a scaled-down desktop image panel. It removes the decorative image, keeps large links and exposes the language choices. The bottom enquiry/call rail appears after the opening content and is removed from view while a modal is open.

## 6. Executed validation

| Check | Observed result | Boundary |
|---|---:|---|
| PHP syntax | 116 files passed | PHP 8.4.24 linting, not PHP 8.5 or Laravel runtime execution. |
| Static source, HTML, links and asset audit | 1,356 assertions passed | Repeated page/markup checks, not 1,356 independent features. Includes unchanged photo hashes and locked base palette. |
| Page/width/theme matrix | 576 states passed | 96 pages at 360, 768 and 1440 CSS pixels, in dark and light. |
| Focused UI assertions | 510 passed | Three locales at 320, 390, 1024 and 1920 pixels, plus context, FAQ, no-JavaScript and reduced-motion checks. |
| Mocked client form-state assertions | 24 passed | Injected fetch responses only: invalid input, field errors, retry, unexpected HTML and acknowledgement display. |
| Representative solid-surface contrast pairs | 70 passed | Text and input boundary checks; excludes photographic/gradient backgrounds and is not a full WCAG audit. |
| Fallback-font/reflow/normal-motion assertions | 49 passed | Representative Times New Roman/Arial cases, a 720-pixel reflow case and settled normal-motion paths. Not physical-device or browser-zoom automation. |
| Existing dependency-free domain checks | 888 passed | Rerun separately; still not framework or database execution. |

The matrix found no horizontal document overflow, missing loaded images or uncaught JavaScript errors in its tested states. Focused checks include modal containment, focus return, scene selection, correct fleet capacities, comparison, photograph selection, language links and disabled preview submission.

During refinement, a long enquiry heading overflowing on a narrow viewport was corrected, the mobile first-screen enquiry position and small supporting labels were adjusted, Spanish mode of address was made consistent, and full-width responsive-image sizing was corrected. The relevant checks were rerun. One test assertion was corrected to recognise a hidden mobile rail via `display:none`, rather than expecting a visibility property change; no application defect was concealed by that correction.

### Browser method and limitations

Chromium 144.0.7559.96 rendered the exact generated HTML with the local CSS, JavaScript and images inlined through Playwright `set_content`. Each matrix page uses a fresh context. This method works around the environment's navigation restriction; it is not an HTTP request to a running Laravel application.

The inlining harness loads the selected image bytes directly and does not test real network prioritisation, lazy loading, responsive-srcset selection, origin storage persistence or production CSP. The declared responsive-image sizing is checked separately in markup.

Screenshots are real browser renderings. Full-page and viewport captures are identified by filename. The fleet-section image is a crop of the corresponding full-page browser screenshot to avoid fixed-header artefacts from off-viewport element capture; it is not a generated or repainted design image.

Representative desktop/mobile dark/light pages and dialog states were additionally inspected visually. Not every possible viewport, OS font, assistive technology or device has been reviewed. Safari, Firefox, physical iOS/Android devices, full accessibility conformance and production speed are not certified.

Laravel/Filament dependency resolution, MySQL migration/storage, SMTP delivery, host cron, installer safety, final policies and PHP 8.5 integration remain outside this frontend milestone. No deployment, genuine enquiry or business email was performed.

## 7. Package instructions

`Londra_Bespoke_Frontend_03_Preview.zip`: extract the entire archive on your computer and open `index.html`. It is a static, connected design preview with local assets, not an installation package. Check the scene choices, fleet selection, comparison, photograph viewer, menu, themes, three languages and enquiry drawer.

`Londra_Bespoke_Frontend_03_Source.zip`: the updated complete development source with public templates, styles, script, UI translations, existing backend source, approved masters and current reports. It does not contain a fabricated vendor tree, dependency locks or production Vite/Filament build. Do not extract it into the live `public_html` as an installable site.

Current executable checks are in `tests/frontend-03/`; current evidence is in `reports/frontend-03/`. Earlier milestone and Frontend 02 reports are historical evidence. `BUILD_STATUS.json` records the current stage.

This release is for reviewing the new design and interactions. No guaranteed absence of defects, guaranteed rankings, independent audit or final user acceptance is claimed.
