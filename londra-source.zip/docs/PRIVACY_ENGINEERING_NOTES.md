# Privacy engineering notes — not a customer privacy policy

These notes describe current source behaviour. They do not establish a legal basis or replace approved customer information.

Enquiries include name, email, telephone, type, language, source page/service, timestamps, internal status and follow-up; contact forms add subject/message. Identity/contact text and note bodies use Laravel encrypted casts. An HMAC of normalised email supports exact lookup. The encryption key must be protected separately from database backups.

The source does not add raw IP addresses or full user-agent strings to the enquiry table. However, Laravel database sessions include IP address and user-agent columns, and web-host access logs may retain request information. Therefore no claim is made that the website stores no IP addresses at all.

The rate limiter uses keyed IP hashes in the configured cache. Session lifetime is an engineering default of 120 minutes; a manual language choice is stored for 30 days; theme preference uses localStorage. These preference/security behaviours must be described appropriately in approved cookie/privacy information.

No external geolocation API, analytics, advertising pixel, visitor recording, fingerprinting or AI data service is active. Internal charts count enquiries; they do not represent unique visitors, ranking data or tracked conversions from an analytics provider.

Customer emails confirm receipt only. Administrator emails link to the protected enquiry instead of including all submitted personal information. SMTP acceptance is not inbox delivery. CSV exports contain personal data and must be stored securely; the source includes formula-injection protection.

Content histories contain public page copy, not customer notes. Failed notification exceptions are redacted to a delivery identifier/class. Framework sessions, normal logs, database backups, queued/failed jobs and exported files still need a documented retention/backup policy.

No enquiry deletion period is invented. Automatic enquiry deletion is disabled pending the owner's period and criteria. There are no real enquiry records or credentials in this package.
