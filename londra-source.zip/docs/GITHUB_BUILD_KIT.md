# Londra Transfers — GitHub Actions prebuild preparation

This source derives from Integration 05, preserving the approved Frontend 04.1 and three-language content. The uploaded source ZIP is not a production release. It contains no customer database, SMTP passwords or installed dependencies.

The GitHub workflow reconstructs this archive from parts, validates digests, resolves Laravel/Filament/PHPMailer and JavaScript dependencies, attempts tests against a disposable MySQL database, and packages separated private/public hosting folders only after all checks pass.

GitHub Actions results have **not** been run or verified in the author's current environment. If any step fails, do not deploy the artifact and share the first failed step and non-sensitive error lines for correction.

The resulting private/public split archive is a **build candidate only** until the Hostinger directory layout, PHP extensions, MySQL access, initial administrator setup, cron, SMTP, backup/restore, pending policies and live acceptance have been verified. There is no completed first-time web installer in this source.

Current `.env.example` intentionally contains no actual database account, SMTP login or passwords. Configure them privately at installation and never commit a real `.env` file.
