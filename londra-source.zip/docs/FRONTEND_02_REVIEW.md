# Londra Transfers — Bespoke Frontend 02

8 October 2026 · public UI/UX implementation and design-review release

**This replaces the rejected Milestone 01 public design. It is not a production deployment package.** The application backend, MySQL/Filament definitions, enquiry rules and hosting constraints remain at their previous integration status. The separate preview is executable static HTML and cannot submit an enquiry.

## 1. What has actually changed

The previous arrangement has been replaced rather than recoloured. The public layer now has a centred emblem/wordmark masthead, an editorial typographic opening, a different use of the approved imagery, a navigation overlay, a service index, a selectable fleet presentation and purpose-specific inner-page layouts. The home page no longer starts with the prototype's left-copy/right-picture composition or relies on repeated small card grids.

The public source is divided into shared header, home, page-family, component and footer partials. Its CSS and interaction script have been rewritten. The same PHP view bodies generate the review HTML and remain connected to the Laravel presentation model. A template-root location was added to that model so includes do not depend on Blade's compiled-cache directory.

The approved six colours remain the only base colours in the public theme: #000000, #0B0B0B, #FFFFFF, #F7F7F5, #BDA177 and #F1ECD9. Transparent rules and photographic colours are not additional brand colours. The light theme uses dark typography rather than placing low-contrast gold body text on white. The approved transparent emblem is used without redrawing its wings.

## 2. Research and the resulting design decisions

These are references for design thinking, not evidence that our design has been tested with their clients. No competitor copy, photographs, graphics or code have been copied into the website.

| Primary reference | Observation used | Londra implementation decision |
|---|---|---|
| Aman official website | Destination and experience-led navigation with short editorial introductions. | Give the journey, destination and contact route distinct places in the hierarchy, rather than filling the screen with feature badges. |
| Rosewood London official website | A place-led hospitality presentation, with imagery and individual experiences doing much of the explanation. | Larger images, considered reading widths and different compositions for services and destinations. |
| Rolls-Royce Bespoke official website | Craftsmanship narratives and a direct route to a specialist. | A deliberate vehicle presentation and a simple personal-enquiry path; no invented pricing or availability machinery. |
| W3C ARIA Authoring Practices: tabs and modal dialogs | Defined keyboard behaviour, labelled panels, contained modal focus and return to the triggering control. | Keyboard-operable fleet/service selectors, native dialogs, Escape dismissal and focus restoration. |
| W3C target-size guidance and MDN reduced-motion documentation | Controls must remain usable beyond a mouse; motion preferences need respect. | Responsive touch controls, visible focus, reduced-motion support and no scroll hijacking. |
| Tailwind Preflight documentation | Its resets can alter element margins and native controls. | Explicit component geometry and a public CSS entry that omits Preflight, avoiding an unreviewed reset overriding the standalone preview styles. |

Reference index, reviewed for this redesign:

- Aman: https://www.aman.com/
- Rosewood London: https://www.rosewoodhotels.com/en/london
- Rolls-Royce Bespoke: https://www.rolls-roycemotorcars.com/en_US/bespoke/discover.html
- W3C tabs: https://www.w3.org/WAI/ARIA/apg/patterns/tabs/
- W3C dialogs: https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/
- W3C target size: https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html
- MDN reduced motion: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion
- Tailwind Preflight: https://tailwindcss.com/docs/preflight
- Core Web Vitals definitions: https://web.dev/articles/vitals

The reference research used official web content. It was not a live, cross-browser visual audit of those external sites. Design/prototyping plugins were searched, but the relevant results were unconnected. No external design agent, paid service or independent human review was used or is claimed.

## 3. The implemented visitor experience

### Opening and navigation

The masthead centres the approved emblem and a coordinated Londra Transfers wordmark, with direct contact, language selection, theme selection and an enquiry action. A secondary navigation gives common destinations immediate access. The expanded menu is a separate, labelled native dialog: image-led on desktop and deliberately simpler on narrow screens. Without JavaScript, the menu link leads to the site directory.

The home opening uses the approved journey/excellence wording, a clear enquiry action and an approved photograph. The journey rail below it contains real service links; it is not a disguised booking engine.

### Service and fleet selection

The service selector changes the accompanying image and description. Its selected state is not communicated by colour alone. Arrow keys, Home and End operate the controls, and each panel is associated with its tab. The fleet selector follows the same interaction model, with a large photograph and a separate vehicle-information panel. Capacities remain E-Class 3, S-Class 3, V-Class 7 and Vito 8. No luggage figure has been added.

These selectors do not auto-advance. Their content remains in the HTML and visible without JavaScript. Links continue to the appropriate full pages.

### Inner pages

There are 32 substantive page identities in each of three languages. Service, airport, tour and vehicle details use an editorial image-and-heading composition, followed by structured reading content. The services overview uses alternating image/text spreads. The fleet overview uses the interactive showcase. Airports have a dedicated image/index arrangement, FAQs have native accordions, and contact/enquiry pages use their own form layouts.

Five policy identities remain unpublished, as in the previous milestone. Existing page-body seed content and business facts have not been replaced with new operational promises. New navigational and presentation text is localised in English, Italian and Spanish.

### Enquiry interaction

The enquiry dialog is a native modal with a branded image panel on desktop. On mobile it uses the screen width and permits internal scrolling. Escape and the explicit close control dismiss it; keyboard focus returns to the opener. Required fields remain name, email and telephone. Service context can be carried into the form. Contact enquiries retain their additional fields. The preview visibly disables submission.

The client script handles validation feedback, unexpected responses, temporary failure and a returned enquiry reference. The delivery tests for those states use mocked responses only; they do not prove storage, authentication, email or server-side validation.

### Motion and themes

Motion is limited to short dialog entrances, selected-panel transitions, restrained image movement and directional link affordances. There is no sound, autoplay carousel, forced introduction, scroll interception or external animation dependency. Reduced-motion preferences disable those effects. The mobile contact bar appears after the introductory content and is hidden when a modal is active.

## 4. Typography and image handling

Typography is specified using a Palatino-family serif and a system sans-serif stack. No font binary is included or distributed, and the preview does not make external font requests. The rendered reference screenshots use the fonts available in the test environment. Text metrics and antialiasing can vary between operating systems; universal pixel-identical typography is not claimed.

All 13 original approved photograph masters are byte-for-byte unchanged. The existing 39 WebP display derivatives and transparent artwork remain available. Responsive image crops are deliberate layout choices; they do not alter the source files. This redesign does not verify or repair the earlier generated photographs' architectural, signage or model details, and does not turn the previously disclosed Ritz crop into native higher-resolution photography.

## 5. Executed checks

| Check | Result | Boundary |
|---|---:|---|
| PHP source syntax | 116 files passed | PHP 8.4.24 syntax only, not PHP 8.5/Laravel execution. |
| Static HTML/source/asset checks | 1,355 assertions passed | Repeated per-page checks; not 1,355 distinct product features. |
| Page / viewport / theme matrix | 576 states passed | 96 pages × 360/768/1440 pixels × dark/light. |
| Focused interaction assertions | 297 passed | Twelve locale/viewport sequences at 320/390/1024/1920 plus supplemental checks. Some checks repeat across locales. |
| Client form-state assertions | 24 passed | Injected fetch stubs only; no server request or customer data. |
| Representative contrast checks | 40 passed | Known solid-surface text and input boundaries; not a full WCAG audit. |
| Existing dependency-free domain suite | 888 assertions passed | Separate from framework/database tests. |
| Approved photo preservation | 13 of 13 matched | Compared with the Milestone 01 source archive's approved masters. |
| Backend business code | Unchanged | The sole changed app class is the presentation view model's partial-path setup. |

The matrix found no horizontal document overflow, missing loaded images or uncaught JavaScript errors in its tested states. Focused tests covered themes, menu and enquiry modal containment/closing, focus return, service and fleet keyboard selection, capacities, language-menu behaviour, FAQ expansion, reduced motion and non-JavaScript fallbacks.

During refinement, the public Tailwind reset interaction was addressed, native-dialog positioning was made explicit, the mobile navigation label/spacing was adjusted, and input underlines were strengthened. A colour transition that could briefly reduce service-label contrast during theme changes was removed. Final tests were rerun after those refinements.

### What the browser tests actually exercised

Chromium 144.0.7559.96 rendered the exact generated HTML, stylesheet, JavaScript and local images. This environment blocks normal browser navigation; Playwright therefore used `set_content`, inlining those local assets. This is real browser rendering, not an image-generation mockup, but it is not navigation against a Laravel HTTP server.

The matrix tests use explicit CSS viewports. The supplied 390-pixel mobile reference screenshot also enables Chromium's touch/mobile emulation. Neither establishes Safari/iOS or Firefox behaviour on physical devices. A number of representative desktop/mobile screenshots were additionally inspected visually; not every possible screen/font/zoom combination has been reviewed.

These checks do not verify HTTP routing, compiled production CSS, CSP headers, cookies across navigations, dynamic CMS publication, MySQL writes, live Filament, SMTP, geolocation, Hostinger installation, production performance or a complete assistive-technology audit. No Core Web Vitals or Lighthouse performance score is invented.

## 6. Files and review instructions

`Londra_Bespoke_Frontend_02_Preview.zip`: extract the complete archive into a folder on your computer, then open `index.html`. Use the menu, language switch, theme button, service/fleet selectors and enquiry action. All 96 language pages are connected with local links. Do not upload this as the live website.

`Londra_Bespoke_Frontend_02_Source.zip`: updated complete application source, approved image masters, templates, styles, scripts and test evidence. It has no fabricated vendor directory, Composer/NPM lock or production build. The backend remains unintegrated and the deployment installer is still pending; this is not the no-SSH installation ZIP.

Reports for this redesign are in `reports/frontend-02/`. Earlier reports in the report root are historical evidence from Milestone 01, except where explicitly rerun. Current frontend checks and their source are in `tests/frontend-02/`. The build status file identifies the current stage.

## 7. Scope preserved

The hosting, PHP, MySQL and Filament decisions are not changed. No payment, quotation, reservation, dispatch, customer-account or multi-role feature has been introduced. The exact palette, public languages, fleet capacities and approved contact details are retained. No third-party tracking, remote font or AI service is added to the visitor experience.

This release is ready for a new design review. It is not represented as guaranteed defect-free, universally pixel-identical, independently audited or ready to replace the live website.
