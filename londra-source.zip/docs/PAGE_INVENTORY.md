# Page and language inventory

| Page identity | Type | English | Italian | Spanish | State |
|---|---|---|---|---|---|
| home | home | /en | /it | /es | Development content available |
| airport-transfers | service | /en/services/airport-transfers | /it/servizi/trasferimenti-aeroportuali | /es/servicios/traslados-aeroportuarios | Development content available |
| private-transfers | service | /en/services/private-transfers | /it/servizi/trasferimenti-privati | /es/servicios/traslados-privados | Development content available |
| private-tours | service | /en/services/private-tours | /it/servizi/tour-privati | /es/servicios/tours-privados | Development content available |
| chauffeur-service | service | /en/services/chauffeur-service | /it/servizi/servizio-con-autista | /es/servicios/servicio-de-chofer | Development content available |
| business-events | service | /en/services/business-event-transfers | /it/servizi/trasferimenti-aziendali-eventi | /es/servicios/traslados-empresas-eventos | Development content available |
| private-clients | service | /en/services/private-client-services | /it/servizi/servizi-clientela-privata | /es/servicios/servicios-clientes-privados | Development content available |
| diplomatic-transfers | service | /en/services/embassies-diplomats-delegations | /it/servizi/ambasciate-diplomatici-delegazioni | /es/servicios/embajadas-diplomaticos-delegaciones | Development content available |
| cruise-transfers | service | /en/services/cruise-port-transfers | /it/servizi/trasferimenti-terminal-crociere | /es/servicios/traslados-puertos-cruceros | Development content available |
| private-aviation | service | /en/services/private-aviation-transfers | /it/servizi/trasferimenti-aviazione-privata | /es/servicios/traslados-aviacion-privada | Development content available |
| services | services | /en/services | /it/servizi | /es/servicios | Development content available |
| fleet | fleet | /en/fleet | /it/flotta | /es/flota | Development content available |
| e-class | vehicle | /en/fleet/mercedes-e-class | /it/flotta/mercedes-e-class | /es/flota/mercedes-e-class | Development content available |
| s-class | vehicle | /en/fleet/mercedes-s-class | /it/flotta/mercedes-s-class | /es/flota/mercedes-s-class | Development content available |
| v-class | vehicle | /en/fleet/mercedes-v-class | /it/flotta/mercedes-v-class | /es/flota/mercedes-v-class | Development content available |
| vito | vehicle | /en/fleet/mercedes-vito | /it/flotta/mercedes-vito | /es/flota/mercedes-vito | Development content available |
| airports | airports | /en/airports | /it/aeroporti | /es/aeropuertos | Development content available |
| heathrow | airport | /en/airports/heathrow | /it/aeroporti/heathrow | /es/aeropuertos/heathrow | Development content available |
| gatwick | airport | /en/airports/gatwick | /it/aeroporti/gatwick | /es/aeropuertos/gatwick | Development content available |
| stansted | airport | /en/airports/stansted | /it/aeroporti/stansted | /es/aeropuertos/stansted | Development content available |
| luton | airport | /en/airports/luton | /it/aeroporti/luton | /es/aeropuertos/luton | Development content available |
| london-city | airport | /en/airports/london-city | /it/aeroporti/london-city | /es/aeropuertos/london-city | Development content available |
| southend | airport | /en/airports/southend | /it/aeroporti/southend | /es/aeropuertos/southend | Development content available |
| tours | tours | /en/tours | /it/tour | /es/rutas | Development content available |
| tours-london | tour | /en/tours/london | /it/tour/londra | /es/rutas/londres | Development content available |
| tours-uk | tour | /en/tours/beyond-london | /it/tour/fuori-londra | /es/rutas/fuera-de-londres | Development content available |
| about | editorial | /en/about | /it/chi-siamo | /es/quienes-somos | Development content available |
| partners | editorial | /en/partners | /it/partner | /es/colaboradores | Development content available |
| contact | contact | /en/contact | /it/contatti | /es/contacto | Development content available |
| enquiry | enquiry | /en/enquiry | /it/richiesta | /es/consulta | Development content available |
| faqs | faq | /en/faqs | /it/domande-frequenti | /es/preguntas-frecuentes | Development content available |
| directory | directory | /en/directory | /it/indice | /es/directorio | Development content available |
| terms | policy | /en/terms | /it/condizioni | /es/condiciones | Withheld pending policy |
| privacy | policy | /en/privacy | /it/privacy | /es/privacidad | Withheld pending policy |
| refund | policy | /en/cancellation-refund | /it/cancellazioni-rimborsi | /es/cancelaciones-reembolsos | Withheld pending policy |
| cookies | policy | /en/cookies | /it/cookie | /es/cookies | Withheld pending policy |
| accessibility | policy | /en/accessibility | /it/accessibilita | /es/accesibilidad | Withheld pending policy |
