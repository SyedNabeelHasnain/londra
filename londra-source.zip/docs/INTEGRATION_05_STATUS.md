# Londra Transfers — Integration Milestone 05

**Date:** 9 October 2026. **Status:** Updated development source, not a production-ready or one-click installer.

## Confirmed project constraints

Laravel 13.x, Filament 5.x, compatible PHPMailer 7.1.x, MySQL, PHP 8.5.4–8.5.x, one English-only administrator, three complete public languages, dark/light themes, approved six-colour palette, four confirmed fleet categories and capacities, enquiry CRM only, no reservation/payment/pricing engine, Hostinger shared hosting without SSH, and SMTP through the user's Zoho mailbox.

## Completed in this integration

- Added the Composer requirement `phpmailer/phpmailer:^7.1.1`, based on the current upstream release. The package is **declared, not downloaded or installed**.
- Added an isolated `InquirySmtpSender` service using authenticated SMTP, mandatory TLS, peer/hostname certificate validation, timed connections, no SMTP debug output, validated sender/recipient addresses and a matching authenticated From identity.
- Existing database-backed enquiry notification jobs now call the PHPMailer service. The administrator receives a reference linking to the protected desk; the customer receives the acknowledgement in the submitted language.
- Updated responsive HTML email with nested presentation tables, brand colours, receipt reference and matching plain-text versions. No email tracking pixel, third-party content or client personal data in the administrator HTML notification.
- Configured the `.env.example` for the supplied Hostinger MySQL hostname and account name, plus Zoho implicit TLS port 465, authenticated sender and Reply-To address. **Neither password is included. Put values containing `#`, spaces or shell-special characters inside quoted `.env` values in the private installation.**
- Added isolated mail transport tests and browser-rendered sample emails with test-only data.
- Staged exactly the already-tested public frontend CSS/JS as static versioned assets behind a compatible manifest. These are **not a completed, reproducible Vite/NPM build**. Removed the custom Filament Vite theme dependency for now so the package can use Filament's default bundled panel stylesheet when Filament is installed.
- Added a private/public split release builder script which deliberately refuses to build without PHP 8.5, required extensions, Composer, a dependency lock and vendor packages.
- Preserved existing frontend content, screenshots/preview design, 13 approved photographs, three languages and unresolved publication gates.

## Test boundaries

The isolation tests exercise mail service configuration and recipient selection using **dummy credentials**, not a real SMTP server. Sample email HTML has been parsed and browser-rendered at 320, 390 and 700 CSS pixels. PHP syntax, existing domain checks and preview rendering are dependency-free tests. The **live Laravel, Filament, MySQL, Zoho, PHP 8.5, Hostinger cron, email inbox delivery and no-SSH installation paths remain untested**.

## Blockers before producing a working release

1. Download and resolve Composer packages on a connected PHP 8.5 build system; create and audit `composer.lock`, install runtime `vendor`, install/publish Filament assets, then run all framework tests using a disposable MySQL test database.
2. Verify Hostinger's actual PHP extensions, writable directory separation, PHP CLI path, upload limits and Cron Jobs. The earlier read-only hosting report has not been provided.
3. Produce and test the no-SSH first-install process, safe application key generation and backup, database migrations, secure administrator creation and restore/rollback.
4. Privately configure the supplied temporary passwords on the server and perform connection tests **without inserting them into an uploaded/public ZIP**. Before production, rotate both temporary passwords and use different passwords for the database and mailbox.
5. Confirm the public Privacy/Terms/Cancellation/Cookies/Accessibility text and real business operating rules. Source intentionally prevents publication and real enquiries until the required legal/policy gates are satisfied.
6. Verify sender-specific Zoho SMTP host in that mailbox's Server Configuration Details. Zoho indicates that some paid organisation mailboxes use `smtppro.zoho.com` rather than `smtp.zoho.com`.
7. Verify the existing SPF record, Zoho DKIM signing and DMARC alignment using DNS and controlled deliverability tests. No library can guarantee placement in every recipient's inbox.

## Intended host layout

```text
hosting-account-home/
  londra-private/
    app/
    bootstrap/
    config/
    database/
    resources/
    routes/
    storage/
    vendor/
    .env
    artisan
  public_html/
    index.php
    .htaccess
    assets/
    build/
```

The public entry point in the builder references the private sibling application. A single ZIP containing both directories can be extracted at the hosting account **home**, provided permissions and paths have first been verified. Extracting all private Laravel source into `public_html` is not an equivalent or approved shortcut.

## Honest handoff

This release is the strongest source milestone that can be verified from the available environment. It is **not** described as 100% running, error-free or ready to replace the live site. See `BUILD_STATUS.json`, `tests/mail/isolated-smtp.php`, `reports/mail-samples/` and `tools/build-private-release.sh`.
