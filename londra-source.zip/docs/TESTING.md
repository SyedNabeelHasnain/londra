> Historical Milestone 01 record. For the replacement public frontend and current test evidence, read `FRONTEND_02_REVIEW.md`. Backend integration limits below still apply.

# Londra Transfers — Development test report

**Milestone 01, 8 October 2026. Source development and public design preview only; not a production release.**

## Executed checks

| Check | Observed result | Important boundary |
|---|---:|---|
| PHP source linting | 111 files passed | Runtime PHP 8.4.24; not PHP 8.5 and not framework execution. |
| JavaScript syntax | 3 files passed | Public interaction scripts and Vite config syntax only. |
| Shell syntax | Build script passed | No production build was run. |
| Dependency-free domain/presentation assertions | 888 passed | Language priority, safe paths, publication gates, shared capacities, omitted baggage, output escaping, CSV safety and London seasonal time checks. Repeated page assertions are not separate framework features. |
| Static content/markup/asset integrity | 1596 checks passed | All 96 translated previews; local links/assets, single H1, language metadata, unique IDs, labels/ARIA references, JSON parsing, exact photo preservation and artwork transparency/colour. |
| Browser page/viewport cases | 192 passed | All 96 previews at 320 and 1440 pixels; each was also switched from dark to light. |
| Focused browser interaction cases | 9 passed | Representative 320/390/768/1440 views; theme control, mobile menu, enquiry dialog, Escape behaviour, focus restoration and disabled preview submission. |
| Original photo hashes | 13 matched the approved ZIP | The approved PNG masters have not been regenerated or resized. |
| Transparent artwork | 17 RGBA exports checked | Transparent background plus exact white/gold/black foreground RGB after antialiasing normalisation. |
| Published policy placeholders | None in the preview | Five policy records remain blank, unreviewed and unpublished. |

Browser: Chromium 144.0.7559.96. The all-page checks found no JavaScript errors, missing images or horizontal overflow in their tested viewports and themes.

The review found missing dimensions on a decorative skyline image and colour-rounding variation in several resized gold images. Both were corrected, and the relevant checks were rerun successfully. This is not a promise that all defects have been eliminated.

## How the browser review actually worked

This environment blocks normal file navigation. The browser therefore received the exact generated page HTML using Playwright `set_content`, with the source CSS, JavaScript and approved local images inlined. It rendered real HTML and CSS; these are not generated image mockups. It did not navigate a running Laravel site.

Consequently, these results do not establish HTTP routing, actual server CSP behaviour, cross-origin cookie/preferences persistence, MySQL writes, Filament authentication, uploads, SMTP or production-host performance. Language and internal destination links were resolved separately against the generated local files.

## Application work written but not executed

There are 9 framework test methods in `tests/Feature/`, covering seeding, closed publication/form gates, language routing, protected paths, one-administrator enforcement, session-bound form tokens, encrypted/idempotent inquiry storage, policy withdrawal and disabled delivery. They require a resolved Laravel environment and an isolated MySQL test database. **They have not run in this milestone.**

Laravel/Filament dependencies could not be downloaded here. The container has PHP 8.4.24 and lacks several production extensions and PDO drivers. No Composer lock, NPM lock, vendor tree, installed package version or successful production compilation is fabricated.

The source includes MySQL schema, Laravel controller/model/job logic and Filament resources, but PHP linting cannot validate their runtime APIs. Their current state is implementation source requiring integration tests, not a working deployed CMS.

## Remaining release checks

Resolve current stable dependencies in a connected PHP 8.5 build environment, audit them, compile public/admin assets, execute migrations and the framework suite on isolated MySQL, test actual admin MFA/reset and uploads, test notifications/retries, verify Hostinger directory/cron/limits, implement and test the no-SSH installer, perform backups/restores, approve business policies and conduct application-level accessibility/security/performance checks.

No real customer records were created, no business email was sent, no live website was changed, and no independent external-agent or human audit is claimed. There are no guaranteed rankings, guaranteed inbox delivery, guaranteed zero errors or universal pixel-perfect rendering claims.

## Reproducibility

See `tests/README.md`, the executable source checks and the detailed JSON reports in `reports/`. Package checksums identify this exact milestone. `BUILD_STATUS.json` gives machine-readable completion and pending states.
