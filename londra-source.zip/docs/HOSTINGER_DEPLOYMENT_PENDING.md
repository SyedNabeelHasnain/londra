# Hostinger deployment: intentionally pending

The user has a basic shared Web Hosting plan without SSH and with database management/Cron Jobs. Those facts are recorded. PHP 8.5.4 is reported by the user but has not been observed through the hosting checker in this session.

Do not upload this source archive as an operational site. It lacks vendor dependencies, lock files, production builds and an installer. Publicly exposing the source root would be unsafe.

Preferred eventual layout:

```text
account-domain-root/
    londra-app/
        app/
        bootstrap/
        config/
        database/
        resources/
        routes/
        storage/
        vendor/
        .env
    public_html/
        index.php
        .htaccess
        assets/
        build/
```

The initial standard public/index.php in this source is for a Laravel public/ document root. It has NOT yet been remapped to the above Hostinger layout. Correct remapping, media serving, private storage permissions and cron paths depend on the actual directory capabilities.

Required evidence: the read-only hosting checker output, actual database server/version, usable parent-directory permissions and the hPanel cron facility. Do not provide passwords in chat.

Once the host is verified, build and test a restricted one-time installation process with database/extension/path validation, secure application-key creation, a single administrator setup, durable installation lock and instructions to remove setup access. Preserve a recovery backup outside the public directory.

Cron must call a PHP command privately. Do not create a public unauthenticated URL that runs migrations, clears caches, sends queues or creates administrators.

Before replacement: back up the current site/database, verify the release in an isolated location, test restore, then perform a controlled switch. Do not delete the existing website solely because this development source has been delivered.
