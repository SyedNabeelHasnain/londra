> Historical Milestone 01 record. For the replacement public frontend and current test evidence, read `FRONTEND_02_REVIEW.md`. Backend integration limits below still apply.

# Implementation status

## Implemented as source and independently inspectable

Custom public templates, dark/light styles and browser interactions; EN/IT/ES content/UI dictionaries; all approved photo masters and WebP variants; transparent artwork; models and MySQL migration source; guarded publication and revision logic; Filament content/fleet/media/CRM/email-queue resources; English settings and UI-translation administration; shared language routing; form validation and idempotency; encrypted enquiry/note fields; transactionally coupled notification records/jobs; mail views; follow-up fields and genuine enquiry metrics; single-record CSV export; discovery controllers and preview protection; source checks and framework test specifications.

The static preview executes the view's PHP on the local CLI and is then rendered in Chromium. This is actual public design work, not an image-generation mockup. It has no database or application login.

## Written but not executed in the framework

All Laravel/Filament lifecycle behaviour, migrations, ORM encryption, login/MFA/reset, uploads, resource form hydration, queue operations, notifications, SQL transactions/concurrency, redirects and HTTP validation require a real resolved Laravel environment. PHP syntax alone does not verify framework compatibility or database behaviour.

## Not completed or not configured

- Composer/NPM dependency resolution and locks; installed vendor packages; audited production assets.
- PHP 8.5 framework execution, real MySQL integration and Filament browser tests.
- The no-SSH production installer and final Hostinger path/cron configuration.
- SMTP credentials and actual sending/failure/retry tests.
- Business-specific policy content, legal/authorisation details and retention/deletion rules.
- Actual IP-country data lookup and dataset maintenance.
- Third-party analytics, Search Console connection, paid tools or marketing pixels.
- Responsive derivatives for future CMS-uploaded photographs; the 13 approved initial photos already have derivatives.
- Per-record optimistic edit conflict handling, full multi-page content-history comparisons, richer media focal-point editing and bulk filtered CRM export.
- Independent accessibility audit, penetration testing, load tests and real-user Core Web Vitals.

The current retention command is deliberately a non-destructive status report. It must not be described as an implemented purge policy.

No additional generated photographs were needed to construct this milestone's page coverage. New imagery can be considered for a specific uncovered page requirement rather than adding unrelated decorative images.

## Content management boundaries

The interface-copy editor updates the public page dictionary. Validation and email messages currently use the stored language dictionaries in source, not the CMS override. Linking those message templates into the same revision workflow remains a follow-up implementation task. Public contact settings and the internal notification recipient are separate; admin notifications remain directed to the configured business inbox. The three-language office/location phrase is edited with the interface copy.
