# Londra Transfers — Frontend 04 design and verification

**Date:** 8 October 2026  
**Status:** Public UI/UX design-review build. **Not a production Laravel/Hostinger installation.**

## Design direction

The approved Milestone 03 design was replaced because its composition still felt like a conventional promotional website. The current presentation adopts a quieter editorial approach inspired by private-client service, automotive craftsmanship and high-end hospitality. This is a design rationale, not a claim of research with real ultra-high-net-worth clients.

The opening comprises a balanced Londra Transfers masthead, carefully letter-spaced navigation, a typographic welcome and a composed image pairing: a chauffeur opening a rear door and a discreet secondary vehicle image. The hero does not use an auto-playing slideshow, inflated claims, a booking engine or a price headline. The central action is **Discuss your journey**.

A brief statement of service principles leads to four visual service choices, an interactive Mercedes-Benz collection, a contrasting champagne editorial passage, an atmospheric London photograph, a private-aviation section and a restrained final invitation. Each section has an intentional role and its own composition; the hierarchy is not a row of repeated cards.

A person enquiring is described respectfully as a **guest** in English and **ospite** in Italian, with **viajero** used in Spanish transport contexts. Internal database/API field names such as `passengers` remain unchanged for interoperability. The passenger limits are the established factual values **3, 3, 7 and 8**, with no invented luggage quantities. All public translations are stored in files for future CMS import; no runtime translation plugin is used.

### Invariants

- Exact brand base colours: `#000000`, `#0B0B0B`, `#FFFFFF`, `#F7F7F5`, `#BDA177`, `#F1ECD9`.
- Default dark theme, optional light theme; dark panels are permitted in light mode to preserve valid artwork contrast.
- Original approved winged-car emblem and supplied logos, white/gold variants, separators and imagery preserved. Approved photographic masters were not regenerated in this release.
- English, Italian and Spanish; **32 content page identities per language, 96 preview pages in all**, plus the English entry page. The five policy identities remain unpublished until actual operational terms are supplied.
- Exactly four Mercedes-Benz categories: E-Class 3 guests, S-Class 3 guests, V-Class 7 guests, Vito 8 guests.
- Enquiries only, no booking confirmation, fare, quotation, availability or payment engine. Static preview submissions are deliberately disabled.
- The previously agreed Laravel 13 / PHP 8.5.x / Filament / MySQL single-administrator architecture is preserved in development source, not claimed as executed.

## Interaction and accessibility work

- Responsive header and full navigation dialog with a visible close action and keyboard Escape dismissal.
- Explicit four-service image selector with accompanying text/imagery update.
- Four-vehicle presentation with tab selection, comparison and photograph-viewer dialogs.
- A three-field private enquiry panel with direct telephone alternative; contact pages use separate full-page forms.
- Focus restoration after closing the enquiry panel; accessible names and ARIA associations in the generated HTML.
- Dark/light switch and reduced-motion handling without scroll hijacking or automatic carousels.
- Image transformations are responsive crops and responsive WebP derivatives, not destructive edits to the approved masters.

The frontend uses available local/system typography; no font files or third-party font CDN are included. Browser typography will differ slightly between operating systems. Real cross-browser typography and accessibility reviews remain outstanding.

## Tests actually executed

| Scope | Result |
|---|---|
| Static source/markup/asset audit | **1,356 passed; 0 failed** |
| CSS viewport matrix, all 96 pages, widths 360/768/1440, dark/light | **576 passed; 0 failed** |
| Enquiry, navigation, theme, service/fleet selection, comparison, gallery in 3 languages | **105 passed; 0 failed** |
| Mocked client form states and validation, in 3 languages | **24 passed; 0 failed** |
| Small-screen fallback-font and 720px reflow checks | **33 passed; 0 failed** |
| Representative contrast pairs on opaque solid backgrounds | **28 passed; 0 failed** |
| PHP source syntax | **116 files passed on PHP 8.4.24** |
| Photography preservation | **13 original photo masters unchanged** |

**Regression fixes identified and retested:** at 320 CSS pixels, the footer wordmark extended outside the viewport; at 720 pixels the decorative footer separator did. Both have been corrected. A fallback-font Italian airport heading and a long Italian enquiry heading had narrow text overflow; responsive sizing/wrapping was refined and retested. A previously detected service-image selector error was also corrected before the current interaction tests.

Browser geometry and interaction checks used headless **Chromium 144**, rendering the generated HTML/CSS/JS with local assets through Playwright. They were not performed against an installed Laravel server. The contrast checks cover representative known solid backgrounds, not every pixel over images or a full WCAG certification. The form tests simulate success and failure responses: no real customer inquiry or email was sent.

## Files

- `Londra_Bespoke_Frontend_04_Preview.zip`: standalone local design preview; extract it fully, open `index.html`, explore the language and theme options, compare vehicles and inspect the enquiry panel.
- `Londra_Bespoke_Frontend_04_Source.zip`: full current development source and test evidence; not a ready-to-upload Hostinger package.
- Separate browser-rendered PNG screenshots are available for the opening, mobile, light mode, fleet, services, comparison and enquiry panel.

## What this build does not prove

Laravel/Filament dependencies are not resolved or installed. MySQL migrations, authentication, persistent storage, email sending/retry and the no-SSH Hostinger installation process have **not** been executed. PHP 8.5 hosting compatibility and performance are unverified. There has been no Safari/Firefox/assistive-technology, third-party security or independent UHNWI user evaluation. Five customer-facing legal/policy pages are still withheld pending business facts.

No claim is made that user taste, cross-device typography, visual luxury, universal pixel accuracy or zero defects can be guaranteed by the test matrix. This release is specifically for inspecting and approving the revised public design before broader backend integration.
