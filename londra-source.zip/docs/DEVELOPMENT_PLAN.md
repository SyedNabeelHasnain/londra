> Frontend 02 supersedes the original visual-system description. See `FRONTEND_02_REVIEW.md`. The approved business and backend scope is unchanged.

# Londra Transfers — Development plan and decision record

Prepared 8 October 2026. Status: the confirmed-scope plan is established and development has started. This record distinguishes owner-approved facts, implementation choices, executed checks and genuinely pending work.

## 1. Scope that is not being reopened

| Requirement | Decision |
|---|---|
| Platform | Laravel, Filament, MySQL and PHP 8.5.x |
| Hosting | Hostinger basic shared Web Hosting; no SSH; database management and Cron Jobs available; exact extension and directory capabilities not yet verified |
| Public languages | English, Italian and Spanish, with English default |
| Administration | One administrator, English-only CMS, no registration or role-management product |
| Conversion | Enquiries only; no fare/availability/quotation/payment/booking engine |
| Notification | Store first, then separate administrator notification and customer acknowledgement; SMTP supplied later |
| Themes | Dark default, visitor-selectable light mode |
| Colours | #000000, #0B0B0B, #FFFFFF, #F7F7F5, #BDA177, #F1ECD9 |
| Images | The final 13-image archive is authoritative for photographs; sources preserved; artwork exported with real alpha transparency |
| Fleet | E-Class 3, S-Class 3, V-Class 7, Vito 8 passengers |
| Business copy | Final English/Italian flyers override the prototype; natural stored Spanish translation is authorised |
| Design | Bespoke layouts and interactions; prototype is a functional reference, not a visual restriction |

## 2. Business-source controls

The final English and Italian V2 flyers establish the services, airports, destinations, passenger capacities and contact details. The provided English flyer page 1 contains eight service headings and page 2 lists airports, private aviation, tour destinations and fleet capacities. The Italian flyer is the corresponding language reference.

Source-based public content covers airport transfers, private transfers, private tours, chauffeur service, business/events, private client services, diplomatic/delegation transport and cruise port transfers. Private aviation is presented separately for navigation as ground transport, not an aircraft-charter business.

The six named airports and the London/UK tour destinations are retained. Professional guiding in Italian remains on request. Hotel and airline appearances in imagery are not treated as formal commercial endorsements or partnerships.

The flyers' TfL-authorisation and experience statements are recorded as business-supplied statements, not independently verified licence or company facts. Exact public legal identity and current supporting details remain pending. The initial public About text avoids expanding these statements into unsupported credentials. The English diplomatic term “security” is not silently expanded into close protection. Publication of specific protection/concierge promises remains tied to the owner's clarification.

Unknown baggage allowances are null. Policy records contain no customer-facing invented text. No fees, waiting allowances, refunds, contact hours, 24/7 claims, review scores or price ranges have been fabricated.

## 3. Application architecture

One application and one MySQL database serve the three public language directories and the English-only administration panel. There is no separately deployed frontend application or permanent Node process.

The public website is server-rendered through Blade. The design preview uses the same PHP template body without invoking Laravel, so it is useful for reviewing layout and content but cannot establish framework compatibility.

The CMS uses structured page fields, shared page identities and three associated translation records. Translations have their own slugs, titles, introductions, paragraphs, lists, FAQs, image descriptions and SEO values. Shared vehicle capacity is stored as structured fleet data rather than three independently managed capacity fields.

A publication action requires all three languages to be complete. Policies also need a recorded approval. Editing an approved policy withdraws publication and approval; restoring content history creates an unreviewed state. The source stores revision snapshots, but simultaneous-tab conflict prevention is not yet implemented and must not be claimed.

MySQL stores live content, enquiry records, sessions, caches and job queues. JSON files in this source are initial import data and review/export artefacts only. The database is not kept in parallel with another editable JSON persistence layer.

## 4. Current public-page coverage

The source contains 37 page identities and 111 language records. Thirty-two identities have substantive trilingual content and design previews. Five policy identities remain intentionally withheld: Terms, Privacy, Cancellation/Refund, Cookies and Accessibility.

Templates cover Home; Services and service detail; Fleet and vehicle detail; Airports and six airport details; Tours and London/beyond-London detail; About; Partners; Contact; Enquiry; FAQs; and a directory.

The private-tours service page explains the service, while the tours overview leads to destination groups. Their SEO titles are distinct. No invented extra fleet or paid attraction inclusion is added to populate a page.

Public interface strings are localised, including forms, validation guidance, acknowledgement text, theme controls, navigation, error pages and accessibility labels. A CMS interface-translations page allows editing known public UI keys; the administrator remains in English.

## 5. Enquiry and notification design

Booking enquiry: required name, email and telephone, plus service/page/language context. Contact enquiry adds subject and message. The public form explicitly distinguishes an enquiry from a confirmed booking and takes no payment.

Server-side rules validate lengths, type, email syntax and a permissive international telephone format. Page/service context must refer to existing published content. CSRF protection, a session-and-language-bound encrypted form token, a honeypot and a per-minute limiter are implemented in source.

An HMAC of the session and submission UUID identifies retries. A payload fingerprint rejects reuse of the same submission key for different data. The enquiry and two notification records are created in one database transaction. When notifications are enabled, database job records are inserted in that same transaction/connection so rolled-back enquiries do not leave committed jobs.

Customer contact fields and internal note bodies use Laravel encryption at rest. Exact email lookup uses a keyed hash rather than exposing a plaintext searchable email column. An application-key backup/recovery process is essential before live use; changing the key without a migration would make encrypted data unreadable.

Notification jobs contain record identifiers, not a plaintext customer payload. Each notification has independent state, attempts and an SMTP-acceptance timestamp. “Accepted by SMTP” is not labelled “delivered”. SMTP can accept a message before an application crash prevents saving its status; therefore email is not claimed to be exactly-once. Manual retry includes a duplicate-warning confirmation.

The customer receipt is in their selected language and does not confirm transport. The administrator notification goes to the confirmed business inbox and links to the protected record instead of repeating all personal information in email.

The CRM records New, Contacted, Awaiting response and Closed states, notes and a London-time follow-up. A single-record CSV export applies spreadsheet-formula neutralisation and warns that the download contains customer information.

## 6. Time, preferences and geolocation

Database/application timestamps use UTC. Administrator display and scheduled calendar interpretation use Europe/London, including BST/GMT transitions. Executed pure-PHP checks cover both 2026 seasonal transitions and the repeated autumn hour.

Explicit /en, /it and /es URLs are never overridden by inferred country. The neutral root uses an existing language preference before country. Italy maps to Italian, Spain to Spanish, all other or unknown countries to English. A manual language selection routes to the equivalent shared page and stores a first-party language preference.

Country lookup remains an unconnected adapter, not a fake IP/header detector. No Cloudflare headers are trusted when Cloudflare is absent. A maintained, licensed local country database can be integrated after the data source is provisioned. Until then English fallback is the real behaviour.

Dark/light selection is a first-party browser preference. No precise-location permission, third-party analytics, advertising pixel, fingerprinting service or public AI API is enabled.

## 7. Visual system and assets

The design uses only the six approved base colours. Transparency and blends of those colours are used for overlays/rules; photographic colours are not recoloured into the branding palette. Gold is not used as small body text against white. Light theme uses onyx text and intentionally dark surfaces for suitable artwork contrast.

All 13 approved PNG photographs are preserved byte-for-byte. There are 39 WebP display derivatives at up to 480, 960 and 1440 pixels, with no upscaling. These do not repair pre-existing generative details, incorrect model identification or the already-disclosed Ritz upscaled crop.

Fourteen provided white/gold raster artwork sources have transparent exports. Three additional logo exports are rendered from the original vector emblem paths, with the text path removed. Source copies and processing provenance are retained. The layout uses the clean vector-derived emblem rather than generatively redrawing the wings.

Typography uses Georgia/Arial system stacks in this milestone. No font binary or external font request is included. Final typography and actual compiled admin styles remain subject to design/runtime review.

Interactions use native dialog/details where possible, keyboard focus, Escape dismissal, a skip link, restrained hover movement and reduced-motion support. The form has a non-JavaScript page fallback. No autoplay video, scroll hijacking, parallax dependency, animation framework, sound or repeated popups are added.

## 8. SEO and public AI discovery

Source includes self-canonical URLs, localised titles/descriptions, Open Graph values, reciprocal language alternates, x-default, generated sitemaps and public structured data. Organization/WebSite/WebPage/Service/Breadcrumb entities contain only supported business information; no ratings, prices or invented street address are manufactured.

Edited slugs generate internal same-page redirects. Redirect targets are page records, not arbitrary external URLs. Main image alternative text and public interface copy are editable. Structured data is JSON-encoded with script-closing characters escaped.

The root and each language have supplementary llms.txt output, and llms-full.txt contains published public language content only. No inquiry, note, administrator or private record is included. Preview mode disables indexing and public discovery. These resources are not a promise of search rankings or AI recommendations.

Internal insights currently mean actual enquiry counts, statuses and dates. Search Console integration, traffic analytics, live ranking data and any external reporting credentials are not installed, simulated or represented as measured values.

## 9. Deployment approach for no SSH

Dependencies and CSS/JavaScript must be built on a separate connected build machine and included in the eventual deployment archive. Hostinger must not be asked to run Composer or Node interactively.

Laravel private files, .env, logs and storage must not be exposed under public_html. The preferred layout is a private sibling application directory and only public entry/assets under public_html. The Hostinger capability report determines whether that layout is supported and how the first-install process can be safely packaged.

There is no production installer in this milestone. A one-time restricted installer, final path mapping, database setup checks, installation locking and rollback instructions are remaining engineering work after dependency/runtime and hosting verification. This source ZIP is not that installer.

Cron should execute PHP commands, not expose an unauthenticated public scheduler URL. The source schedules bounded database-queue work. Actual CLI PHP path, PCNTL availability, scheduler interval, timeout/resource limits and cron execution are still unverified. PHP SMTP timeouts and transport-failure tests are also required.

No production migration or destructive command is run here. The source build script refuses to proceed without dependency locks and an isolated test environment. Framework tests refuse any MySQL database whose name does not end with _test.

## 10. Release sequence

1. Review the supplied working public design preview while content/CMS source continues to be refined.
2. Resolve audited dependencies in a connected PHP 8.5 environment; produce Composer/NPM lock files and public/admin builds.
3. Execute MySQL migrations and full Laravel/Filament/authentication/CRM tests on an isolated database.
4. Verify host extensions, directory separation, limits and the cron facility from the hosting report.
5. Complete exact privacy, commercial conditions and remaining special-service wording from business answers; keep unresolved copy unpublished.
6. Complete the no-SSH installer/deployment package and test installation, upgrade/rollback, backup/restore, SMTP retries and administrator recovery.
7. Perform real application browser, accessibility, concurrency and performance checks in desktop/mobile dark/light and all three public languages.
8. Only after acceptance, back up the existing website, deploy through the agreed layout, activate forms/SMTP and remove preview restrictions. Enable indexing separately after public content checks.

## 11. Remaining owner inputs, condensed

- The read-only hosting checker JSON report, to settle installation and cron compatibility rather than assume them.
- Approved current business identity/authorisation details and actual payment, waiting, cancellation, refund and enquiry-retention rules; existing policies or plain-language operating notes are sufficient.
- Specific special-service and fleet-practicality facts where they should be published: concierge/private-suite arrangements, diplomatic security meaning, luggage, child seats, accessibility and actual service languages. Unprovided optional details remain omitted rather than guessed.

SMTP credentials and the administrator password are entered securely during setup, not pasted into the conversation. Extra analytics and geolocation dataset integrations remain disabled until their data source and processing details are settled.

## 12. Validation status

Read TESTING.md and reports/*.json. Executed static/domain/browser-preview checks are distinct from tests merely written for the framework. No external-agent/human review or production security certification is claimed. Dependency/network limitations are engineering blockers, not business questions for the owner to answer.
