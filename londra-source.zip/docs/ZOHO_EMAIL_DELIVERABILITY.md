# Londra Transfers — Email transport and delivery readiness

**Intended sending identity:** `admin@londratransfers.co.uk`. **Administrator notifications:** `info@londratransfers.co.uk`. **Customer replies:** `info@londratransfers.co.uk`. The SMTP host and port are configured in `.env.example` without passwords.

## Transport behaviour

- PHPMailer 7.1.1 or another compatible tested 7.1.x release will be installed via Composer.
- Port 465 uses implicit TLS and port 587 uses STARTTLS; both require SMTP authentication and server-certificate/hostname validation.
- All notifications contain HTML and text alternatives. The customer version is localised to the submission language; the administrator version is English.
- Submission and email delivery are separate. Enquiries are saved first. Notification status records distinguish pending, retrying, failed and accepted by SMTP; acceptance does not establish final delivery to an inbox.
- Each job uses a fresh PHPMailer object, validates recipient addresses, avoids SMTP protocol logging and does not attach sensitive files.

## Required external verification

1. In the Zoho mailbox settings, verify the account-specific SMTP server. Zoho's official documentation distinguishes `smtp.zoho.com` and `smtppro.zoho.com` for different organisation plans.
2. Confirm `admin@londratransfers.co.uk` is an authenticated, sending-enabled mailbox, including an application password if two-factor authentication requires one.
3. Check the domain has one correct SPF policy covering all authorised senders; do not add a second SPF TXT record.
4. Enable and verify Zoho DKIM for the sending domain, then check the actual DMARC policy and alignment with the From address.
5. Test send/receive to multiple providers, inspect authentication results and diagnose delivery/bounce reports. No inbox-placement guarantee is possible.
6. Rotate the temporary database and SMTP passwords before live deployment and store replacements only in the private server configuration.

Official references: https://www.zoho.com/mail/help/zoho-smtp.html · https://www.zoho.com/mail/help/adminconsole/spf-configuration.html · https://www.zoho.com/mail/help/adminconsole/dkim-configuration.html · https://www.zoho.com/mail/help/adminconsole/dmarc-policy.html
