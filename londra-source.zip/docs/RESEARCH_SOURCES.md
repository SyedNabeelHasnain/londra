# Official research references

Reviewed during the 8 October 2026 development session. Links support architectural choices; they are not evidence that packages were installed or that the deployed application passed testing. Exact dependency versions remain unresolved until a connected build produces lock files.

| Area | Primary reference | Applied decision |
|---|---|---|
| Laravel release support | https://laravel.com/docs/releases | Start from the current Laravel 13 family and target the confirmed PHP 8.5 series. |
| Deployment | https://laravel.com/docs/13.x/deployment | Private application files must not be exposed as the public document root. |
| Asset build | https://laravel.com/docs/13.x/vite | Compile assets before deployment; no Node production server. |
| Database | https://laravel.com/docs/13.x/database | MySQL transactions for structured content and enquiry records. |
| Queues | https://laravel.com/docs/13.x/queues | Database queue, commit-aware work, bounded workers and explicit failure state. |
| Mail | https://laravel.com/docs/13.x/mail | Localised customer acknowledgement and separately addressed admin notification. |
| Filament installation | https://filamentphp.com/docs/5.x/introduction/installation | Use current Filament 5 API families rather than copy outdated resource APIs. |
| Filament resources | https://filamentphp.com/docs/5.x/resources/overview | Schema-based forms and resource tables. |
| Filament configuration | https://filamentphp.com/docs/5.x/panel-configuration | Single panel, transactions, persistent English management context, no extra tenants. |
| Filament authentication | https://filamentphp.com/docs/5.x/users/multi-factor-authentication | Built-in app MFA and recovery rather than a hand-written authentication factor. |
| Filament styling | https://filamentphp.com/docs/5.x/styling/overview | Separate admin theme and local system-font stylesheet. |
| Tailwind | https://tailwindcss.com/docs/installation/using-vite | Current Tailwind/Vite integration, custom approved brand tokens. |
| Vite | https://vite.dev/guide/ | Build-time tooling only, with compatible Node requirements. |
| Google multilingual sites | https://developers.google.com/search/docs/specialty/international/managing-multi-regional-sites | Separate persistent language URLs and discoverable equivalents. |
| Google language annotations | https://developers.google.com/search/docs/specialty/international/localized-versions | Reciprocal hreflang and appropriate x-default. |
| Google AI features | https://developers.google.com/search/docs/appearance/ai-features | Accessible public content; no special AI file or schema is required for eligibility. No ranking guarantee. |
| Composer constraints | https://getcomposer.org/doc/articles/versions.md | ~8.5.4 remains below PHP 8.6, unlike ^8.5. |

Business copy sources are the two final V2 flyers, not these software documents. In particular, industry documentation does not establish the business's fees, hours, licences, luggage allowance, cancellation terms or protection services.
