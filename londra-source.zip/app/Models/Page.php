<?php
declare(strict_types=1);
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Validation\ValidationException;
use App\Domain\ReleasePolicy;
final class Page extends Model
{
    protected $fillable = ['key', 'kind', 'image_key', 'published', 'approval_required', 'approved_at', 'sort_order', 'source_reference'];
    protected function casts(): array { return ['published' => 'boolean', 'approval_required' => 'boolean', 'approved_at' => 'datetime']; }
    public function translations(): HasMany { return $this->hasMany(PageTranslation::class); }
    public function revisions(): HasMany { return $this->hasMany(ContentRevision::class); }
    public function scopePublished(Builder $query): Builder { return $query->where('published', true); }
    public function translation(string $locale): ?PageTranslation { return $this->translations->firstWhere('locale', $locale); }
    protected static function booted(): void
    {
        static::saving(function (Page $page): void {
            if ($page->kind === 'policy') { $page->approval_required = true; }
            if ($page->isDirty('published') && $page->published && !ReleasePolicy::canPublish($page->approval_required, $page->approved_at !== null, $page->translations()->where('ready', true)->pluck('locale')->all())) {
                throw ValidationException::withMessages(['published' => 'Complete all three translations and required approval before publishing.']);
            }
        });
    }
}
