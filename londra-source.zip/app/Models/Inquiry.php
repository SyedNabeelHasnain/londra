<?php
declare(strict_types=1);
namespace App\Models;
use App\Domain\InquiryStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
final class Inquiry extends Model
{
    protected $fillable = ['reference', 'submission_key', 'payload_fingerprint', 'type', 'locale', 'status', 'name', 'email', 'phone', 'email_lookup', 'subject', 'message', 'page_key', 'service_key', 'follow_up_at', 'closed_at', 'privacy_notice_at', 'privacy_notice_version'];
    protected $hidden = ['name', 'email', 'phone', 'subject', 'message', 'email_lookup', 'submission_key', 'payload_fingerprint'];
    protected function casts(): array
    {
        return ['name' => 'encrypted', 'email' => 'encrypted', 'phone' => 'encrypted', 'subject' => 'encrypted', 'message' => 'encrypted', 'status' => InquiryStatus::class, 'follow_up_at' => 'datetime', 'closed_at' => 'datetime', 'privacy_notice_at' => 'datetime'];
    }
    public function notes(): HasMany { return $this->hasMany(InquiryNote::class); }
    public function deliveries(): HasMany { return $this->hasMany(NotificationDelivery::class); }
    protected static function booted(): void
    {
        static::saving(function (Inquiry $inquiry): void {
            if ($inquiry->isDirty('status')) { $inquiry->closed_at = $inquiry->status === InquiryStatus::Closed ? now() : null; }
        });
    }
}
