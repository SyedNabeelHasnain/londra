<?php
declare(strict_types=1);
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\ValidationException;
final class MediaAsset extends Model
{
    protected $fillable = ['key', 'public_path', 'upload_path', 'width', 'height', 'variants', 'alt_en', 'alt_it', 'alt_es', 'provenance'];
    protected function casts(): array { return ['variants' => 'array']; }
    public function url(): string { return $this->upload_path ? route('media', ['path' => $this->upload_path]) : asset($this->public_path); }
    public function alt(string $locale): string { return (string) $this->{'alt_'.$locale}; }
    protected static function booted(): void
    {
        static::saving(function (MediaAsset $media): void {
            if ($media->public_path && !preg_match('~^assets/(photos|artwork)/[a-z0-9.-]+$~D', $media->public_path)) { throw ValidationException::withMessages(['public_path' => 'Invalid asset path.']); }
            if ($media->upload_path && !preg_match('~^[a-f0-9-]{36}\.(png|jpg|jpeg|webp)$~D', $media->upload_path)) { throw ValidationException::withMessages(['upload_path' => 'Invalid upload path.']); }
            if($media->upload_path && $media->isDirty('upload_path')) {
                $path=\Illuminate\Support\Facades\Storage::disk('media')->path($media->upload_path);
                $size=@getimagesize($path);
                if(!$size || !in_array($size['mime'],['image/png','image/jpeg','image/webp'],true) || $size[0]*$size[1]>40000000) {throw ValidationException::withMessages(['upload_path'=>'Use a valid PNG, JPEG or WebP image below 40 megapixels.']);}
                $media->width=$size[0];$media->height=$size[1];$media->variants=[];
            }

        });
        static::deleting(function (MediaAsset $media): void {
            if (Page::where('image_key', $media->key)->exists() || Vehicle::where('image_key', $media->key)->exists()) { throw ValidationException::withMessages(['key' => 'This image is used by a page or vehicle. Replace those references first.']); }
        });
    }
}
