<?php
declare(strict_types=1);
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Domain\LocalePolicy;
use Illuminate\Validation\ValidationException;
final class Redirect extends Model
{
    protected $fillable = ['locale', 'from_path', 'page_id'];
    public function page(): BelongsTo { return $this->belongsTo(Page::class); }
    protected static function booted(): void
    {
        static::saving(function (Redirect $redirect): void {
            if (!LocalePolicy::safePath($redirect->from_path) || !in_array($redirect->locale, LocalePolicy::LOCALES, true)) { throw ValidationException::withMessages(['from_path' => 'Only local language paths are allowed.']); }
        });
    }
}
