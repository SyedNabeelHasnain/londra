<?php
declare(strict_types=1);
namespace App\Models;
use App\Domain\LocalePolicy;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Validation\ValidationException;
final class PageTranslation extends Model
{
    protected $fillable = ['locale', 'slug', 'title', 'eyebrow', 'intro', 'body', 'highlights', 'faq_items', 'seo_title', 'meta_description', 'image_alt', 'ready'];
    protected function casts(): array { return ['highlights' => 'array', 'faq_items' => 'array', 'ready' => 'boolean']; }
    public function page(): BelongsTo { return $this->belongsTo(Page::class); }
    public function url(): string { return rtrim(config('app.url'), '/').'/'.$this->locale.($this->slug === '' ? '' : '/'.$this->slug); }
    protected static function booted(): void
    {
        static::saving(function (PageTranslation $translation): void {
            if (!in_array($translation->locale, LocalePolicy::LOCALES, true) || !LocalePolicy::safePath($translation->slug)) {
                throw ValidationException::withMessages(['slug' => 'Use a valid localised path with lowercase letters, numbers, hyphens and slashes.']);
            }
            if (($translation->page->key === 'home') !== ($translation->slug === '')) {
                throw ValidationException::withMessages(['slug' => 'The homepage must use the empty path; all other pages need a path.']);
            }
            if ($translation->exists && $translation->isDirty('locale')) {
                throw ValidationException::withMessages(['locale' => 'Keep this translation in its existing language.']);
            }
            if ($translation->ready && (trim($translation->title) === '' || trim($translation->intro) === '' || trim($translation->seo_title) === '' || trim($translation->meta_description) === '')) {
                throw ValidationException::withMessages(['ready' => 'Title, introduction and metadata are required.']);
            }
        });
        static::updating(function (PageTranslation $translation): void {
            if ($translation->page->approval_required) { $translation->page->update(['published'=>false,'approved_at'=>null]); }
            elseif ($translation->isDirty('ready') && !$translation->ready) { $translation->page->update(['published'=>false]); }
            ContentRevision::create(['page_id' => $translation->page_id, 'locale' => $translation->locale, 'snapshot' => $translation->getOriginal(), 'user_id' => auth()->id()]);
            if ($translation->isDirty('slug')) {
                Redirect::updateOrCreate(['locale' => $translation->locale, 'from_path' => $translation->getOriginal('slug')], ['page_id' => $translation->page_id]);
            }
        });
    }
}
