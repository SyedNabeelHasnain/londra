<?php
declare(strict_types=1);
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
final class Vehicle extends Model
{
    protected $fillable = ['code', 'page_id', 'name', 'passengers', 'image_key', 'large_luggage', 'cabin_luggage', 'luggage_approved', 'active', 'sort_order'];
    protected function casts(): array { return ['passengers' => 'integer', 'active' => 'boolean', 'luggage_approved' => 'boolean']; }
    public function page(): BelongsTo { return $this->belongsTo(Page::class); }
}
