<?php
declare(strict_types=1);
namespace App\Http\Controllers;
use Illuminate\Http\Request;
final class PreviewController
{
    public function show() { abort_unless(config('londra.preview'), 404); return view('preview-login'); }
    public function login(Request $request)
    {
        abort_unless(config('londra.preview'), 404);
        $value = $request->validate(['password' => ['required', 'string', 'max:200']])['password'];
        $expected = config('londra.preview_password');
        abort_unless(is_string($expected) && strlen($expected) >= 20 && hash_equals($expected, $value), 403);
        $request->session()->regenerate(); $request->session()->put('londra_preview_authorized', true);
        return redirect('/en');
    }
}
