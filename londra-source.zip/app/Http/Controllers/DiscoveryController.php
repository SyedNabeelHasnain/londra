<?php
declare(strict_types=1);
namespace App\Http\Controllers;
use App\Models\Page;
use App\Services\PublicationState;
use Illuminate\Http\Request;
final class DiscoveryController
{
    public function robots(PublicationState $state)
    {
        $body=$state->indexingAllowed()?"User-agent: *\nDisallow: /admin\nDisallow: /livewire\nDisallow: /preview\nDisallow: /language/\nSitemap: ".rtrim(config('app.url'),'/')."/sitemap.xml\n":"User-agent: *\nDisallow: /\n";
        return response($body)->header('Content-Type','text/plain; charset=UTF-8');
    }
    public function sitemap(PublicationState $state)
    {
        $xml=new \XMLWriter();$xml->openMemory();$xml->startDocument('1.0','UTF-8');
        $xml->startElement('urlset');$xml->writeAttribute('xmlns','http://www.sitemaps.org/schemas/sitemap/0.9');$xml->writeAttribute('xmlns:xhtml','http://www.w3.org/1999/xhtml');
        if($state->indexingAllowed()){
            foreach(Page::published()->with('translations')->get() as $page){
                $translations=$page->translations->where('ready',true);
                foreach($translations as $translation){
                    $xml->startElement('url');$xml->writeElement('loc',$translation->url());$xml->writeElement('lastmod',$translation->updated_at->utc()->toAtomString());
                    foreach($translations as $alternate){$xml->startElement('xhtml:link');$xml->writeAttribute('rel','alternate');$xml->writeAttribute('hreflang',$alternate->locale);$xml->writeAttribute('href',$alternate->url());$xml->endElement();}
                    $english=$translations->firstWhere('locale','en');
                    if($english){$xml->startElement('xhtml:link');$xml->writeAttribute('rel','alternate');$xml->writeAttribute('hreflang','x-default');$xml->writeAttribute('href',$page->key==='home'?rtrim(config('app.url'),'/').'/':$english->url());$xml->endElement();}
                    $xml->endElement();
                }
            }
        }
        $xml->endElement();$xml->endDocument();
        return response($xml->outputMemory())->header('Content-Type','application/xml; charset=UTF-8');
    }
    public function llms(Request $request, PublicationState $state)
    {
        $locale=$request->route('locale') ?? 'en';
        if(!$state->indexingAllowed()){return response("# Londra Transfers\n\nPrivate development. Public discovery is not enabled.\n")->header('Content-Type','text/plain; charset=UTF-8');}
        $head=['en'=>'Private transport and chauffeur services in London and the United Kingdom.','it'=>'Trasporto privato e servizi con autista a Londra e nel Regno Unito.','es'=>'Transporte privado y servicios de chófer en Londres y en el Reino Unido.'];
        $body="# Londra Transfers\n\n> ".$head[$locale]."\n\n";
        foreach(Page::published()->with('translations')->orderBy('sort_order')->get() as $page){$t=$page->translation($locale);if($t?->ready){$body.='- ['.str_replace(['[',']'], '', $t->title).']('.$t->url().'): '.preg_replace('/\s+/u',' ',$t->intro)."\n";}}
        return response($body)->header('Content-Type','text/plain; charset=UTF-8');
    }
    public function llmsFull(PublicationState $state)
    {
        if(!$state->indexingAllowed()){return response("# Londra Transfers\n\nPrivate development. Public discovery is not enabled.\n")->header('Content-Type','text/plain; charset=UTF-8');}
        $body="# Londra Transfers\n\n";
        foreach(['en','it','es'] as $locale){foreach(Page::published()->with('translations')->orderBy('sort_order')->get() as $page){$t=$page->translation($locale);if($t?->ready){$body.='## '.strtoupper($locale).' / '.$t->title."\n\n".$t->url()."\n\n".$t->intro."\n\n".$t->body."\n\n";}}}
        return response($body)->header('Content-Type','text/plain; charset=UTF-8');
    }
}
