<?php
declare(strict_types=1);
namespace App\Http\Controllers;
use App\Actions\SubmitInquiry;
use App\Http\Requests\StoreInquiryRequest;
use App\Services\InquiryFormToken;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
final class InquiryController
{
    public function store(StoreInquiryRequest $request, SubmitInquiry $submit, InquiryFormToken $tokens): JsonResponse|RedirectResponse
    {
        $locale = (string) $request->route('locale');
        abort_unless($tokens->valid((string) $request->input('form_token'), $request->session()->getId(), $locale), 419);
        $inquiry = $submit->handle($request->validated(), $locale, $request->session()->getId());
        $result = ['reference' => $inquiry->reference, 'message' => __('ui.received'), 'booking_confirmed' => false, 'payment_taken' => false];
        if ($request->expectsJson()) { return response()->json($result, $inquiry->wasRecentlyCreated ? 201 : 200); }
        $target=\App\Models\Page::with('translations')->where('key',$inquiry->type==='contact'?'contact':'enquiry')->firstOrFail()->translation($locale);
        return redirect($target->url())->with('inquiry_receipt', $result);
    }
}
