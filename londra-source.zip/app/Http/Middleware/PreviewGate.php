<?php
declare(strict_types=1);
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
final class PreviewGate
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!config('londra.preview') || app()->environment('local', 'testing') || $request->is('admin*', 'livewire*', 'preview*', 'up', 'robots.txt', 'sitemap.xml', 'llms.txt', 'llms-full.txt', 'en/llms.txt', 'it/llms.txt', 'es/llms.txt')) { return $next($request); }
        if ($request->session()->get('londra_preview_authorized') === true) { return $next($request); }
        return redirect('/preview');
    }
}
