<?php
declare(strict_types=1);
namespace App\Presentation;
final class Html
{
    public static function e(mixed $value): string { return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
    public static function image(array $v, string $key, string $class = '', bool $priority = false, ?string $sizes = null): string
    {
        $media = $v['media'][$key] ?? null;
        if (!$media) { return ''; }
        $srcset = [];
        foreach (($media['variants'] ?? []) as $variant) { $srcset[] = $v['asset_base'].$variant['path'].' '.$variant['width'].'w'; }
        $variants = $media['variants'] ?? []; $last = $variants ? end($variants) : null;
        $src = $last ? $v['asset_base'].$last['path'] : ($media['url'] ?? $v['asset_base'].$media['original']);
        return '<img class="'.self::e($class).'" src="'.self::e($src).'"'.($srcset ? ' srcset="'.self::e(implode(', ', $srcset)).'" sizes="'.self::e($sizes ?? ($priority ? '100vw' : '(min-width: 1100px) 50vw, 100vw')).'"' : '').' alt="'.self::e($media['alt'][$v['locale']] ?? '').'" width="'.(int) ($media['width'] ?? 1600).'" height="'.(int) ($media['height'] ?? 1000).'" decoding="async" '.($priority ? 'fetchpriority="high"' : 'loading="lazy"').'>';
    }
    public static function arrow(): string { return '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" fill="none"><path d="M4 12h15m-6-6 6 6-6 6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'; }
}
