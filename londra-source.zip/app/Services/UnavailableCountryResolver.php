<?php
declare(strict_types=1);
namespace App\Services;
final class UnavailableCountryResolver implements CountryResolver
{
    public function country(?string $ip): ?string { return null; }
}
