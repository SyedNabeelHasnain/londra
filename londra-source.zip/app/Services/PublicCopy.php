<?php
declare(strict_types=1);
namespace App\Services;
use App\Models\Setting;
final class PublicCopy
{
    public function forLocale(string $locale): array
    {
        if(!in_array($locale,['en','it','es'],true)){throw new \InvalidArgumentException('Unsupported language.');}
        $defaults=trans('ui',[],$locale);
        $saved=Setting::find('interface-copy')?->value[$locale]??[];
        return array_intersect_key($saved,$defaults)+$defaults;
    }
}
