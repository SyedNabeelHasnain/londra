<?php
declare(strict_types=1);
namespace App\Services;
use App\Models\Inquiry;
use PHPMailer\PHPMailer\PHPMailer;
use RuntimeException;
final class InquirySmtpSender
{
    public function send(Inquiry $inquiry, string $kind): void
    {
        if (!in_array($kind, ['admin', 'customer'], true)) {
            throw new RuntimeException('Unknown notification category.');
        }
        $config = config('mail.mailers.smtp');
        $host = trim((string) ($config['host'] ?? ''));
        $port = (int) ($config['port'] ?? 0);
        $username = trim((string) ($config['username'] ?? ''));
        $password = (string) ($config['password'] ?? '');
        $from = trim((string) config('mail.from.address'));
        $replyTo = trim((string) config('mail.reply_to.address'));
        if ($host === '' || $username === '' || $password === '' || !in_array($port, [465, 587], true)) {
            throw new RuntimeException('SMTP configuration is incomplete.');
        }
        if (!filter_var($from, FILTER_VALIDATE_EMAIL) || !filter_var($replyTo, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('SMTP sender and reply-to addresses must be valid.');
        }
        if (strcasecmp($from, $username) !== 0) {
            throw new RuntimeException('SMTP From address must match the authenticated mailbox.');
        }
        $locale = $kind === 'admin' ? 'en' : $inquiry->locale;
        if (!in_array($locale, ['en', 'it', 'es'], true)) {
            throw new RuntimeException('Unsupported notification locale.');
        }
        $recipient = $kind === 'admin' ? (string) config('londra.contact.email') : (string) $inquiry->email;
        if (!filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('SMTP recipient address is invalid.');
        }
        $subject = ($kind === 'admin'
            ? 'New '.($inquiry->type === 'contact' ? 'contact' : 'journey').' enquiry'
            : (string) __('ui.email_subject', [], $locale)).' | '.$inquiry->reference;
        $viewData = ['inquiry' => $inquiry, 'kind' => $kind, 'locale' => $locale];
        $html = view('emails.inquiry-received', $viewData)->render();
        $plain = view('emails.inquiry-received-text', $viewData)->render();
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = $host;
        $mail->Port = $port;
        $mail->SMTPAuth = true;
        $mail->Username = $username;
        $mail->Password = $password;
        $mail->SMTPSecure = $port === 465 ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAutoTLS = false;
        $mail->SMTPDebug = 0;
        $mail->Timeout = 15;
        $mail->SMTPKeepAlive = false;
        $mail->SMTPOptions = ['ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'allow_self_signed' => false]];
        $mail->CharSet = PHPMailer::CHARSET_UTF8;
        $mail->Encoding = PHPMailer::ENCODING_BASE64;
        $mail->setFrom($from, (string) config('mail.from.name', 'Londra Transfers'));
        $mail->addAddress($recipient);
        if ($kind === 'admin') {
            if (filter_var((string) $inquiry->email, FILTER_VALIDATE_EMAIL)) {
                $mail->addReplyTo((string) $inquiry->email, (string) $inquiry->name);
            }
        } else {
            $mail->addReplyTo($replyTo, (string) config('mail.reply_to.name', 'Londra Transfers'));
        }
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $html;
        $mail->AltBody = $plain;
        $mail->send();
    }
}
