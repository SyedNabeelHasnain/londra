<?php
declare(strict_types=1);
namespace App\Services;
use App\Domain\ReleasePolicy;
use App\Models\Page;
final class PublicationState
{
    public function policiesReady(): bool
    {
        return Page::query()->whereIn('key', ['privacy', 'terms', 'refund'])->where('published', true)->whereNotNull('approved_at')->whereHas('translations', fn($q) => $q->where('ready', true), '=', 3)->count() === 3;
    }
    public function inquiriesAllowed(): bool { return ReleasePolicy::inquiryAllowed(config('londra')) && $this->policiesReady(); }
    public function indexingAllowed(): bool { return ReleasePolicy::indexAllowed(config('londra')) && $this->policiesReady(); }
}
