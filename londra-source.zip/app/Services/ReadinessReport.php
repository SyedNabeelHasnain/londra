<?php
declare(strict_types=1);
namespace App\Services;
use App\Models\{Page,User};
use Illuminate\Support\Facades\DB;
final class ReadinessReport
{
    private function hasPublicAssets(): bool
    {
        $manifest = public_path('build/manifest.json');
        if (!is_file($manifest)) { return false; }
        try {
            $entries = json_decode((string) file_get_contents($manifest), true, 512, JSON_THROW_ON_ERROR);
            foreach (['resources/css/app.css', 'resources/js/app.js'] as $key) {
                if (!isset($entries[$key]['file']) || !is_string($entries[$key]['file'])) { return false; }
                if (!is_file(public_path('build/'.$entries[$key]['file']))) { return false; }
            }
            return true;
        } catch (\Throwable) { return false; }
    }
    public function checks(): array
    {
        $extensions=['ctype','curl','dom','fileinfo','filter','hash','intl','mbstring','openssl','pcre','pdo_mysql','session','tokenizer','xml','xmlwriter'];
        $missing=array_values(array_filter($extensions,fn(string $extension)=>!extension_loaded($extension)));
        $connection=false;
        try { $connection=(int)DB::select('SELECT 1 AS healthy')[0]->healthy===1; } catch (\Throwable) {}
        $pages=$connection ? Page::with('translations')->get() : collect();
        $unfinished=$pages->filter(fn(Page $page)=>$page->published && $page->translations->where('ready',true)->count()!==3)->count();
        $policies=$pages->where('kind','policy')->filter(fn(Page $page)=>$page->published&&$page->approved_at)->count();
        return [
            ['label'=>'PHP 8.5 compatibility','ok'=>PHP_VERSION_ID>=80504&&PHP_VERSION_ID<80600,'detail'=>PHP_VERSION],
            ['label'=>'Required PHP extensions','ok'=>$missing===[],'detail'=>$missing?implode(', ',$missing):'Available'],
            ['label'=>'MySQL connection','ok'=>$connection,'detail'=>$connection?'Query succeeded':'Not verified'],
            ['label'=>'Exactly one administrator','ok'=>$connection&&User::count()===1,'detail'=>'Single administrator only; registration is disabled.'],
            ['label'=>'Published pages have three reviewed translations','ok'=>$connection&&$pages->isNotEmpty()&&$unfinished===0,'detail'=>$unfinished.' published pages require attention.'],
            ['label'=>'Policies reviewed and published','ok'=>$policies===5,'detail'=>$policies.' of 5 policy pages approved and published.'],
            ['label'=>'Preview protection disabled for approved launch','ok'=>!config('londra.preview'),'detail'=>'Keep protection enabled until acceptance checks have passed.'],
            ['label'=>'Publication explicitly approved','ok'=>(bool)config('londra.publication_approved'),'detail'=>'Business approval is separate from software testing.'],
            ['label'=>'Privacy explicitly approved','ok'=>(bool)config('londra.privacy_approved'),'detail'=>'Requires accurate retention and processing information.'],
            ['label'=>'Notification processing enabled','ok'=>(bool)config('londra.send_notifications'),'detail'=>'Actual SMTP sending, failures and cron execution still require live testing.'],
            ['label'=>'Public stylesheet and script files staged','ok'=>$this->hasPublicAssets(),'detail'=>'Static frontend assets are staged; this does not certify the Filament package assets or a reproducible Vite build.'],
            ['label'=>'Debug information disabled','ok'=>!config('app.debug'),'detail'=>'Never expose production exception details.'],
        ];
    }
}
