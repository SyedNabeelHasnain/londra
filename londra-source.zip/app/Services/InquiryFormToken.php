<?php
declare(strict_types=1);
namespace App\Services;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;
final class InquiryFormToken
{
    public function issue(string $sessionId, string $locale): string
    {
        return Crypt::encryptString(json_encode(['session' => hash('sha256', $sessionId), 'locale' => $locale, 'issued_at' => time()], JSON_THROW_ON_ERROR));
    }
    public function valid(string $token, string $sessionId, string $locale): bool
    {
        try { $data = json_decode(Crypt::decryptString($token), true, 16, JSON_THROW_ON_ERROR); }
        catch (DecryptException|\JsonException $exception) { return false; }
        return is_array($data) && hash_equals(hash('sha256', $sessionId), (string) ($data['session'] ?? '')) && ($data['locale'] ?? null) === $locale && is_int($data['issued_at'] ?? null) && $data['issued_at'] <= time() && $data['issued_at'] >= time() - 7200;
    }
}
