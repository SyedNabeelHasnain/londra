<?php
declare(strict_types=1);
namespace App\Providers;
use App\Services\CountryResolver;
use App\Services\UnavailableCountryResolver;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;
final class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(CountryResolver::class, UnavailableCountryResolver::class);
    }
    public function boot(): void
    {
        if (str_starts_with((string) config('app.url'), 'https://')) { URL::forceScheme('https'); }
        RateLimiter::for('inquiries', fn (Request $request) => Limit::perMinute(5)->by(hash_hmac('sha256', (string) $request->ip(), (string) config('app.key'))));
        RateLimiter::for('preview-login', fn (Request $request) => Limit::perMinute(5)->by(hash_hmac('sha256', (string) $request->ip(), (string) config('app.key'))));
    }
}
