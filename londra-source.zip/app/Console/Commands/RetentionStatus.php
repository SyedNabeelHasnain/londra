<?php
declare(strict_types=1);
namespace App\Console\Commands;
use Illuminate\Console\Command;
final class RetentionStatus extends Command
{
    protected $signature='londra:retention';
    protected $description='Report that automatic deletion remains disabled until the retention policy is approved.';
    public function handle(): int
    {
        $this->warn('Automatic deletion is not implemented: the business retention period and deletion criteria are pending. No records changed.');
        return self::SUCCESS;
    }
}
