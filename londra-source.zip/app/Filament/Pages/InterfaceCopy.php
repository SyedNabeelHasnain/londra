<?php
declare(strict_types=1);
namespace App\Filament\Pages;
use App\Models\Setting;
use Filament\Pages\Page;
use Filament\Schemas\Contracts\HasSchemas;
use Filament\Schemas\Concerns\InteractsWithSchemas;
use Filament\Schemas\Schema;
use Filament\Forms\Components\{Select,KeyValue};
use Filament\Notifications\Notification;
final class InterfaceCopy extends Page implements HasSchemas
{
    use InteractsWithSchemas;
    protected static string|\BackedEnum|null $navigationIcon='heroicon-o-language';
    protected static string|\UnitEnum|null $navigationGroup='Content';
    protected static ?string $navigationLabel='Interface translations';
    protected string $view='filament.pages.interface-copy';
    public ?array $data=[];
    public function mount(): void {$this->form->fill(['locale'=>'en','copy'=>app(\App\Services\PublicCopy::class)->forLocale('en')]);}
    public function form(Schema $schema): Schema
    {
        return $schema->components([
            Select::make('locale')->options(['en'=>'English','it'=>'Italiano','es'=>'Español'])->required()->live()->afterStateUpdated(function(string $state):void{if(in_array($state,['en','it','es'],true)){$this->form->fill(['locale'=>$state,'copy'=>app(\App\Services\PublicCopy::class)->forLocale($state)]);}}),
            KeyValue::make('copy')->label('Public interface text')->keyLabel('Fixed key')->valueLabel('Translation')->addable(false)->deletable(false)->editableKeys(false)->reorderable(false),
        ])->statePath('data');
    }
    public function save(): void
    {
        $data=$this->form->getState();$locale=$data['locale'];
        abort_unless(in_array($locale,['en','it','es'],true),422);
        $defaults=trans('ui',[],$locale);$copy=array_intersect_key($data['copy'],$defaults);
        foreach($defaults as $key=>$value){if(!isset($copy[$key])||!is_string($copy[$key])||trim($copy[$key])===''||mb_strlen($copy[$key])>1200){throw \Illuminate\Validation\ValidationException::withMessages(['data.copy'=>'Every fixed key requires a non-empty translation, up to 1,200 characters.']);}}
        $saved=Setting::find('interface-copy')?->value??[];$saved[$locale]=$copy;
        Setting::updateOrCreate(['key'=>'interface-copy'],['value'=>$saved]);
        Notification::make()->title('Interface translations saved')->success()->send();
    }
}
