<?php
declare(strict_types=1);
namespace App\Filament\Pages;
use App\Models\Setting;
use Filament\Actions\Action;
use Filament\Forms\Components\{TextInput,Textarea};
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Schema;
use Filament\Schemas\Concerns\InteractsWithSchemas;
use Filament\Schemas\Contracts\HasSchemas;
final class PortalSettings extends Page implements HasSchemas
{
    use InteractsWithSchemas;
    protected static string|\BackedEnum|null $navigationIcon='heroicon-o-cog-6-tooth';
    protected static string|\UnitEnum|null $navigationGroup='Administration';
    protected string $view='filament.pages.settings';
    public ?array $data=[];
    public function mount(): void
    {
        $stored=Setting::find('public-contact')?->value ?? [];
        $this->form->fill($stored+['phone_display'=>config('londra.contact.phone'),'phone_link'=>config('londra.contact.tel'),'email'=>config('londra.contact.email'),'instagram'=>config('londra.contact.instagram')]);
    }
    public function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('phone_display')->required()->maxLength(40),TextInput::make('phone_link')->required()->regex('/^\+[0-9]{6,20}$/D'),
            TextInput::make('email')->required()->email()->maxLength(254),TextInput::make('instagram')->required()->regex('/^[a-zA-Z0-9_.]{1,60}$/D'),
        ])->statePath('data');
    }
    public function save(): void
    {
        Setting::updateOrCreate(['key'=>'public-contact'],['value'=>$this->form->getState()]);
        Notification::make()->title('Contact information saved')->success()->send();
    }
}
