<?php
declare(strict_types=1);
namespace App\Filament\Widgets;
use App\Models\Inquiry;
use App\Models\NotificationDelivery;
use Filament\Widgets\StatsOverviewWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
final class InquiryStats extends StatsOverviewWidget
{
    protected function getStats(): array
    {
        return [
            Stat::make('New enquiries',Inquiry::where('status','new')->count())->description('Awaiting first contact')->color('primary'),
            Stat::make('Follow-ups due',Inquiry::where('status','!=','closed')->whereNotNull('follow_up_at')->where('follow_up_at','<=',now())->count())->description('London time')->color('primary'),
            Stat::make('Emails needing attention',NotificationDelivery::whereIn('status',['pending','failed'])->count())->description('SMTP acceptance is tracked, not inbox delivery')->color('primary'),
        ];
    }
}
