<?php
declare(strict_types=1);
namespace App\Filament\Widgets;
use App\Models\Inquiry;
use Carbon\CarbonImmutable;
use Filament\Widgets\ChartWidget;
final class InquiryChart extends ChartWidget
{
    public function getHeading(): string { return 'Enquiries over the last 14 days'; }
    protected function getType(): string { return 'line'; }
    protected function getData(): array
    {
        $labels=[]; $values=[];
        for($i=13;$i>=0;$i--){
            $day=CarbonImmutable::now('Europe/London')->subDays($i)->startOfDay();
            $labels[]=$day->format('d M');
            $values[]=Inquiry::where('created_at','>=',$day->utc())->where('created_at','<',$day->addDay()->utc())->count();
        }
        return ['datasets'=>[['label'=>'Received enquiries','data'=>$values,'borderColor'=>'#BDA177','backgroundColor'=>'#F1ECD9','tension'=>0.2]],'labels'=>$labels];
    }
}
