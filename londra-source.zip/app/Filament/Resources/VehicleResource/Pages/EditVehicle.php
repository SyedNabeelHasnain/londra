<?php
declare(strict_types=1);
namespace App\Filament\Resources\VehicleResource\Pages;
use App\Filament\Resources\VehicleResource;
use Filament\Resources\Pages\EditRecord;
final class EditVehicle extends EditRecord
{
    protected static string $resource = VehicleResource::class;
}
