<?php
declare(strict_types=1);
namespace App\Filament\Resources\MediaAssetResource\Pages;
use App\Filament\Resources\MediaAssetResource;
use Filament\Resources\Pages\ListRecords;
final class ListMediaAssets extends ListRecords
{
    protected static string $resource = MediaAssetResource::class;
    protected function getHeaderActions(): array { return [\Filament\Actions\CreateAction::make()]; }
}
