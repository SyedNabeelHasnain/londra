<?php
declare(strict_types=1);
namespace App\Filament\Resources;
use App\Models\Vehicle;
use App\Models\Page;
use App\Models\MediaAsset;
use App\Filament\Resources\VehicleResource\Pages;
use Filament\Actions\EditAction;
use Filament\Forms\Components\{TextInput,Select,Toggle};
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Tables\Table;
use Filament\Tables\Columns\{TextColumn,IconColumn};
final class VehicleResource extends Resource
{
    protected static ?string $model = Vehicle::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-truck';
    protected static string|\UnitEnum|null $navigationGroup = 'Content';
    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('code')->required()->maxLength(40)->unique(ignoreRecord:true)->regex('/^[a-z0-9-]+$/D'),
            TextInput::make('name')->required()->maxLength(255),
            Select::make('page_id')->options(fn()=>Page::where('kind','vehicle')->pluck('key','id'))->required(),
            Select::make('image_key')->options(fn()=>MediaAsset::pluck('key','key'))->required()->searchable(),
            TextInput::make('passengers')->label('Passenger capacity, excluding the driver')->numeric()->integer()->minValue(1)->maxValue(99)->required(),
            TextInput::make('large_luggage')->label('Large suitcases, only when confirmed')->numeric()->integer()->minValue(0)->maxValue(99)->nullable(),
            TextInput::make('cabin_luggage')->label('Cabin bags, only when confirmed')->numeric()->integer()->minValue(0)->maxValue(99)->nullable(),
            Toggle::make('luggage_approved')->label('Publish these confirmed luggage allowances')->default(false),
            Toggle::make('active')->default(true),TextInput::make('sort_order')->numeric()->minValue(0)->maxValue(999)->default(0),
        ])->columns(2);
    }
    public static function table(Table $table): Table { return $table->columns([TextColumn::make('name')->searchable(),TextColumn::make('passengers')->label('Passengers'),IconColumn::make('active')->boolean()])->recordActions([EditAction::make()])->defaultSort('sort_order'); }
    public static function getPages(): array { return ['index'=>Pages\ListVehicles::route('/'),'create'=>Pages\CreateVehicle::route('/create'),'edit'=>Pages\EditVehicle::route('/{record}/edit')]; }
}
