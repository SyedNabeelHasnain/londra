<?php
declare(strict_types=1);
namespace App\Filament\Resources;
use App\Models\{ContentRevision,PageTranslation};
use Filament\Resources\Resource;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Actions\Action;
use Filament\Forms\Components\Textarea;
use Illuminate\Support\Facades\DB;
final class ContentRevisionResource extends Resource
{
    protected static ?string $model=ContentRevision::class;
    protected static ?string $navigationLabel='Content history';
    protected static string|\BackedEnum|null $navigationIcon='heroicon-o-clock';
    protected static string|\UnitEnum|null $navigationGroup='Content';
    public static function canCreate(): bool{return false;}
    public static function canEdit(\Illuminate\Database\Eloquent\Model $record): bool{return false;}
    public static function table(Table $table): Table
    {
        return $table->columns([TextColumn::make('page.key')->searchable(),TextColumn::make('locale'),TextColumn::make('created_at')->dateTime('d M Y H:i')->timezone('Europe/London'),TextColumn::make('user.name')])->recordActions([
            Action::make('inspect')->label('Inspect revision')->schema([Textarea::make('snapshot')->rows(20)->disabled()])->fillForm(fn(ContentRevision $record)=>['snapshot'=>json_encode($record->snapshot,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)])->modalSubmitAction(false)->modalCancelActionLabel('Close'),
            Action::make('restore')->requiresConfirmation()->modalDescription('Restore the text as an unreviewed translation and unpublish the page. Review all languages before publishing again.')->action(function(ContentRevision $record):void{DB::transaction(function()use($record):void{
                $translation=PageTranslation::where('page_id',$record->page_id)->where('locale',$record->locale)->lockForUpdate()->firstOrFail();
                $data=array_intersect_key($record->snapshot,array_flip(['title','eyebrow','intro','body','highlights','faq_items','seo_title','meta_description','image_alt']));
                foreach(['highlights','faq_items'] as $key){if(isset($data[$key])&&is_string($data[$key])){$data[$key]=json_decode($data[$key],true,512,JSON_THROW_ON_ERROR);}}
                $translation->fill([...$data,'ready'=>false])->save();$translation->page->update(['published'=>false]);
            });}),
        ])->defaultSort('created_at','desc');
    }
    public static function getPages(): array{return ['index'=>\App\Filament\Resources\ContentRevisionResource\Pages\ListContentRevisions::route('/')];}
}
