<?php
declare(strict_types=1);
namespace App\Filament\Resources\PageResource\Pages;
use App\Filament\Resources\PageResource;
use Filament\Resources\Pages\CreateRecord;
final class CreatePage extends CreateRecord
{
    protected static string $resource = PageResource::class;
}
