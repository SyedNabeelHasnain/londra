<?php
declare(strict_types=1);
namespace App\Filament\Resources\PageResource\Pages;
use App\Filament\Resources\PageResource;
use Filament\Resources\Pages\EditRecord;
final class EditPage extends EditRecord
{
    protected static string $resource = PageResource::class;
    protected function getHeaderActions(): array { return [\Filament\Actions\Action::make('publish')->requiresConfirmation()->action(fn()=>app(\App\Actions\PublishPage::class)->handle($this->record))]; }
}
