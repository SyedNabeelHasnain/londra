<?php
declare(strict_types=1);
namespace App\Filament\Resources;
use App\Actions\PublishPage;
use App\Models\Page;
use App\Models\MediaAsset;
use App\Filament\Resources\PageResource\Pages;
use Filament\Actions\Action;
use Filament\Actions\EditAction;
use Filament\Forms\Components\{TextInput,Textarea,Select,Repeater,Toggle,TagsInput};
use Filament\Schemas\Components\Section;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Tables\Table;
use Filament\Tables\Columns\{TextColumn,IconColumn};
use Filament\Tables\Filters\SelectFilter;
final class PageResource extends Resource
{
    protected static ?string $model = Page::class;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-document-text';
    protected static string|\UnitEnum|null $navigationGroup = 'Content';
    protected static ?int $navigationSort = 1;
    public static function canDelete(\Illuminate\Database\Eloquent\Model $record): bool { return false; }
    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make('Page')->schema([
                TextInput::make('key')->required()->maxLength(80)->regex('/^[a-z0-9-]+$/D')->unique(ignoreRecord:true)->disabledOn('edit'),
                Select::make('kind')->required()->disabledOn('edit')->options(array_combine(['home','services','service','fleet','vehicle','airports','airport','tours','tour','editorial','contact','enquiry','faq','directory','policy'],['Home','Service overview','Service','Fleet overview','Vehicle','Airport overview','Airport','Tour overview','Tour','Editorial','Contact','Enquiry','FAQs','Directory','Policy'])),
                Select::make('image_key')->label('Main image')->options(fn()=>MediaAsset::orderBy('key')->pluck('key','key'))->searchable(),
                TextInput::make('sort_order')->numeric()->minValue(0)->maxValue(999)->default(0),
                TextInput::make('source_reference')->label('Source or approval reference')->maxLength(255),
            ])->columns(2),
            Repeater::make('translations')->relationship()->schema([
                Select::make('locale')->label('Language')->disabledOn('edit')->options(['en'=>'English','it'=>'Italiano','es'=>'Español'])->required()->disableOptionsWhenSelectedInSiblingRepeaterItems(),
                TextInput::make('slug')->label('URL path, without the language prefix')->maxLength(190),
                TextInput::make('title')->required()->maxLength(200), TextInput::make('eyebrow')->maxLength(160),
                Textarea::make('intro')->required()->rows(3), Textarea::make('body')->label('Main text; blank lines separate paragraphs')->rows(8),
                TagsInput::make('highlights')->label('Destination or feature list'),
                Repeater::make('faq_items')->label('Questions and answers')->schema([TextInput::make('q')->label('Question')->required()->maxLength(240), Textarea::make('a')->label('Answer')->required()->maxLength(4000)])->defaultItems(0)->collapsible()->columnSpanFull(),
                TextInput::make('seo_title')->required()->maxLength(200), Textarea::make('meta_description')->required()->rows(3),
                TextInput::make('image_alt')->label('Alternative text for the main image')->maxLength(255),
                Toggle::make('ready')->label('This translation has been reviewed')->default(false),
            ])->default([['locale'=>'en'],['locale'=>'it'],['locale'=>'es']])->minItems(3)->maxItems(3)->addable(false)->deletable(false)->reorderable(false)->columns(2)->columnSpanFull(),
        ]);
    }
    public static function table(Table $table): Table
    {
        return $table->columns([TextColumn::make('key')->searchable()->sortable(),TextColumn::make('kind')->sortable(),IconColumn::make('published')->boolean(),IconColumn::make('approval_required')->boolean(),TextColumn::make('updated_at')->dateTime('d M Y H:i')->timezone('Europe/London')->sortable()])
            ->filters([SelectFilter::make('kind')->options(['service'=>'Services','vehicle'=>'Fleet','airport'=>'Airports','tour'=>'Tours','policy'=>'Policies'])])
            ->recordActions([
                EditAction::make(),
                Action::make('publish')->requiresConfirmation()->visible(fn(Page $record)=>!$record->published)->action(fn(Page $record)=>app(PublishPage::class)->handle($record)),
                Action::make('unpublish')->requiresConfirmation()->visible(fn(Page $record)=>$record->published)->action(fn(Page $record)=>$record->update(['published'=>false])),
                Action::make('approve')->label('Approve reviewed policy')->requiresConfirmation()->modalDescription('Only approve after the business has supplied and reviewed the actual policy in all three languages.')->visible(fn(Page $record)=>$record->approval_required && !$record->approved_at)->action(fn(Page $record)=>$record->update(['approved_at'=>now()])),
            ])->defaultSort('sort_order');
    }
    public static function getPages(): array { return ['index'=>Pages\ListPages::route('/'),'create'=>Pages\CreatePage::route('/create'),'edit'=>Pages\EditPage::route('/{record}/edit')]; }
}
