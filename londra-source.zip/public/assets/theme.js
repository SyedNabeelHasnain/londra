(() => {
    let theme = 'dark';
    try { if (localStorage.getItem('londra-theme') === 'light') theme = 'light'; } catch {}
    document.documentElement.dataset.theme = theme;
})();
