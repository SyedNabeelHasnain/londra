<?php
declare(strict_types=1);
use App\Http\Middleware\EnglishAdmin;
use App\Http\Middleware\PreviewGate;
use App\Http\Middleware\SecurityHeaders;
use App\Http\Middleware\SetPublicLocale;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
$app = Application::configure(basePath: dirname(__DIR__))
    ->withRouting(web: __DIR__.'/../routes/web.php', commands: __DIR__.'/../routes/console.php', health: '/up')
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->prepend(\App\Http\Middleware\VerifyOriginHost::class);
        $middleware->append(SecurityHeaders::class);
        $middleware->web(append: [PreviewGate::class]);
        $middleware->alias(['locale.public' => SetPublicLocale::class, 'admin.english' => EnglishAdmin::class]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {})
    ->create();
$publicSibling = dirname(__DIR__, 2).'/public_html';
if (is_dir($publicSibling) && !is_dir(dirname(__DIR__).'/public/build')) {
    $app->usePublicPath(realpath($publicSibling));
}
return $app;
