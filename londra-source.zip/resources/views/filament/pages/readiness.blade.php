<x-filament-panels::page>
<x-filament::section heading="Release checks"><p>These checks describe configuration and content state. They are not a security certification, legal approval or proof of delivery to an email inbox.</p></x-filament::section>
@foreach ($this->checks() as $check)<x-filament::section :heading="$check['label']"><p>{{ $check['ok'] ? 'Pass' : 'Pending' }}: {{ $check['detail'] }}</p></x-filament::section>@endforeach
</x-filament-panels::page>
