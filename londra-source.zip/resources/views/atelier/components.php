<?php
use App\Presentation\Html;
$e = static fn($value) => Html::e($value);
$u = $v['u']; $p = $v['page']; $links = $v['links']; $cat = $v['catalog']; $base = $v['asset_base'];
$link = static fn(string $key) => $links[$key] ?? $links['home'];
$services = array_filter($cat, static fn($item) => $item['kind'] === 'service');
$airports = array_filter($cat, static fn($item) => $item['kind'] === 'airport');
if (!empty($p['image_alt']) && isset($v['media'][$p['image_key']])) { $v['media'][$p['image_key']]['alt'][$v['locale']] = $p['image_alt']; }
$photos = static fn($key, $class = '', $priority = false, $sizes = null) => Html::image($v, $key, $class, $priority, $sizes);
$arrow = static fn() => Html::arrow();
$cta = static fn(string $label, string $style = 'button', string $service = '') => '<a class="'.$e($style).'" href="'.$e($link('enquiry')).'" data-open-enquiry data-service="'.$e($service).'" data-service-name="'.$e($cat[$service]['title']??'').'">'.'<span>'.$e($label).'</span>'.Html::arrow().'</a>';
$icon = static function(string $name) use ($e): string {
    $paths = [
        'close'=>'<path d="m6 6 12 12M18 6 6 18"/>',
        'sun'=>'<circle cx="12" cy="12" r="4"/><path d="M12 1v2m0 18v2M1 12h2m18 0h2M4.2 4.2l1.4 1.4m12.8 12.8 1.4 1.4m0-15.6-1.4 1.4M5.6 18.4l-1.4 1.4"/>',
        'moon'=>'<path d="M20.8 13A9 9 0 0 1 11 3.2 9 9 0 1 0 20.8 13Z"/>',
        'plus'=>'<path d="M12 5v14M5 12h14"/>',
        'person'=>'<circle cx="12" cy="7" r="3"/><path d="M5 21v-3a7 7 0 0 1 14 0v3"/>',
        'chevron'=>'<path d="m7 10 5 5 5-5"/>',
        'back'=>'<path d="M20 12H4m6-6-6 6 6 6"/>',
        'up'=>'<path d="M12 20V4m-6 6 6-6 6 6"/>',
        'phone'=>'<path d="m7 3 3 5-3 2c1 3 4 6 7 7l2-3 5 3c0 3-2 4-4 4C10 20 4 14 3 7c0-2 1-4 4-4Z"/>',
    ];
    return '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.($paths[$name]??$paths['plus']).'</svg>';
};
$brand = static function(string $class='') use($base,$link,$e,$u): void { ?>
<a href="<?= $e($link('home')) ?>" class="brand <?= $e($class) ?>" aria-label="Londra Transfers · <?= $e($u['home']) ?>"><span class="emblem-stack"><img src="<?= $e($base) ?>assets/artwork/logo-master-gold.png" class="emblem-dark" width="1224" height="306" alt=""><img src="<?= $e($base) ?>assets/artwork/logo-master-black.png" class="emblem-light" width="1224" height="306" alt=""></span><span class="wordmark">LONDRA<span>TRANSFERS</span></span></a>
<?php };
$renderForm = static function(string $type, string $id) use($v,$u,$p,$e,$link,$services): void {
    $old=$v['old']; $disabled=!$v['accept_inquiries'];
?>
<form action="<?= $e($v['form_action']) ?>" method="post" data-enquiry-form data-preview="<?= $disabled ? 'true' : 'false' ?>" class="enquiry-form">
<input type="hidden" name="_token" value="<?= $e($v['csrf']) ?>"><input type="hidden" name="submission_id" value="<?= $e($v['submission_id']) ?>"><input type="hidden" name="form_token" value="<?= $e($v['form_token']) ?>"><input type="hidden" name="type" value="<?= $e($type) ?>"><input type="hidden" name="page_key" value="<?= $e($p['key']) ?>">
<?php if($type==='booking'): ?><input type="hidden" name="service_key" value="<?= $e($p['kind']==='service'?$p['key']:'') ?>"><?php endif; ?>
<div class="honeypot" aria-hidden="true"><label for="<?= $e($id) ?>-website">Website</label><input id="<?= $e($id) ?>-website" name="website" tabindex="-1" autocomplete="off"></div>
<?php foreach(['name'=>'text','email'=>'email','phone'=>'tel'] as $name=>$kind): ?><div class="form-field full"><label for="<?= $e($id.'-'.$name) ?>"><?= $e($u[$name]) ?></label><input id="<?= $e($id.'-'.$name) ?>" name="<?= $e($name) ?>" type="<?= $e($kind) ?>" value="<?= $e($old[$name]??'') ?>" autocomplete="<?= $e($name==='phone'?'tel':$name) ?>" required maxlength="<?= $name==='email'?'254':($name==='name'?'120':'40') ?>" aria-describedby="<?= $e($id.'-'.$name) ?>-error"><span class="field-error" id="<?= $e($id.'-'.$name) ?>-error" data-field-error="<?= $e($name) ?>"><?= $e($v['errors'][$name][0]??'') ?></span></div><?php endforeach; ?>
<?php if($type==='contact'): ?>
<div class="form-field full"><label for="<?= $e($id) ?>-service"><?= $e($u['service']) ?> <span>(<?= $e($u['optional']) ?>)</span></label><select id="<?= $e($id) ?>-service" name="service_key"><option value=""><?= $e($u['any_service']) ?></option><?php foreach($services as $item): ?><option value="<?= $e($item['key']) ?>" <?= ($old['service_key']??'')===$item['key']?'selected':'' ?>><?= $e($item['title']) ?></option><?php endforeach; ?></select></div>
<div class="form-field full"><label for="<?= $e($id) ?>-subject"><?= $e($u['subject']) ?></label><input id="<?= $e($id) ?>-subject" name="subject" required maxlength="160" value="<?= $e($old['subject']??'') ?>" aria-describedby="<?= $e($id) ?>-subject-error"><span class="field-error" id="<?= $e($id) ?>-subject-error" data-field-error="subject"><?= $e($v['errors']['subject'][0]??'') ?></span></div>
<div class="form-field full"><label for="<?= $e($id) ?>-message"><?= $e($u['message']) ?></label><textarea id="<?= $e($id) ?>-message" name="message" required maxlength="5000" rows="5" aria-describedby="<?= $e($id) ?>-message-error"><?= $e($old['message']??'') ?></textarea><span class="field-error" id="<?= $e($id) ?>-message-error" data-field-error="message"><?= $e($v['errors']['message'][0]??'') ?></span></div>
<?php endif; ?>
<?php if(isset($v['links']['privacy'])): ?><p class="form-note"><a href="<?= $e($link('privacy')) ?>"><?= $e($u['privacy_notice']) ?></a></p><?php endif; ?>
<p class="form-note"><?= $e($u['form_note']) ?></p>
<?php if($disabled): ?><p class="preview-form"><?= $e($u['preview_form']) ?></p><?php endif; ?>
<button type="submit" class="button form-submit" <?= $disabled?'disabled':'' ?>><?= $e($u['send']) ?><?= Html::arrow() ?></button>
<p class="form-status" data-form-status role="status" aria-live="polite"><?php if($v['receipt']): ?><?= $e($u['received'].' '.$u['reference'].': '.($v['receipt']['reference']??'')) ?><?php endif; ?></p>
</form>
<?php };

$sectionTitle = static function(string $kicker,string $title,string $intro='',string $id='') use($e): void { ?>
<div class="section-heading"><div><p class="eyebrow"><?= $e($kicker) ?></p><h2 <?= $id?'id="'.$e($id).'"':'' ?>><?= $e($title) ?></h2></div><?php if($intro): ?><p class="section-intro"><?= $e($intro) ?></p><?php endif; ?></div>
<?php };
$renderFleet = static function(string $id='fleet-deck') use($v,$cat,$e,$u,$photos,$cta,$icon): void { $vehicles=array_values(array_filter($v['vehicles'],static fn($x)=>isset($cat[$x['page_key']]))); ?>
<div class="fleet-deck" data-deck data-initial="1">
<div class="fleet-tabs" data-tablist aria-label="<?= $e($u['fleet_selection']) ?>">
<?php foreach($vehicles as $i=>$vehicle): $item=$cat[$vehicle['page_key']]; ?><button type="button" class="fleet-tab" data-tab="<?= $i ?>" id="<?= $e($id) ?>-tab-<?= $i ?>" aria-controls="<?= $e($id) ?>-panel-<?= $i ?>"><span class="tab-index">0<?= $i+1 ?></span><span><?= $e(str_replace('Mercedes-Benz ', '', $item['title'])) ?></span><small><?= (int)$vehicle['passengers'] ?> <?= $e($u['guests']) ?></small></button><?php endforeach; ?>
</div>
<?php foreach($vehicles as $i=>$vehicle): $item=$cat[$vehicle['page_key']]; ?>
<div class="fleet-panel" id="<?= $e($id) ?>-panel-<?= $i ?>" data-panel="<?= $i ?>" aria-labelledby="<?= $e($id) ?>-tab-<?= $i ?>">
<div class="fleet-copy"><div><p class="eyebrow"><?= $e($u['fleet_maker']) ?></p><h3><?= $e(str_replace('Mercedes-Benz ', '', $item['title'])) ?></h3></div><div class="fleet-description"><p><?= $e($item['intro']) ?></p><div class="capacity"><?= $icon('person') ?><strong><?= (int)$vehicle['passengers'] ?></strong><span><?= $e($u['guests']) ?></span></div></div><a href="<?= $e($item['url']) ?>" class="text-link"><span><?= $e($u['view_vehicle']) ?></span><?= Html::arrow() ?></a></div>
<div class="fleet-photo"><span class="fleet-frame" aria-hidden="true"></span><?= $photos($vehicle['image_key'], '', false, '100vw') ?><div class="fleet-photo-label"><span><?= $e($u['fleet_index']) ?></span><span>0<?= $i+1 ?> / <?= sprintf('%02d',count($vehicles)) ?></span></div><button class="photo-open" type="button" data-open-gallery aria-label="<?= $e($u['fleet_image'].' · '.$item['title']) ?>"><span><?= $e($u['fleet_image']) ?></span><?= $icon('plus') ?></button></div>
</div>
<?php endforeach; ?><div class="fleet-bottom"><span><?= $e($u['fleet_browse']) ?></span><div class="fleet-controls"><button type="button" class="circle-button" data-deck-prev aria-label="<?= $e($u['previous_vehicle']) ?>"><?= $icon('back') ?></button><button type="button" class="circle-button" data-deck-next aria-label="<?= $e($u['next_vehicle']) ?>"><?= Html::arrow() ?></button></div><button class="text-link compare-trigger" type="button" data-open-compare><span><?= $e($u['fleet_compare']) ?></span><?= $icon('plus') ?></button></div>
</div>
<?php };
$renderServiceIndex = static function(array $items,string $class='') use($e,$photos,$u): void { ?>
<div class="service-collection <?= $e($class) ?>"><?php foreach(array_values($items) as $i=>$item): ?><article class="service-spread"><div class="spread-head"><span class="folio">0<?= $i+1 ?></span><h2><a href="<?= $e($item['url']) ?>"><?= $e($item['title']) ?></a></h2></div><a class="spread-photo media-zoom" href="<?= $e($item['url']) ?>"><?= $photos($item['image_key']) ?><span class="circle-button image-corner" aria-hidden="true"><?= Html::arrow() ?></span></a><div class="spread-copy"><p><?= $e($item['intro']) ?></p><a class="text-link" href="<?= $e($item['url']) ?>"><span><?= $e($u['service_caption']) ?></span><?= Html::arrow() ?></a></div></article><?php endforeach; ?></div>
<?php };
$renderProcess = static function() use($e,$u): void { ?>
<div class="process-grid"><?php for($i=1;$i<=3;$i++): ?><div><span class="process-number">0<?= $i ?></span><p><?= $e($u['process_'.$i]) ?></p></div><?php endfor; ?></div>
<?php };
?>
