<?php require $v['template_root'].'/components.php'; ?>
<!doctype html>
<html lang="<?= $e($v['locale']) ?>" data-theme="dark">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="dark light"><meta name="theme-color" content="#0B0B0B">
<title><?= $e($p['seo_title']) ?></title><meta name="description" content="<?= $e($p['meta_description']) ?>"><meta name="robots" content="<?= $v['indexable']?'index,follow,max-image-preview:large':'noindex,nofollow,noarchive' ?>"><link rel="canonical" href="<?= $e($v['canonical']) ?>">
<?php foreach($v['alternates'] as $locale=>$url): ?><link rel="alternate" hreflang="<?= $e($locale) ?>" href="<?= $e($url) ?>"><?php endforeach; ?>
<link rel="alternate" hreflang="x-default" href="<?= $e($p['key']==='home'?$v['origin'].'/':($v['alternates']['en']??$v['canonical'])) ?>">
<meta property="og:type" content="website"><meta property="og:site_name" content="Londra Transfers"><meta property="og:title" content="<?= $e($p['seo_title']) ?>"><meta property="og:description" content="<?= $e($p['meta_description']) ?>"><meta property="og:url" content="<?= $e($v['canonical']) ?>"><meta property="og:locale" content="<?= $e(['en'=>'en_GB','it'=>'it_IT','es'=>'es_ES'][$v['locale']]) ?>">
<?php if(isset($v['media'][$p['image_key']])): ?><meta property="og:image" content="<?= $e(($v['media'][$p['image_key']]['url']??($v['origin'].'/'.$v['media'][$p['image_key']]['original']))) ?>"><meta property="og:image:alt" content="<?= $e($v['media'][$p['image_key']]['alt'][$v['locale']]??'') ?>"><?php endif; ?>
<meta name="twitter:card" content="summary_large_image"><link rel="icon" type="image/png" href="<?= $e($base) ?>assets/artwork/logo-master-gold.png">
<script src="<?= $e($base) ?>assets/theme.js"></script><link rel="stylesheet" href="<?= $e($v['css_url']) ?>"><script <?= $v['offline']?'defer':'type="module"' ?> src="<?= $e($v['js_url']) ?>"></script>
<script type="application/ld+json"><?= $v['schema'] ?></script>
</head>
<body data-page="<?= $e($p['key']) ?>" data-kind="<?= $e($p['kind']) ?>" data-ui="<?= $e(json_encode($u,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)) ?>">
<a class="skip-link" href="#main"><?= $e($u['skip']) ?></a>
<?php require $v['template_root'].'/header.php'; ?>
<main id="main" tabindex="-1">
<?php require $v['template_root'].($p['kind']==='home'?'/home.php':'/page.php'); ?>
<?php if(!in_array($p['kind'],['contact','enquiry','policy'],true)): ?>
<section class="invitation" aria-labelledby="invitation-title"><div class="invitation-grid wrap"><div class="invitation-copy"><p class="eyebrow"><?= $e($u['contact_kicker']) ?></p><h2 id="invitation-title"><?= $e($u['invitation_first']) ?><br><em><?= $e($u['invitation_second']) ?></em></h2><p><?= $e($u['cta_body']) ?></p><div class="invitation-actions"><?= $cta($u['enquire'],'button') ?><a href="tel:<?= $e($v['contact']['phone_link']) ?>" class="invitation-phone"><?= $e($v['contact']['phone_display']) ?></a></div></div><div class="invitation-photo"><?= $photos('private-transfer') ?><span class="invitation-emblem"><img src="<?= $e($base) ?>assets/artwork/logo-master-white.png" alt="" width="1224" height="306" loading="lazy"></span></div></div></section>
<?php endif; ?>
</main>
<?php require $v['template_root'].'/footer.php'; ?>
</body></html>
