(() => {
    'use strict';
    document.documentElement.classList.add('js');
    let ui = {};
    try { ui = JSON.parse(document.body.dataset.ui || '{}'); } catch { return; }
    const themeButton = document.querySelector('[data-theme-toggle]');
    const syncTheme = () => {
        const isLight = document.documentElement.dataset.theme === 'light';
        themeButton?.setAttribute('aria-pressed', String(isLight));
        themeButton?.setAttribute('aria-label', isLight ? ui.dark : ui.light);
        document.querySelector('meta[name="theme-color"]')?.setAttribute('content', isLight ? '#F7F7F5' : '#0B0B0B');
    };
    themeButton?.addEventListener('click', () => {
        const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
        document.documentElement.dataset.theme = next;
        try { localStorage.setItem('londra-theme', next); } catch {}
        syncTheme();
    });
    syncTheme();
    document.querySelectorAll('.language-switch').forEach(details => {
        details.addEventListener('keydown', event => {
            if (event.key === 'Escape') {
                details.open = false;
                details.querySelector('summary')?.focus();
            }
        });
        document.addEventListener('click', event => {
            if (!details.contains(event.target)) details.open = false;
        });
    });
    const configureDialog = (id, openSelector, closeSelector, onOpen) => {
        const dialog = document.getElementById(id);
        if (!dialog || typeof dialog.showModal !== 'function') return;
        let opener = null;
        document.querySelectorAll(openSelector).forEach(link => {
            link.addEventListener('click', event => {
                event.preventDefault();
                opener = link;
                document.querySelectorAll('.language-switch[open]').forEach(element => { element.open = false; });
                onOpen?.(dialog, link);
                document.querySelectorAll('dialog[open]').forEach(other => { if (other !== dialog) other.close(); });
                if (!dialog.open) dialog.showModal();
                document.body.classList.add('is-locked');
                const title = dialog.querySelector('h2[tabindex="-1"]');
                title?.focus({preventScroll: true});
            });
        });
        dialog.querySelector(closeSelector)?.addEventListener('click', () => dialog.close());
        dialog.addEventListener('click', event => {
            if (event.target !== dialog) return;
            const rect = dialog.getBoundingClientRect();
            if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
        });
        dialog.addEventListener('close', () => {
            if (!document.querySelector('dialog[open]')) document.body.classList.remove('is-locked');
            if (opener?.isConnected) opener.focus({preventScroll:true});
        });
    };
    configureDialog('navigation-dialog', '[data-open-navigation]', '[data-close-navigation]');
    configureDialog('enquiry-dialog', '[data-open-enquiry]', '[data-close-dialog]', (dialog, link) => {
        const service = dialog.querySelector('[name="service_key"]');
        const selected = link.dataset.service || '';
        if (service) service.value = selected;
        const context = dialog.querySelector('[data-enquiry-context]');
        if (context) {
            const option = document.querySelector(`option[value="${CSS.escape(selected)}"]`);
            const name = option?.textContent || link.dataset.serviceName || '';
            context.hidden = !selected || !name;
            context.querySelector('strong').textContent = name;
        }
    });
    document.querySelectorAll('[data-deck]').forEach(deck => {
        const tablist = deck.querySelector('[data-tablist]');
        const tabs = Array.from(deck.querySelectorAll('[data-tab]'));
        const panels = Array.from(deck.querySelectorAll('[data-panel]'));
        if (!tablist || !tabs.length || tabs.length !== panels.length) return;
        const vertical = tablist.dataset.orientation === 'vertical';
        tablist.setAttribute('role', 'tablist');
        tablist.setAttribute('aria-orientation', vertical ? 'vertical' : 'horizontal');
        tabs.forEach(tab => tab.setAttribute('role', 'tab'));
        panels.forEach(panel => { panel.setAttribute('role','tabpanel'); panel.setAttribute('tabindex','0'); });
        const activate = (index, focus = false) => {
            const current = (index + tabs.length) % tabs.length;
            tabs.forEach((tab, i) => {
                tab.setAttribute('aria-selected', String(i === current));
                tab.tabIndex = i === current ? 0 : -1;
                panels[i].hidden = i !== current;
            });
            if (focus) tabs[current].focus({preventScroll: true});
        };
        tabs.forEach((tab, index) => {
            tab.addEventListener('click', () => activate(index));
            tab.addEventListener('keydown', event => {
                const forwards = vertical ? 'ArrowDown' : 'ArrowRight';
                const backwards = vertical ? 'ArrowUp' : 'ArrowLeft';
                const next = event.key === forwards ? index + 1 : event.key === backwards ? index - 1 : event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : null;
                if (next === null) return;
                event.preventDefault();
                activate(next, true);
            });
        });
        deck.classList.add('is-enhanced');
        deck.querySelector('[data-deck-prev]')?.addEventListener('click', () => {
            const current = tabs.findIndex(tab => tab.getAttribute('aria-selected') === 'true');
            activate(current - 1);
        });
        deck.querySelector('[data-deck-next]')?.addEventListener('click', () => {
            const current = tabs.findIndex(tab => tab.getAttribute('aria-selected') === 'true');
            activate(current + 1);
        });
        const requested = Number.parseInt(deck.dataset.initial || '0', 10);
        activate(Number.isFinite(requested) && requested >= 0 && requested < tabs.length ? requested : 0);
    });
    configureDialog('compare-dialog', '[data-open-compare]', '[data-close-compare]');
    configureDialog('gallery-dialog', '[data-open-gallery]', '[data-close-gallery]', (dialog, trigger) => {
        const source = trigger.closest('.fleet-photo')?.querySelector('img');
        const image = dialog.querySelector('.gallery-photo img');
        if (!source || !image) return;
        image.removeAttribute('srcset');
        image.removeAttribute('sizes');
        image.src = source.currentSrc || source.src;
        image.alt = source.alt;
        const vehicle = trigger.closest('.fleet-panel')?.querySelector('h3')?.textContent || '';
        const title = dialog.querySelector('h2');
        if (title) title.textContent = `${ui.gallery_title}${vehicle ? ' · ' + vehicle : ''}`;
    });
    const navigation = document.getElementById('navigation-dialog');
    navigation?.querySelectorAll('[data-menu-image]').forEach(link => {
        const selectImage = () => {
            navigation.querySelectorAll('[data-menu-scene]').forEach(scene => {
                scene.hidden = scene.dataset.menuScene !== link.dataset.menuImage;
            });
        };
        link.addEventListener('mouseenter', selectImage);
        link.addEventListener('focus', selectImage);
    });
    document.querySelectorAll('[data-cinema]').forEach(cinema => {
        const controls = Array.from(cinema.querySelectorAll('[data-scene-select]'));
        const scenes = Array.from(cinema.querySelectorAll('[data-scene]'));
        const select = (index, focus = false) => {
            const next = (index + controls.length) % controls.length;
            controls.forEach((control, i) => control.setAttribute('aria-pressed', String(i === next)));
            scenes.forEach((scene, i) => { scene.hidden = i !== next; });
            if (focus) controls[next].focus({preventScroll:true});
        };
        controls.forEach((control, index) => {
            control.addEventListener('click', () => select(index));
            control.addEventListener('keydown', event => {
                let next = null;
                if (event.key === 'ArrowRight') next = index + 1;
                if (event.key === 'ArrowLeft') next = index - 1;
                if (event.key === 'Home') next = 0;
                if (event.key === 'End') next = controls.length - 1;
                if (next !== null) { event.preventDefault(); select(next, true); }
            });
        });
    });
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;
                observer.unobserve(entry.target);
                if (!reduceMotion.matches && typeof entry.target.animate === 'function') {
                    entry.target.animate([{opacity:0.55, transform:'translateY(16px)'},{opacity:1, transform:'translateY(0)'}], {duration:700, easing:'cubic-bezier(.22,1,.36,1)'});
                }
            });
        }, {threshold:0.12});
        document.querySelectorAll('.section-heading,.journey-card,.experience-copy,.arrivals-copy,.spread-head').forEach(node => observer.observe(node));
    }
    let scrollPending = false;
    const updateScroll = () => {
        const hero = document.querySelector('.cinema');
        const threshold = hero ? Math.max(650, hero.offsetHeight - 120) : 500;
        document.body.classList.toggle('has-scrolled', window.scrollY > threshold);
        document.body.classList.toggle('scrolled-header', window.scrollY > (hero ? hero.offsetHeight - 85 : 280));
        scrollPending = false;
    };
    window.addEventListener('scroll', () => {
        if (scrollPending) return;
        scrollPending = true;
        requestAnimationFrame(updateScroll);
    }, {passive:true});
    updateScroll();
    document.querySelectorAll('[data-enquiry-form]').forEach(form => {
        const status = form.querySelector('[data-form-status]');
        const submit = form.querySelector('[type="submit"]');
        if (!status || !submit) return;
        const originalButton = Array.from(submit.childNodes).map(node => node.cloneNode(true));
        const restoreButton = () => submit.replaceChildren(...originalButton.map(node => node.cloneNode(true)));
        form.querySelectorAll('input,textarea,select').forEach(input => {
            input.addEventListener('input', () => {
                input.setCustomValidity('');
                input.removeAttribute('aria-invalid');
                const error = form.querySelector(`[data-field-error="${CSS.escape(input.name)}"]`);
                if (error) error.textContent = '';
            });
            input.addEventListener('invalid', () => {
                const text = input.validity.typeMismatch && input.type === 'email' ? ui.invalid_email : input.validity.tooLong ? ui.too_long : ui.required;
                input.setCustomValidity(text);
                input.setAttribute('aria-invalid', 'true');
            });
        });
        form.addEventListener('submit', async event => {
            event.preventDefault();
            if (form.dataset.preview === 'true') { status.textContent = ui.preview_form; return; }
            form.querySelectorAll('[data-field-error]').forEach(node => { node.textContent = ''; });
            form.querySelectorAll('[aria-invalid]').forEach(node => node.removeAttribute('aria-invalid'));
            status.textContent = '';
            submit.disabled = true;
            submit.textContent = ui.sending;
            form.setAttribute('aria-busy','true');
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 20000);
            try {
                const response = await fetch(form.action, {method:'POST', body:new FormData(form), credentials:'same-origin', headers:{'Accept':'application/json'}, signal:controller.signal});
                const contentType = response.headers.get('content-type') || '';
                const data = contentType.includes('application/json') ? await response.json() : {};
                if (!response.ok) {
                    if (response.status === 422 && data.errors) {
                        let focused = false;
                        Object.entries(data.errors).forEach(([key, errors]) => {
                            const input = form.elements.namedItem(key);
                            const message = Array.isArray(errors) ? errors[0] : String(errors);
                            const node = form.querySelector(`[data-field-error="${CSS.escape(key)}"]`);
                            if (node) node.textContent = message;
                            if (input && typeof input.focus === 'function') {
                                input.setAttribute('aria-invalid','true');
                                if (!focused) { input.focus(); focused = true; }
                            }
                        });
                    }
                    throw new Error(ui.try_again);
                }
                if (typeof data.reference !== 'string' || data.booking_confirmed !== false) throw new Error(ui.try_again);
                status.textContent = `${ui.received} ${ui.reference}: ${data.reference}`;
                status.setAttribute('tabindex','-1');
                status.focus();
                form.querySelectorAll('input,textarea,select').forEach(input => { input.disabled = true; });
                restoreButton();
                submit.disabled = true;
            } catch {
                status.textContent = ui.try_again;
                submit.disabled = false;
                restoreButton();
            } finally {
                clearTimeout(timeout);
                form.removeAttribute('aria-busy');
            }
        });
    });

    document.querySelectorAll('[data-l4-services]').forEach(section => {
        const choices = Array.from(section.querySelectorAll('[data-l4-select]'));
        const scenes = Array.from(section.querySelectorAll('[data-l4-visual]'));
        if (choices.length !== scenes.length || !choices.length) return;
        const select = index => {
            choices.forEach((control, i) => {
                control.setAttribute('aria-pressed', String(i === index));
                control.closest('.l4-service-row')?.classList.toggle('is-active', i === index);
            });
            scenes.forEach((scene, i) => { scene.hidden = i !== index; });
        };
        choices.forEach((control, i) => {
            control.addEventListener('click', () => select(i));
            control.addEventListener('focus', () => select(i));
        });
        select(0);
    });
})();
