# Current validation: Frontend 04.1

Run `php tests/domain-checks.php` for dependency-free domain and business-rule checks.

The current frontend audit scripts are under `tests/frontend-04/`. They require the generated static preview and, for browser checks, Python Playwright plus Chromium. The shared inline preview renderer is in `tests/frontend-03/render.py`; set `PYTHONPATH=tests/frontend-03` when invoking scripts from the source root. Use short page shards for the viewport matrix.

`tests/Feature/` contains Laravel/MySQL test methods that remain **unexecuted** until the application dependencies are resolved and an isolated test MySQL database is available. Never run these against the live database.

View `docs/RELEASE_AUDIT_04_1.md` for the current checks, production blockers and evidence boundaries.
