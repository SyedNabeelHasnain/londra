from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path

from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser()
parser.add_argument('--preview', required=True, type=Path)
parser.add_argument('--chromium', default='/usr/bin/chromium')
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
preview = args.preview.resolve()
encoded: dict[str, str] = {}


def inline(path: Path) -> str:
    doc = BeautifulSoup(path.read_text(encoding='utf-8'), 'html.parser')
    for tag in list(doc.select('link[rel="stylesheet"]')):
        replacement = doc.new_tag('style')
        replacement.string = (preview / tag['href']).read_text()
        tag.replace_with(replacement)
    for script in list(doc.select('script[src]')):
        name = script['src']
        script.string = (preview / name).read_text()
        script.attrs.pop('src', None)
        script.attrs.pop('defer', None)
        if name.endswith('site.js'):
            script.extract()
            doc.body.append(script)
    for image in doc.select('img'):
        name = image['src']
        if name not in encoded:
            file = preview / name
            mime = 'webp' if file.suffix == '.webp' else 'png'
            encoded[name] = f'data:image/{mime};base64,' + base64.b64encode(file.read_bytes()).decode()
        image['src'] = encoded[name]
        image['loading'] = 'eager'
        image.attrs.pop('srcset', None)
    return str(doc)


report = {
    'method': 'Chromium set_content using generated PHP views with local CSS, JS and images inlined. File navigation is blocked by environment policy. Not a Laravel HTTP/runtime test.',
    'cases': [],
    'failures': [],
}
with sync_playwright() as playwright:
    browser = playwright.chromium.launch(executable_path=args.chromium, headless=True, args=['--no-sandbox'])
    report['browser'] = browser.version
    for path in sorted(preview.glob('*--*.html')):
        html = inline(path)
        for width in (320, 1440):
            page = browser.new_page(viewport={'width': width, 'height': 900}, device_scale_factor=1)
            errors: list[str] = []
            page.on('pageerror', lambda error, bucket=errors: bucket.append(str(error)))
            page.set_content(html, wait_until='load')
            page.evaluate('Promise.all(Array.from(document.images, x => x.decode().catch(() => null)))')
            values = page.evaluate('''() => ({
                scrollWidth: document.documentElement.scrollWidth,
                viewportWidth: innerWidth,
                h1: document.querySelectorAll('h1').length,
                missingImages: Array.from(document.images).filter(x => !x.complete || !x.naturalWidth).length,
                theme: document.documentElement.dataset.theme,
                language: document.documentElement.lang,
                activeSubmitButtons: Array.from(document.querySelectorAll('form[data-enquiry-form] button[type=submit]')).filter(x => !x.disabled).length
            })''')
            failures = []
            if values['scrollWidth'] > width + 1:
                failures.append('horizontal overflow')
            if values['h1'] != 1:
                failures.append('H1 count')
            if values['missingImages'] != 0:
                failures.append('missing image')
            if values['theme'] != 'dark':
                failures.append('default theme')
            if values['language'] != path.name.split('--')[0]:
                failures.append('language')
            if values['activeSubmitButtons'] != 0:
                failures.append('preview form enabled')
            if errors:
                failures.extend(errors)
            page.locator('[data-theme-toggle]').click()
            if page.locator('html').get_attribute('data-theme') != 'light':
                failures.append('light mode toggle')
            light_width = page.evaluate('document.documentElement.scrollWidth')
            if light_width > width + 1:
                failures.append('light mode overflow')
            case = {'file': path.name, 'width': width, 'dark': values, 'lightWidth': light_width, 'javascriptErrors': errors, 'passed': not failures}
            report['cases'].append(case)
            if failures:
                report['failures'].append({'file': path.name, 'width': width, 'issues': failures})
            page.close()
        (root / 'reports/browser-all-pages.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
        if len(report['cases']) % 32 == 0:
            print(f"Checked {len(report['cases'])} page/viewport cases", flush=True)
    browser.close()
report['case_count'] = len(report['cases'])
(root / 'reports/browser-all-pages.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'cases': report['case_count'], 'failures': report['failures']}, indent=2, ensure_ascii=False))
raise SystemExit(1 if report['failures'] else 0)
