<?php
declare(strict_types=1);
namespace Tests\Feature;
use App\Jobs\SendInquiryEmail;
use App\Models\{Inquiry,NotificationDelivery};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;
final class DeliveryTest extends TestCase
{
    use RefreshDatabase;
    public function test_disabled_smtp_keeps_a_pending_delivery_without_sending(): void
    {
        Mail::fake();config(['londra.send_notifications'=>false]);
        $inquiry=Inquiry::create(['reference'=>'LT-SYNTHETIC','submission_key'=>str_repeat('1',64),'payload_fingerprint'=>str_repeat('2',64),'type'=>'booking','locale'=>'es','name'=>'Synthetic Test','email'=>'client@example.test','email_lookup'=>str_repeat('3',64),'phone'=>'+440000000000','privacy_notice_at'=>now(),'privacy_notice_version'=>'test-only']);
        $delivery=NotificationDelivery::create(['inquiry_id'=>$inquiry->id,'kind'=>'customer','status'=>'queued']);
        app()->call([new SendInquiryEmail($delivery->id),'handle']);
        $this->assertSame('pending',$delivery->fresh()->status);Mail::assertNothingSent();
    }
}
