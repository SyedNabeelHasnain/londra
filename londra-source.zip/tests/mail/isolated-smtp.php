<?php
declare(strict_types=1);
namespace PHPMailer\PHPMailer {
    class PHPMailer
    {
        public const ENCRYPTION_SMTPS = 'ssl';
        public const ENCRYPTION_STARTTLS = 'tls';
        public const CHARSET_UTF8 = 'UTF-8';
        public const ENCODING_BASE64 = 'base64';
        public static array $sent = [];
        public string $Host = '';
        public int $Port = 0;
        public bool $SMTPAuth = false;
        public string $Username = '';
        public string $Password = '';
        public string $SMTPSecure = '';
        public bool $SMTPAutoTLS = true;
        public int $SMTPDebug = 0;
        public int $Timeout = 0;
        public bool $SMTPKeepAlive = true;
        public array $SMTPOptions = [];
        public string $CharSet = '';
        public string $Encoding = '';
        public string $Subject = '';
        public string $Body = '';
        public string $AltBody = '';
        public array $recipients = [];
        public array $replies = [];
        public array $sender = [];
        public bool $html = false;
        public function __construct(bool $exceptions = false) {}
        public function isSMTP(): void {}
        public function setFrom(string $address, string $name = ''): void { $this->sender = [$address, $name]; }
        public function addAddress(string $address): void { $this->recipients[] = $address; }
        public function addReplyTo(string $address, string $name = ''): void { $this->replies[] = [$address, $name]; }
        public function isHTML(bool $flag): void { $this->html = $flag; }
        public function send(): void { self::$sent[] = clone $this; }
    }
}
namespace App\Models {
    class Inquiry
    {
        public function __construct(
            public string $type = 'booking',
            public string $locale = 'it',
            public string $email = 'guest@example.test',
            public string $name = 'Test Guest',
            public string $reference = 'LT-TEST',
        ) {}
    }
}
namespace {
    function config(string $key, mixed $default = null): mixed
    {
        return $GLOBALS['mail_test_config'][$key] ?? $default;
    }
    function __(string $key, array $vars = [], string|null $locale = null): string
    {
        return ($locale ?? 'en').'::'.$key;
    }
    function view(string $name, array $vars = []): object
    {
        return new class($name, $vars) {
            public function __construct(private string $name, private array $vars) {}
            public function render(): string { return 'VIEW:'.$this->name.';KIND:'.$this->vars['kind'].';LOCALE:'.$this->vars['locale']; }
        };
    }
    require dirname(__DIR__, 2).'/app/Services/InquirySmtpSender.php';
    $GLOBALS['mail_test_config'] = [
        'mail.mailers.smtp' => ['host' => 'smtp.example.test', 'port' => 465, 'username' => 'admin@example.test', 'password' => 'dummy-only'],
        'mail.from.address' => 'admin@example.test',
        'mail.from.name' => 'Londra Transfers',
        'mail.reply_to.address' => 'info@example.test',
        'mail.reply_to.name' => 'Londra Transfers',
        'londra.contact.email' => 'info@example.test',
    ];
    $assertions = 0;
    function check(bool $result, string $label): void
    {
        global $assertions;
        $assertions++;
        if (!$result) { throw new \RuntimeException('Failed: '.$label); }
    }
    $service = new \App\Services\InquirySmtpSender();
    $inquiry = new \App\Models\Inquiry();
    $service->send($inquiry, 'customer');
    $mail = \PHPMailer\PHPMailer\PHPMailer::$sent[0];
    check($mail->Host === 'smtp.example.test' && $mail->Port === 465, 'server and port');
    check($mail->SMTPAuth && $mail->SMTPSecure === 'ssl', 'SSL authentication');
    check(!$mail->SMTPAutoTLS && $mail->SMTPDebug === 0, 'explicit encryption and no debug');
    check($mail->SMTPOptions['ssl']['verify_peer'] && $mail->SMTPOptions['ssl']['verify_peer_name'] && !$mail->SMTPOptions['ssl']['allow_self_signed'], 'certificate checks');
    check($mail->CharSet === 'UTF-8' && $mail->Encoding === 'base64', 'unicode transport');
    check($mail->sender[0] === 'admin@example.test', 'authenticated sender');
    check($mail->recipients === ['guest@example.test'], 'customer address');
    check($mail->replies[0][0] === 'info@example.test', 'reply-to business');
    check(str_contains($mail->Body, 'KIND:customer;LOCALE:it'), 'italian HTML');
    check(str_contains($mail->AltBody, 'KIND:customer;LOCALE:it'), 'italian text');
    $service->send($inquiry, 'admin');
    $mail = \PHPMailer\PHPMailer\PHPMailer::$sent[1];
    check($mail->recipients === ['info@example.test'], 'admin goes to business inbox');
    check($mail->replies[0][0] === 'guest@example.test', 'admin reply goes to client');
    check(str_contains($mail->Body, 'KIND:admin;LOCALE:en'), 'english admin');
    $GLOBALS['mail_test_config']['mail.mailers.smtp']['port'] = 587;
    $service->send(new \App\Models\Inquiry(locale: 'es'), 'customer');
    $mail = \PHPMailer\PHPMailer\PHPMailer::$sent[2];
    check($mail->SMTPSecure === 'tls' && $mail->Port === 587, 'STARTTLS mode');
    check(str_contains($mail->Body, 'KIND:customer;LOCALE:es'), 'spanish HTML');
    $GLOBALS['mail_test_config']['mail.from.address'] = 'different@example.test';
    try { $service->send($inquiry, 'customer'); throw new \RuntimeException('Mismatch accepted'); }
    catch (\RuntimeException $e) { check($e->getMessage() === 'SMTP From address must match the authenticated mailbox.', 'sender mismatch rejected'); }
    $GLOBALS['mail_test_config']['mail.from.address'] = 'admin@example.test';
    $GLOBALS['mail_test_config']['mail.mailers.smtp']['password'] = '';
    try { $service->send($inquiry, 'customer'); throw new \RuntimeException('Missing password accepted'); }
    catch (\RuntimeException $e) { check($e->getMessage() === 'SMTP configuration is incomplete.', 'empty credentials rejected'); }
    $GLOBALS['mail_test_config']['mail.mailers.smtp']['password'] = 'dummy-only';
    try { $service->send($inquiry, 'other'); throw new \RuntimeException('Unknown kind accepted'); }
    catch (\RuntimeException $e) { check($e->getMessage() === 'Unknown notification category.', 'unknown notification rejected'); }
    check(count(\PHPMailer\PHPMailer\PHPMailer::$sent) === 3, 'no extra sends');
    echo 'PASS '.$assertions.' isolated mail-transport assertions; no network, database or real email used.'.PHP_EOL;
}
