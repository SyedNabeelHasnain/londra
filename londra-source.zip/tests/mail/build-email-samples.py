from pathlib import Path
import json
import re
from html import escape
from bs4 import BeautifulSoup
root=Path(__file__).resolve().parents[2]
source=(root/'resources/views/emails/inquiry-received.blade.php').read_text()
out=root/'reports'/'mail-samples'
out.mkdir(exist_ok=True, parents=True)
for locale in ('en','it','es'):
    translations=json.loads((root/'lang'/locale/'ui.json').read_text())
    for kind in ('customer','admin'):
        text=source
        active=[]
        lines=[]
        for line in text.splitlines():
            stripped=line.strip()
            if stripped.startswith('@if ('):
                expr=stripped[4:-1]
                if "$kind === 'customer'" in expr: val=kind=='customer'
                elif "$kind === 'admin'" in expr: val=kind=='admin'
                else: raise RuntimeError('Unexpected email condition: '+expr)
                active.append(val)
                continue
            if stripped == '@else':
                active[-1]=not active[-1]
                continue
            if stripped == '@endif':
                active.pop()
                continue
            if all(active): lines.append(line)
        text='\n'.join(lines)
        sample={
            'locale':locale,
            'kind':kind,
            'reference':'LT-EXAMPLE-2026',
            'email':'guest@example.test',
            'type':'booking',
            'id':101,
        }
        subs={
            '$locale': locale,
            "$kind === 'admin' ? 'New client enquiry' : __('ui.email_subject', [], $locale)": 'New client enquiry' if kind=='admin' else translations['email_subject'],
            "__('ui.email_greeting', [], $locale)": translations['email_greeting'],
            "__('ui.email_body', [], $locale)": translations['email_body'],
            "__('ui.email_disclaimer', [], $locale)": translations['email_disclaimer'],
            "__('ui.reference', [], $locale)": translations['reference'],
            "$inquiry->reference": sample['reference'],
            "strtoupper($inquiry->locale)": locale.upper(),
            "$inquiry->type === 'contact' ? 'contact' : 'journey'":'journey',
            "url('/admin/inquiries/'.$inquiry->id.'/edit')": 'https://londratransfers.co.uk/admin/inquiries/101/edit',
            "$kind === 'admin' ? 'Enquiry reference' : __('ui.reference', [], $locale)": 'Enquiry reference' if kind=='admin' else translations['reference'],
        }
        pattern=r'{{\s*(.*?)\s*}}'
        def translate(match):
            expr=match.group(1).strip()
            if expr not in subs: raise RuntimeError('Unrecognised Blade expression '+expr)
            return escape(subs[expr])
        text=re.sub(pattern,translate,text)
        soup=BeautifulSoup(text,'html.parser')
        assert len(soup.find_all('table'))>=3
        assert not soup.find_all('script')
        assert '{' not in soup.get_text() or '{{' not in text
        assert 'LT-EXAMPLE-2026' in soup.get_text()
        assert all(color in text for color in ('#000000','#FFFFFF','#F7F7F5','#BDA177','#F1ECD9'))
        (out/f'{kind}-{locale}.html').write_text(text)
        print(f'PASS {kind}-{locale}: {len(soup.find_all("table"))} tables, receipt and brand palette, no scripts')
