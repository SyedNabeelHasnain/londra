import hashlib,json,re,subprocess,sys
from pathlib import Path
from bs4 import BeautifulSoup
root=Path(__file__).resolve().parents[2]
results=[]
def check(name, ok, details=None):
    results.append({'name':name,'pass':bool(ok),'details':details})
manifest=json.loads((root/'public/build/manifest.json').read_text())
for logical,source in [('resources/css/app.css','resources/css/site.css'),('resources/js/app.js','resources/js/app.js')]:
    entry=manifest.get(logical,{})
    output=root/'public/build'/entry.get('file','missing')
    check('staged frontend asset '+logical, output.is_file() and output.read_bytes()==(root/source).read_bytes())
check('dependencies are explicitly not marked installed',not (root/'vendor/autoload.php').exists())
composer=json.loads((root/'composer.json').read_text())
check('PHPMailer 7.1 declared',composer['require'].get('phpmailer/phpmailer')=='^7.1.1')
check('PHP 8.5 requested',composer['require'].get('php')=='~8.5.4')
check('live password never stored in sample env',all(x in (root/'.env.example').read_text() for x in ('DB_PASSWORD=""','MAIL_PASSWORD=""')))
check('Zoho host, secure port, authenticated sender template',all(x in (root/'.env.example').read_text() for x in ('MAIL_HOST=smtp.zoho.com','MAIL_PORT=465','MAIL_FROM_ADDRESS=admin@londratransfers.co.uk')))
check('SMTP debug disabled by code', '$mail->SMTPDebug = 0;' in (root/'app/Services/InquirySmtpSender.php').read_text())
check('strict certificate validation in mail service',all(x in (root/'app/Services/InquirySmtpSender.php').read_text() for x in ("'verify_peer' => true", "'verify_peer_name' => true", "'allow_self_signed' => false")))
check('no plaintext credentials or live env in app',not (root/'.env').exists())
check('private/public builder is syntax-valid',subprocess.run(['bash','-n',str(root/'tools/build-private-release.sh')],capture_output=True).returncode==0)
php_files=list(root.rglob('*.php'))
failed=[]
for f in php_files:
    result=subprocess.run(['php','-l',str(f)],capture_output=True,text=True)
    if result.returncode:failed.append(str(f.relative_to(root)))
check('PHP lint',not failed,{'files':len(php_files),'failures':failed})
cmd=subprocess.run(['php',str(root/'tests/mail/isolated-smtp.php')],capture_output=True,text=True)
check('isolated PHPMailer service tests',cmd.returncode==0 and 'PASS 19' in cmd.stdout,cmd.stdout.strip())
preview=Path('/mnt/data/londra_production_work/RENDERED_PREVIEW')
pages=list(preview.glob('??--*.html'))
check('all public language previews generated',len(pages)==96,len(pages))
for email in sorted((root/'reports/mail-samples').glob('*.html')):
    soup=BeautifulSoup(email.read_text(),'html.parser')
    check('email markup '+email.stem,len(soup.select('table'))>=3 and bool(soup.select('h1')) and not soup.select('script') and soup.html.get('lang') in ('en','it','es'))
report={'scope':'Londra Transfers integration 05 dependency-free static/mocked tests','passed':sum(c['pass'] for c in results),'failed':sum(not c['pass'] for c in results),'checks':results,'production_certified':False,'live_mysql_tested':False,'live_smtp_tested':False,'laravel_runtime_tested':False}
out=root/'reports/INTEGRATION_05_QA.json'
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
for c in results:
    if not c['pass']:print('FAIL',c['name'],c['details'])
sys.exit(int(report['failed']>0))
