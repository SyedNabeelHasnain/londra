import os,json
from pathlib import Path
from playwright.sync_api import sync_playwright
from render import inline,ROOT
checks=[]
def verify(name,condition,details=None):
    checks.append({'check':name,'passed':bool(condition),'detail':details})
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('LONDRA_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
    for lc in ['en','it','es']:
        for route in ['home','fleet','contact','services','diplomatic-transfers']:
            for width in [320,1440]:
                page=browser.new_page(viewport={'width':width,'height':844 if width<600 else 1000},reduced_motion='reduce')
                errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.set_content(inline(ROOT/f'{lc}--{route}.html'),wait_until='load')
                page.add_style_tag(content="*{font-family:Arial,sans-serif!important}h1,h2,h3,em,.serif{font-family:'Times New Roman',serif!important}")
                data=page.evaluate('''()=>({width:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth,clipped:[...document.querySelectorAll('main h1, main h2, main h3')].filter(x=>x.getClientRects().length && x.scrollWidth>x.clientWidth+2).map(x=>x.innerText.slice(0,80))})''')
                verify(f'{lc}/{route}/{width}: fallback fonts',data['scroll']<=data['width']+1 and not data['clipped'] and not errors,{'data':data,'errors':errors})
                page.close()
    for lc in ['en','it','es']:
        page=browser.new_page(viewport={'width':720,'height':900},reduced_motion='reduce')
        page.set_content(inline(ROOT/f'{lc}--home.html'),wait_until='load')
        verify(f'{lc}: 720px reflow',page.evaluate('document.documentElement.scrollWidth<=document.documentElement.clientWidth+1'))
        page.close()
    browser.close()
out={'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks}
location=Path(__file__).resolve().parents[2]/'reports/frontend-04/resilience.json'
location.write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('fallback/reflow:',out['passed'],'passed;',out['failed'],'failed')
if out['failed']:print([x for x in checks if not x['passed']]);raise SystemExit(1)
