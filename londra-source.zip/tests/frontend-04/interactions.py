import sys,json,os
from pathlib import Path
from playwright.sync_api import sync_playwright
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'frontend-03'))
from render import ROOT,inline
records=[]
def verify(label,truth,detail=None):
 records.append({'case':label,'passed':bool(truth),'detail':detail if detail is not None else ''})
 if not truth:print('FAIL',label,detail,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ.get('LONDRA_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 for loc in ([sys.argv[1]] if len(sys.argv)>1 else ['en','it','es']):
  for width in [390,1440]:
   page=browser.new_page(viewport={'width':width,'height':900},reduced_motion='reduce')
   errors=[]
   page.on('pageerror',lambda e:errors.append(str(e)))
   page.set_content(inline(ROOT/f'{loc}--home.html'),wait_until='load')
   verify(f'{loc}/{width}: initial theme',page.evaluate('document.documentElement.dataset.theme')=='dark')
   verify(f'{loc}/{width}: welcome photograph',page.locator('.l4-hero-composition img').first.evaluate('(x)=>x.naturalWidth>0 && x.getBoundingClientRect().width>0'))
   page.locator('[data-l4-select="2"]').click()
   verify(f'{loc}/{width}: service switch',page.locator('[data-l4-select="2"]').get_attribute('aria-pressed')=='true' and not page.locator('[data-l4-visual="2"]').evaluate('(x)=>x.hidden'))
   verify(f'{loc}/{width}: service count',page.locator('[data-l4-select]').count()==4)
   page.locator('.l4-fleet-block [data-tab="2"]').first.click()
   verify(f'{loc}/{width}: fleet tab keyboard semantics',page.locator('.l4-fleet-block [data-tab="2"]').first.get_attribute('aria-selected')=='true' and page.locator('.l4-fleet-block [data-panel="2"]').first.is_visible())
   verify(f'{loc}/{width}: guest count',page.locator('.l4-fleet-block [data-panel="2"] .capacity').first.inner_text().strip().replace('\n',' ').find('7')>=0)
   trigger=page.locator('.l4-hero-actions [data-open-enquiry]').first
   trigger.click()
   verify(f'{loc}/{width}: enquiry drawer',page.locator('#enquiry-dialog').evaluate('(x)=>x.open'))
   verify(f'{loc}/{width}: not bookable',page.locator('#enquiry-dialog [type="submit"]').is_disabled())
   page.keyboard.press('Escape')
   verify(f'{loc}/{width}: dialog Escape',not page.locator('#enquiry-dialog').evaluate('(x)=>x.open'))
   verify(f'{loc}/{width}: focus restored',trigger.evaluate('(x)=>document.activeElement===x'))
   page.locator('[data-open-navigation]').first.click()
   verify(f'{loc}/{width}: navigation dialog',page.locator('#navigation-dialog').evaluate('(x)=>x.open'))
   page.locator('[data-close-navigation]').click()
   verify(f'{loc}/{width}: navigation close',not page.locator('#navigation-dialog').evaluate('(x)=>x.open'))
   page.locator('[data-theme-toggle]').click()
   verify(f'{loc}/{width}: light theme',page.evaluate('document.documentElement.dataset.theme')=='light')
   verify(f'{loc}/{width}: no script errors',not errors,errors)
   verify(f'{loc}/{width}: no horizontal scroll',page.evaluate('document.documentElement.scrollWidth<=document.documentElement.clientWidth+1'))
   page.close()
 for loc in ([sys.argv[1]] if len(sys.argv)>1 else ['en','it','es']):
  page=browser.new_page(viewport={'width':390,'height':844},reduced_motion='reduce')
  page.set_content(inline(ROOT/f'{loc}--fleet.html'),wait_until='load')
  verify(f'{loc}: four vehicle categories',page.locator('.l4-collection-fleet .fleet-tab').count()==4)
  guest_tokens={'en':'guests','it':'ospiti','es':'viajeros'}
  verify(f'{loc}: considerate language',guest_tokens[loc] in page.locator('.l4-collection-fleet').inner_text())
  page.locator('[data-open-compare]').first.click()
  verify(f'{loc}: comparison opens',page.locator('#compare-dialog').evaluate('(x)=>x.open'))
  page.locator('[data-close-compare]').click()
  page.locator('.fleet-panel:not([hidden]) [data-open-gallery]').first.click()
  verify(f'{loc}: photograph gallery opens',page.locator('#gallery-dialog').evaluate('(x)=>x.open'))
  verify(f'{loc}: gallery includes photograph',page.locator('#gallery-dialog img').first.evaluate('(x)=>x.naturalWidth>0'))
  page.keyboard.press('Escape')
  page.close()
 browser.close()
out={'passed':sum(r['passed'] for r in records),'failed':sum(not r['passed'] for r in records),'cases':records}
report=Path(__file__).resolve().parents[2]/'reports/frontend-04'
report.mkdir(parents=True,exist_ok=True)
(report/('interactions-'+(sys.argv[1] if len(sys.argv)>1 else 'all')+'.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('interaction checks',out['passed'],'passed;',out['failed'],'failed')
if out['failed']:sys.exit(1)
