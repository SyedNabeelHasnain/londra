import os
from pathlib import Path
from playwright.sync_api import sync_playwright
from render import inline,ROOT
out=Path('/mnt/data')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('LONDRA_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 def capture(name,route,width,height=960,theme='dark',full=False,action=None):
  page=b.new_page(viewport={'width':width,'height':height},device_scale_factor=1,reduced_motion='reduce')
  page.set_content(inline(ROOT/route),wait_until='load')
  page.evaluate('Promise.all(Array.from(document.images,x=>x.decode().catch(()=>null)))')
  if theme=='light':page.locator('[data-theme-toggle]').click()
  if action:page.locator(action).first.click()
  page.wait_for_timeout(120)
  page.screenshot(path=str(out/name),full_page=full,animations='disabled')
  print(name, (out/name).stat().st_size)
  page.close()
 capture('Londra_Frontend_04_Desktop.png','en--home.html',1440)
 capture('Londra_Frontend_04_Mobile.png','en--home.html',390,844)
 capture('Londra_Frontend_04_Desktop_Full.png','en--home.html',1440,900,full=True)
 capture('Londra_Frontend_04_Light.png','en--home.html',1440,theme='light')
 capture('Londra_Frontend_04_Fleet.png','en--fleet.html',1440)
 capture('Londra_Frontend_04_Service.png','en--chauffeur-service.html',1440)
 capture('Londra_Frontend_04_Italian_Mobile.png','it--home.html',390,844)
 capture('Londra_Frontend_04_Spanish_Contact.png','es--contact.html',1440)
 capture('Londra_Frontend_04_Enquiry.png','en--home.html',1440,action='.l4-hero-actions [data-open-enquiry]')
 capture('Londra_Frontend_04_Comparison.png','en--fleet.html',1440,action='[data-open-compare]')
 b.close()
