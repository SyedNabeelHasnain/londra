import json,time,sys,os
from pathlib import Path
from playwright.sync_api import sync_playwright
from render import inline,ROOT
OUT=Path(__file__).resolve().parents[2]/'reports/frontend-04'
start=int(sys.argv[1]) if len(sys.argv)>1 else 0
stop=int(sys.argv[2]) if len(sys.argv)>2 else 96
checks=[];faults=[];started=time.time()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ.get('LONDRA_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 version=browser.version
 for n,path in enumerate(sorted(ROOT.glob('??--*.html'))[start:stop],start=start):
  page=browser.new_page(viewport={'width':1440,'height':1000},reduced_motion='reduce')
  page.set_default_timeout(8000)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(inline(path),wait_until='load')
  page.evaluate('Promise.all(Array.from(document.images,x=>x.decode().catch(()=>null)))')
  for width in (360,768,1440):
   page.set_viewport_size({'width':width,'height':844 if width<600 else 1000})
   page.evaluate('window.scrollTo({top:0,behavior:"instant"})')
   for theme in ('dark','light'):
    if page.evaluate('document.documentElement.dataset.theme')!=theme:page.locator('[data-theme-toggle]').click()
    page.wait_for_timeout(45)
    state=page.evaluate('''()=>{
     const vw=document.documentElement.clientWidth;
     const visible=e=>!!e.getClientRects().length && getComputedStyle(e).visibility!=='hidden' && !e.closest('[hidden]');
     const spill=[...document.querySelectorAll('main h1,main h2,main h3,main p,main a,main button,.masthead a,.masthead button')].filter(visible).map(e=>({text:e.textContent.trim().slice(0,70),left:e.getBoundingClientRect().left,right:e.getBoundingClientRect().right,tag:e.tagName,cl:e.className})).filter(e=>e.left < -1 || e.right > vw+1);
     return {viewport:vw,documentWidth:document.documentElement.scrollWidth,missingImages:[...document.images].filter(x=>!x.complete||!x.naturalWidth).length,h1:document.querySelectorAll('h1').length,previewButtons:[...document.querySelectorAll('[type="submit"]')].every(x=>x.disabled),spill};
    }''')
    okay=state['documentWidth']<=state['viewport']+1 and state['missingImages']==0 and state['h1']==1 and state['previewButtons'] and not state['spill'] and not errors
    result={'page':path.name,'width':width,'theme':theme,'pass':okay,**state,'jsErrors':list(errors)}
    checks.append(result)
    if not okay:faults.append(result)
  page.close()
  if n%8==0:print(f'{n+1}/96 pages; cases {len(checks)}; failures {len(faults)}; elapsed {time.time()-started:.0f}s',flush=True)
 browser.close()
report={'method':'Chromium set_content with exact local HTML/CSS/JS and inlined assets, fresh page contexts; reduced motion for stable geometry; not HTTP/Laravel execution','browser':version,'cases':len(checks),'passed':len(checks)-len(faults),'failed':len(faults),'elapsed_seconds':round(time.time()-started,1),'results':checks}
(OUT/f'browser-matrix-{start}-{stop}.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2));print(json.dumps(faults[:12],indent=2,ensure_ascii=False))
