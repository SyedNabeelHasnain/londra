import json,os
from pathlib import Path
from playwright.sync_api import sync_playwright
from render import ROOT,inline
checks=[]
def brightness(rgb):
    parts=[v/255 for v in rgb]
    parts=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in parts]
    return sum(a*b for a,b in zip(parts,[.2126,.7152,.0722]))
def contrast(a,b):
    hi,lo=sorted([brightness(a),brightness(b)],reverse=True)
    return (hi+.05)/(lo+.05)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('LONDRA_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':960})
    for route in ['en--home.html','en--fleet.html','en--contact.html']:
        page.set_content(inline(ROOT/route),wait_until='load')
        for theme in ['dark','light']:
            if page.evaluate('document.documentElement.dataset.theme') != theme:page.locator('[data-theme-toggle]').click()
            selectors=['.l4-hero-left h1','.l4-hero-lead','.l4-intro-text h2','.l4-intro-text>p','.l4-services-list .l4-service-row:first-child strong','.l4-fleet-block .fleet-copy h3','.l4-attention-copy h2','.l4-attention-copy>p:not(.l4-kicker)','.l4-airport-copy h2','.l4-airport-copy>p:not(.l4-kicker)','.l4-contact-editorial h1','.l4-contact-paper label','.site-footer nav a']
            for selector in selectors:
                loc=page.locator(selector).first
                if not loc.count() or not loc.is_visible():continue
                data=loc.evaluate(r'''el=>{let e=el;let bg=null;const rgba=x=>{if(x.startsWith('color(srgb ')){const m=x.match(/color\(srgb\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)/);return m?[...m.slice(1,4).map(v=>Number(v)*255),1]:null}const m=x.match(/[\d.]+/g);return m?m.map(Number):null};while(e){const s=getComputedStyle(e),a=rgba(s.backgroundColor);if(a && (a.length<4||a[3]>=.999)){bg=a.slice(0,3);break;}e=e.parentElement;}const s=getComputedStyle(el);return {fg:rgba(s.color)?.slice(0,3),bg:bg,font:parseFloat(s.fontSize),weight:parseInt(s.fontWeight)||400}}''')
                if not data['fg'] or not data['bg']:continue
                ratio=contrast(data['fg'],data['bg'])
                required=3 if data['font']>=24 or (data['font']>=18.66 and data['weight']>=700) else 4.5
                checks.append({'route':route,'theme':theme,'selector':selector,'contrast':round(ratio,2),'required':required,'passed':ratio>=required})
    browser.close()
out={'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,'scope':'Representative elements with an opaque ancestor surface; visual overlays and complete accessibility testing not covered.'}
(Path(__file__).resolve().parents[2]/'reports/frontend-04/contrast.json').write_text(json.dumps(out,indent=2))
print(out['passed'],out['failed'])
print([x for x in checks if not x['passed']])
if out['failed']:raise SystemExit(1)
