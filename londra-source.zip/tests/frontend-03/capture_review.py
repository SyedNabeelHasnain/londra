import os,json,io
from PIL import Image
from pathlib import Path
from playwright.sync_api import sync_playwright
from render import inline,ROOT
OUT=Path(os.environ.get('LONDRA_SCREENSHOT_DIR','/mnt/data/londra_frontend_03_shots'));OUT.mkdir(parents=True,exist_ok=True)
results=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('LONDRA_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 for name,file,width,theme,op in [
  ('showroom','en--home.html',1440,'dark','fleet'),
  ('comparison','en--home.html',1440,'dark','compare'),
  ('comparison-mobile','en--home.html',390,'dark','compare'),
  ('menu','en--home.html',1440,'dark','menu'),
  ('italian-menu','it--home.html',390,'dark','menu'),
  ('service','en--chauffeur-service.html',1440,'dark','full'),
  ('service-mobile','it--chauffeur-service.html',390,'light','full'),
  ('enquiry-mobile','es--home.html',390,'dark','enquiry'),
  ('second-scene','en--home.html',1440,'dark','scene'),
  ('gallery','en--fleet.html',1440,'dark','gallery')
 ]:
  page=b.new_page(viewport={'width':width,'height':1000 if width>600 else 844},device_scale_factor=1,is_mobile=width<600,has_touch=width<600,reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(inline(ROOT/file),wait_until='load')
  page.evaluate('Promise.all([...document.images].map(i=>i.decode().catch(()=>null)))')
  if theme=='light':page.locator('[data-theme-toggle]').click()
  if op=='fleet':
   box=page.locator('#fleet-showcase').bounding_box()
   rendered=Image.open(io.BytesIO(page.screenshot(full_page=True)))
   rendered.crop((round(box['x']),round(box['y']),round(box['x']+box['width']),round(box['y']+box['height']))).save(OUT/f'{name}.png')
  else:
   if op=='compare':page.locator('[data-open-compare]').click()
   if op=='menu':page.locator('[data-open-navigation]').click()
   if op=='enquiry':page.locator('.dock-enquire').click()
   if op=='scene':page.locator('[data-scene-select]').nth(1).click()
   if op=='gallery':page.locator('[data-panel]:not([hidden]) [data-open-gallery]').click()
   page.wait_for_timeout(100)
   page.screenshot(path=str(OUT/f'{name}.png'),full_page=op=='full')
  results.append({'file':name+'.png','source':file,'viewport':width,'theme':theme,'operation':op,'js_errors':errors})
  page.close()
 b.close()
(OUT/'capture-manifest.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
