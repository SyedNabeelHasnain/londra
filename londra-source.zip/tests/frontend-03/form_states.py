import json
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
from render import inline,ROOT
OUT=Path(__file__).resolve().parents[2]/'reports/frontend-03'
checks=[]
def check(name,value):checks.append({'check':name,'pass':bool(value)})
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('LONDRA_CHROMIUM', '/usr/bin/chromium'),headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000})
 for lc in ('en','it','es'):
  def setup():
   page.set_content(inline(ROOT/f'{lc}--enquiry.html'),wait_until='load')
   page.locator('.contact-form-wrap form').evaluate('form=>{form.dataset.preview="false";form.querySelector("[type=submit]").disabled=false}')
   form=page.locator('.contact-form-wrap form');form.locator('[name=name]').fill('Test Visitor');form.locator('[name=email]').fill('test@example.invalid');form.locator('[name=phone]').fill('+44 7000 000000');return form
  form=setup()
  form.locator('[name=email]').fill('not-an-email');form.locator('[type=submit]').click()
  check(lc+': native invalid-email control flags error',form.locator('[name=email]').evaluate('e=>e.validity.typeMismatch && e.getAttribute("aria-invalid")==="true"'))
  form.locator('[name=email]').fill('test@example.invalid')
  page.evaluate('() => {window.fetch=async()=>({ok:false,status:422,headers:{get:()=>"application/json"},json:async()=>({errors:{phone:["Validation response for test"]}})});}')
  form.locator('[type=submit]').click();page.wait_for_timeout(50)
  check(lc+': server field errors reflected accessibly',form.locator('[name=phone]').get_attribute('aria-invalid')=='true' and form.locator('[data-field-error=phone]').inner_text()=='Validation response for test')
  check(lc+': submit restored with icon after validation rejection',not form.locator('[type=submit]').is_disabled() and form.locator('[type=submit] svg').count()==1)
  form=setup();page.evaluate('() => {window.fetch=async()=>{throw new Error("simulated network rejection")};}')
  form.locator('[type=submit]').click();page.wait_for_timeout(50)
  check(lc+': network failure preserves input and permits retry',form.locator('[name=name]').input_value()=='Test Visitor' and not form.locator('[type=submit]').is_disabled() and bool(form.locator('[data-form-status]').inner_text()))
  form=setup();page.evaluate('() => {window.fetch=async()=>({ok:true,status:200,headers:{get:()=>"text/html"},json:async()=>({})});}')
  form.locator('[type=submit]').click();page.wait_for_timeout(50)
  check(lc+': unexpected HTML is not treated as success',not form.locator('[type=submit]').is_disabled() and not form.locator('[name=name]').is_disabled())
  form=setup();page.evaluate('() => {window.fetch=async()=>({ok:true,status:201,headers:{get:()=>"application/json"},json:async()=>({reference:"LT-TEST-ONLY",booking_confirmed:false})});}')
  form.locator('[type=submit]').click();page.wait_for_timeout(50)
  check(lc+': reference displayed for valid mocked success','LT-TEST-ONLY' in form.locator('[data-form-status]').inner_text())
  check(lc+': duplicate UI submission disabled after mocked success',form.locator('[type=submit]').is_disabled() and form.locator('[name=name]').is_disabled())
  check(lc+': success status receives focus',form.locator('[data-form-status]').evaluate('e=>e===document.activeElement'))
 b.close()
report={'method':'Client state tests using injected window.fetch stubs. No server, database, external request or email is exercised. Static delivered files remain submission-disabled.','passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'checks':checks}
(OUT/'form-states.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2));print([x for x in checks if not x['pass']])
