import json,os
from pathlib import Path
from playwright.sync_api import sync_playwright
from render import inline,ROOT
OUT=Path(__file__).resolve().parents[2]/'reports/frontend-03';checks=[]
def check(name,ok,detail=None):checks.append({'check':name,'pass':bool(ok),**({'detail':detail} if detail is not None else {})})
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('LONDRA_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 for lc in ('en','it','es'):
  for kind in ('home','contact','enquiry','services','fleet','diplomatic-transfers'):
   for width in (320,1440):
    page=b.new_page(viewport={'width':width,'height':844 if width<600 else 1000},reduced_motion='reduce')
    page.set_content(inline(ROOT/f'{lc}--{kind}.html'),wait_until='load')
    page.add_style_tag(content=":root{--serif:'Times New Roman',serif;--sans:Arial,sans-serif}")
    result=page.evaluate('''()=>({width:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth,heading:[...document.querySelectorAll('main h1,main h2,main h3')].filter(e=>e.getClientRects().length&&e.scrollWidth>e.clientWidth+2).map(e=>({text:e.textContent,client:e.clientWidth,scroll:e.scrollWidth}))})''')
    check(f'{lc}/{kind}/{width}: fallback-font reflow',result['scroll']<=result['width']+1 and not result['heading'],result)
    page.close()
 page=b.new_page(viewport={'width':720,'height':900},reduced_motion='reduce')
 page.set_content(inline(ROOT/'en--home.html'))
 check('720 CSS pixel viewport approximating 200% browser zoom on a 1440 display: no overflow',page.evaluate('document.documentElement.scrollWidth<=document.documentElement.clientWidth+1'))
 page.close()
 for name in ('en--home.html','it--home.html','es--home.html'):
  page=b.new_page(viewport={'width':1440,'height':1000},reduced_motion='no-preference')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(inline(ROOT/name));page.wait_for_timeout(850)
  page.locator('[data-scene-select]').nth(2).click();page.wait_for_timeout(900)
  check(name+': normal-motion scene settles correctly',page.locator('[data-scene-select]').nth(2).get_attribute('aria-pressed')=='true' and page.locator('[data-scene]:not([hidden])').count()==1)
  page.locator('.dock-enquire').click();page.wait_for_timeout(700)
  check(name+': normal-motion drawer settles within viewport',page.locator('#enquiry-dialog').evaluate('e=>{const r=e.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth+1&&e.open}'))
  page.keyboard.press('Escape');page.wait_for_timeout(300)
  page.locator('.journeys-section').scroll_into_view_if_needed();page.wait_for_timeout(850)
  check(name+': reveal animation retains readable content',page.locator('.journey-card').first.evaluate('e=>getComputedStyle(e).opacity==="1" && e.getBoundingClientRect().height>300'))
  check(name+': normal-motion path has no script error',not errors,errors)
  page.close()
 b.close()
report={'scope':'Representative Times New Roman/Arial fallback-font layout at 320/1440, a 720 CSS-pixel reflow case, and settled normal-motion interactions. This is not real Windows/iOS/Safari testing or browser zoom automation.','passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'checks':checks}
(OUT/'resilience.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2));print(json.dumps([x for x in checks if not x['pass']],indent=2))
