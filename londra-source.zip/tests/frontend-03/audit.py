import argparse,json,re,sys,hashlib,zipfile,subprocess
from pathlib import Path
import os
from collections import Counter
from urllib.parse import urlparse,unquote
from bs4 import BeautifulSoup
ROOT=Path(os.environ.get('LONDRA_PREVIEW_DIR', str(Path(__file__).resolve().parents[2]/'design-preview')))
SRC=Path(__file__).resolve().parents[2]
OUT=SRC/'reports/frontend-03';OUT.mkdir(parents=True,exist_ok=True)
results=[]
def check(name, ok, detail=None):
 results.append({'check':name,'pass':bool(ok),**({'detail':detail} if detail is not None else {})})
files=sorted(ROOT.glob('??--*.html'))
check('96 translated pages',len(files)==96,len(files))
for path in files:
 soup=BeautifulSoup(path.read_text(),'html.parser');tag=path.name
 check(tag+': h1',len(soup.select('h1'))==1)
 check(tag+': language',soup.html.get('lang')==tag[:2])
 check(tag+': noindex',soup.select_one('meta[name=robots]')['content'].startswith('noindex'))
 ids=[el['id'] for el in soup.select('[id]')];check(tag+': unique IDs',len(ids)==len(set(ids)))
 missing_refs=[]
 for el in soup.select('[aria-labelledby],[aria-describedby],[aria-controls]'):
  for attr in ['aria-labelledby','aria-describedby','aria-controls']:
   for ref in el.get(attr,'').split():
    if ref not in ids:missing_refs.append(ref)
 check(tag+': aria references',not missing_refs,missing_refs or None)
 labels={el.get('for') for el in soup.select('label[for]')}
 unlabelled=[el.get('name') for el in soup.select('input:not([type=hidden]),textarea,select') if el.get('id') not in labels and not el.get('aria-label')]
 check(tag+': labelled inputs',not unlabelled,unlabelled or None)
 missing=[];anchor_errors=[]
 for el in soup.select('a[href],script[src],link[rel=stylesheet],img[src]'):
  attr='href' if el.name in ('a','link') else 'src';url=el[attr];parsed=urlparse(url)
  if parsed.scheme or url.startswith('//'):continue
  if parsed.path:
   candidate=ROOT/unquote(parsed.path)
   if not candidate.is_file():missing.append(url)
  if parsed.fragment and not parsed.path and parsed.fragment not in ids:anchor_errors.append(url)
 check(tag+': local assets and links',not missing,missing or None)
 check(tag+': local anchor targets',not anchor_errors,anchor_errors or None)
 check(tag+': no active submissions',all(el.has_attr('disabled') for el in soup.select('[type=submit]')))
 check(tag+': all alt attributes',all(img.has_attr('alt') for img in soup.select('img')))
 check(tag+': declared dimensions',all(img.get('width') and img.get('height') for img in soup.select('img')))
 check(tag+': three equivalent-language links', {el.get('hreflang') for el in soup.select('.language-switch a')}=={'en','it','es'})
 check(tag+': schema parse',all(isinstance(json.loads(el.string),dict) for el in soup.select('script[type="application/ld+json"]')))
 check(tag+': no external runtime resources',not soup.select('script[src^="http"],link[rel="stylesheet"][href^="http"],img[src^="http"],iframe'))
 css=(SRC/'resources/css/site.css').read_text()
check('base hex palette locked', {s.upper() for s in re.findall(r'#[0-9a-fA-F]{6}\b',css)}=={'#000000','#0B0B0B','#FFFFFF','#F7F7F5','#BDA177','#F1ECD9'})
check('no font binaries in app',not [p for p in SRC.rglob('*') if p.suffix.lower() in {'.ttf','.otf','.woff','.woff2'}])
ui={lc:json.loads((SRC/f'lang/{lc}/ui.json').read_text()) for lc in ('en','it','es')}
check('UI locale keys equal',set(ui['en'])==set(ui['it'])==set(ui['es']))
for lc,data in ui.items():check(lc+': no empty UI strings',all(isinstance(v,str) and bool(v.strip()) for v in data.values()))
with zipfile.ZipFile(os.environ.get('LONDRA_BASELINE_ZIP', str(SRC.parent/'Londra_Development_Milestone_01_Source.zip'))) as z:
 baseline={i.filename:z.read(i.filename) for i in z.infolist() if not i.is_dir()}
 photo_count=0;photo_mismatches=[];backend_changes=[]
 frontend_prefixes=('resources/views/','resources/css/','resources/js/','lang/','docs/','reports/','tests/')
 for path in SRC.rglob('*'):
  if not path.is_file():continue
  rel=path.relative_to(SRC).as_posix();original=baseline.get('londra-development/'+rel)
  if original is None:continue
  if rel.startswith('public/assets/photos/') and path.suffix=='.png':
   photo_count+=1
   if path.read_bytes()!=original:photo_mismatches.append(rel)
  if rel.startswith(('app/','database/','routes/','config/')) and path.read_bytes()!=original and rel not in {'app/Presentation/SiteViewModel.php','app/Presentation/Html.php'}:backend_changes.append(rel)
 check('all original masters unchanged',photo_count==13 and not photo_mismatches,{'checked':photo_count,'mismatches':photo_mismatches})
 check('backend business logic unchanged',not backend_changes,backend_changes)
home=BeautifulSoup((ROOT/'en--home.html').read_text(),'html.parser')
check('full-width visual slots request full viewport images',all(img.get('sizes')=='100vw' for img in home.select('.cinema-scenes img,.fleet-photo>img,.destination-cinema>img')))
php=list(SRC.rglob('*.php'));lint_fail=[]
for path in php:
 r=subprocess.run(['php','-l',str(path)],capture_output=True,text=True)
 if r.returncode:lint_fail.append({'file':str(path),'message':r.stdout+r.stderr})
check('PHP source syntax',not lint_fail,{'files':len(php),'failures':lint_fail})
for path in (SRC/'resources/js').glob('*.js'):
 r=subprocess.run(['node','--check',str(path)],capture_output=True,text=True);check(path.name+': JavaScript syntax',r.returncode==0,r.stderr or None)
out={'test':'Static source and rendered preview audit','passed':sum(r['pass'] for r in results),'failed':sum(not r['pass'] for r in results),'checks':results}
(OUT/'static-audit.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2));print(json.dumps([x for x in results if not x['pass']],indent=2))
