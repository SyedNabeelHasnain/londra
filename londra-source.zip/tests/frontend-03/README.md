# Frontend 03 checks

Generate the preview with `php tools/render-preview.php /absolute/path/to/preview`.

Set `LONDRA_PREVIEW_DIR` to that path. Set `LONDRA_CHROMIUM` to a compatible Chromium executable where `/usr/bin/chromium` is unavailable. Python checks require Playwright, BeautifulSoup4 and Pillow. Reports are written to `reports/frontend-03/`.

Run `audit.py` with `LONDRA_BASELINE_ZIP` pointing to the original Frontend 02 source ZIP. It checks markup, links, palette, photo preservation and source syntax.

Run `browser_matrix.py START STOP` for six separate ranges: 0 16, 16 32, 32 48, 48 64, 64 80, 80 96. A complete matrix contains 576 page/viewport/theme states, not six times that many features.

Run `interactions.py en`, `interactions.py it` and `interactions.py es`. Run `form_states.py`, `contrast.py` and `resilience.py` separately.

`render.py` and `capture_review.py` produce reference screenshots. Set `LONDRA_SCREENSHOT_DIR` to a writable directory. The latter crops the fleet section from a full-page browser capture; it does not alter the CSS to hide fixed elements.

The harness inlines assets using set_content because ordinary navigation is restricted in this environment. It does not exercise HTTP routing, cookies across origins, source-set network selection, Laravel, database writes, SMTP, Filament or Hostinger.

Current counts and limitations are in `docs/FRONTEND_03_REVIEW.md`. This does not constitute a complete accessibility, security or cross-browser audit.
