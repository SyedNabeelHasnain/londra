from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from collections import Counter
from pathlib import Path
from urllib.parse import unquote, urlsplit

from bs4 import BeautifulSoup
from PIL import Image

parser = argparse.ArgumentParser()
parser.add_argument('--preview', required=True, type=Path)
parser.add_argument('--original-archive', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
preview = args.preview.resolve()
checks: list[dict[str, object]] = []


def check(name: str, passed: bool, detail: object = None) -> None:
    row: dict[str, object] = {'check': name, 'passed': bool(passed)}
    if not passed and detail is not None:
        row['detail'] = detail
    checks.append(row)


def read_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


pages = read_json(root / 'database/content/pages.json')
public = [p for p in pages if not p['approval_required']]
check('32 substantive public page records', len(public) == 32)
check('5 policy records remain unpublished', sum(p['approval_required'] for p in pages) == 5)
for locale in ('en', 'it', 'es'):
    titles = [p['translations'][locale]['seo_title'] for p in public]
    descriptions = [p['translations'][locale]['meta_description'] for p in public]
    check(f'Unique SEO titles: {locale}', len(titles) == len(set(titles)))
    check(f'Unique meta descriptions: {locale}', len(descriptions) == len(set(descriptions)))
    ui = read_json(root / f'lang/{locale}/ui.json')
    check(f'Nonempty interface dictionary: {locale}', all(isinstance(v, str) and v.strip() for v in ui.values()))

html_paths = sorted(preview.glob('*--*.html'))
check('96 separate translated HTML pages', len(html_paths) == 96)
for path in html_paths:
    html = path.read_text(encoding='utf-8')
    doc = BeautifulSoup(html, 'html.parser')
    name = path.name
    locale = name.split('--')[0]
    check(f'{name}: correct language', doc.html is not None and doc.html.get('lang') == locale)
    check(f'{name}: exactly one H1', len(doc.select('h1')) == 1)
    ids = [x['id'] for x in doc.select('[id]')]
    duplicates = [k for k, v in Counter(ids).items() if v > 1]
    check(f'{name}: unique element IDs', not duplicates, duplicates)
    check(f'{name}: noindex', 'noindex' in str(doc.select_one('meta[name="robots"]')['content']))
    canonical = doc.select_one('link[rel="canonical"]')['href']
    check(f'{name}: language-specific canonical', canonical.startswith(f'https://londratransfers.co.uk/{locale}'))
    alternatives = {x['hreflang']: x['href'] for x in doc.select('link[hreflang]')}
    check(f'{name}: reciprocal languages and x-default', set(alternatives) == {'en', 'it', 'es', 'x-default'})
    check(f'{name}: self-referencing hreflang', alternatives.get(locale) == canonical)
    broken: list[str] = []
    for tag in doc.select('[src],a[href],link[rel="stylesheet"]'):
        value = tag.get('src', tag.get('href', ''))
        parsed = urlsplit(value)
        if parsed.scheme or parsed.netloc or value.startswith('data:'):
            continue
        target = (path.parent / unquote(parsed.path)).resolve() if parsed.path else path
        if not target.exists() or not target.is_relative_to(preview):
            broken.append(value)
        if parsed.fragment and target == path and parsed.fragment not in ids:
            broken.append(value)
    for img in doc.select('img[srcset]'):
        for candidate in img['srcset'].split(','):
            local = candidate.strip().split()[0]
            if not (preview / local).exists():
                broken.append(local)
    check(f'{name}: local links and image variants resolve', not broken, sorted(set(broken)))
    check(f'{name}: image alternative attributes exist', all(x.has_attr('alt') for x in doc.select('img')))
    check(f'{name}: no missing public image dimensions', all(x.has_attr('width') and x.has_attr('height') for x in doc.select('img')))
    labels = {x.get('for') for x in doc.select('label[for]')}
    inputs = [x for x in doc.select('input,textarea,select') if x.get('type') not in {'hidden', 'submit'}]
    check(f'{name}: input labels', all(x.get('id') in labels or x.has_attr('aria-label') for x in inputs))
    broken_aria = []
    for el in doc.select('[aria-labelledby],[aria-describedby],[aria-controls]'):
        for attr in ('aria-labelledby', 'aria-describedby', 'aria-controls'):
            for target in el.get(attr, '').split():
                if target not in ids:
                    broken_aria.append(target)
    check(f'{name}: ARIA references resolve', not broken_aria, broken_aria)
    for script in doc.select('script[type="application/ld+json"],script[type="application/json"]'):
        try:
            json.loads(script.string or script.get_text())
            valid_json = True
        except (json.JSONDecodeError, TypeError):
            valid_json = False
        check(f'{name}: parseable embedded JSON', valid_json)
    check(f'{name}: enquiry submission disabled', all(x.has_attr('disabled') for x in doc.select('form[data-enquiry-form] [type="submit"]')))

source_rows = read_json(root / 'reports/source-photographs.json')
archived = read_json(root / 'reports/archived-photo-masters.json')
check('13 archived PNG masters documented', len(source_rows) == len(archived) == 13)
media_rows = read_json(root / 'database/content/media.json')
for row in source_rows:
    r = next((r for r in archived if r['original_name'] == row['file']), None)
    check(f"Archived original recorded: {row['file']}", r is not None and r['original_sha256'] == row['sha256'])
    if r is None:
        continue
    record = next((m for m in media_rows if m['key'] == r['key']), None)
    check(f"Runtime image points to included WebP: {r['key']}", record is not None and record['original'] == f"assets/photos/{r['key']}-1440.webp")
    w, h = r['original_dimensions']
    for variant in r['variants']:
        p = root / 'public/assets/photos' / variant['filename']
        check(f"WebP variant integrity: {variant['filename']}", p.exists() and hashlib.sha256(p.read_bytes()).hexdigest() == variant['sha256'])
        if p.exists():
            with Image.open(p) as image:
                check(f"WebP image validated: {variant['filename']}", image.format == 'WEBP' and image.width <= w and image.height <= h and abs(image.width / image.height - w / h) < 0.012)
if args.original_archive:
    with zipfile.ZipFile(args.original_archive) as archive:
        for row in source_rows:
            matches = [x for x in archive.namelist() if Path(x).name == row['file']]
            check(f"Original ZIP entry unique: {row['file']}", len(matches) == 1)
            if len(matches) == 1:
                check(f"Original ZIP bytes match: {row['file']}", hashlib.sha256(archive.read(matches[0])).hexdigest() == row['sha256'])

artwork = list((root / 'public/assets/artwork').glob('*.png'))
check('17 transparent artwork exports', len(artwork) == 17)
for path in artwork:
    with Image.open(path) as image:
        check(f'{path.name}: RGBA', image.mode == 'RGBA')
        if image.mode == 'RGBA':
            alpha = image.getchannel('A')
            low, high = alpha.getextrema()
            check(f'{path.name}: genuine transparency and visible artwork', low == 0 and high > 0)
            target = (189, 161, 119) if 'gold' in path.stem else ((0, 0, 0) if 'black' in path.stem else (255, 255, 255))
            valid = all(pixel[3] == 0 or pixel[:3] == target for pixel in image.get_flattened_data())
            check(f'{path.name}: exact approved foreground RGB', valid)

forbidden = [str(x.relative_to(root)) for x in root.rglob('*') if x.is_file() and (x.suffix.lower() in {'.woff', '.woff2', '.ttf', '.otf', '.eot'} or x.name == '.env')]
check('No font binaries or real .env distributed', not forbidden, forbidden)
for directory in ('app', 'database/seeders'):
    for path in (root / directory).rglob('*.php'):
        text = path.read_text()
        match = re.search(r'namespace\s+([^;]+);', text)
        if match:
            base = 'App' if directory == 'app' else r'Database\Seeders'
            expected = base + '\\' + str(path.relative_to(root / directory).parent).replace('/', '\\')
            expected = expected.rstrip('\\').removesuffix('\\.')
            check(f'{path.relative_to(root)}: PSR-4 namespace', match.group(1).strip() == expected, {'actual': match.group(1), 'expected': expected})

failures = [x for x in checks if not x['passed']]
report = {'method': 'Static HTML/content/asset integrity checks. This is not a Laravel, MySQL, SMTP or accessibility certification.', 'checks': len(checks), 'passed': len(checks) - len(failures), 'failures': failures, 'results': checks}
(root / 'reports/static-integrity.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({k: report[k] for k in ('checks', 'passed', 'failures')}, indent=2, ensure_ascii=False))
raise SystemExit(1 if failures else 0)
