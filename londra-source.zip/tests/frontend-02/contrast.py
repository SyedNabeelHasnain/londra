import json
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
from render import inline,ROOT
OUT=Path(__file__).resolve().parents[2]/'reports/frontend-02';checks=[]
def luminance(c):
 vals=[v/255 for v in c[:3]];lin=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in vals];return sum(a*b for a,b in zip(lin,[.2126,.7152,.0722]))
def ratio(a,b):
 x,y=sorted([luminance(a),luminance(b)]);return (y+.05)/(x+.05)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('LONDRA_CHROMIUM', '/usr/bin/chromium'),headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1000})
 for name in ('en--home.html','en--contact.html'):
  page.set_content(inline(ROOT/name))
  for theme in ('dark','light'):
   if page.evaluate('document.documentElement.dataset.theme')!=theme:page.locator('[data-theme-toggle]').click();page.wait_for_timeout(350)
   selectors=['.opening h1>span','.opening h1>em','.opening-title>.eyebrow','.opening-subline p','.section-heading h2','.section-intro','.service-tab[aria-selected=false]>span:nth-child(2)','.personal-copy>.eyebrow','.personal-copy h2','.fleet-panel:not([hidden]) .fleet-copy h3','.fleet-panel:not([hidden]) .fleet-copy .eyebrow','.fleet-panel:not([hidden]) .fleet-copy>p:not(.eyebrow)','.invitation p','.site-footer nav>a','.contact-story>.lede','.contact-form-wrap h2','.contact-form-wrap .form-field label','.contact-form-wrap .form-note']
   for sel in selectors:
    loc=page.locator(sel).first
    if not loc.count():continue
    data=loc.evaluate('''el=>{const cv=document.createElement('canvas');cv.width=cv.height=1;const ctx=cv.getContext('2d',{willReadFrequently:true});const color=s=>{ctx.clearRect(0,0,1,1);ctx.fillStyle=s;ctx.fillRect(0,0,1,1);return [...ctx.getImageData(0,0,1,1).data]};let current=el,bg=[0,0,0,0];while(current){const c=color(getComputedStyle(current).backgroundColor);if(c[3]>0){const a=bg[3]/255,b=c[3]/255,z=a+b*(1-a);bg=[0,1,2].map(i=>(bg[i]*a+c[i]*b*(1-a))/z).concat(z*255);if(bg[3]>=254)break}current=current.parentElement}const s=getComputedStyle(el);return {fg:color(s.color),bg,font:parseFloat(s.fontSize),weight:parseInt(s.fontWeight)||400}}''')
    if data['bg'][3]<254:continue
    value=ratio(data['fg'],data['bg']);minimum=3 if data['font']>=24 or (data['font']>=18.66 and data['weight']>=700) else 4.5
    checks.append({'page':name,'theme':theme,'selector':sel,'ratio':round(value,2),'minimum':minimum,'pass':value>=minimum})
   if name=='en--contact.html':
    pair=page.locator('.contact-form-wrap input[name=name]').evaluate('''el=>{const c=document.createElement('canvas');c.width=c.height=1;const x=c.getContext('2d');const a=s=>{x.clearRect(0,0,1,1);x.fillStyle=s;x.fillRect(0,0,1,1);return [...x.getImageData(0,0,1,1).data]};return [a(getComputedStyle(el).borderBottomColor),a(getComputedStyle(el.closest('.contact-form-wrap')).backgroundColor)]}''')
    value=ratio(*pair);checks.append({'page':name,'theme':theme,'selector':'input underline','ratio':round(value,2),'minimum':3,'pass':value>=3})
 b.close()
report={'scope':'Representative text and input underline colours on known solid surfaces. Excludes text over photographs/gradients and is not a full WCAG audit.','passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'checks':checks}
(OUT/'contrast.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2));print([x for x in checks if not x['pass']])
