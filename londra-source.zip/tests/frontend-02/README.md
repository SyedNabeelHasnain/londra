# Frontend 02 checks

These are static/presentation tests, not a running Laravel test suite. Python requires Pillow, BeautifulSoup4 and Playwright; PHP is used by the preview generator and lint checks. Chromium must be installed. There are no live submissions in these tests.

From the project root, render the static preview:

```sh
php tools/render-preview.php design-preview
```

The scripts use `design-preview/` by default. Set `LONDRA_PREVIEW_DIR` for another directory and `LONDRA_CHROMIUM` for the Chromium executable. `LONDRA_BASELINE_ZIP` must identify the original Milestone 01 source ZIP for `audit.py` to perform the preservation check; it is not silently skipped.

```sh
python tests/frontend-02/audit.py
python tests/frontend-02/browser_matrix.py 0 16
python tests/frontend-02/browser_matrix.py 16 32
python tests/frontend-02/browser_matrix.py 32 48
python tests/frontend-02/browser_matrix.py 48 64
python tests/frontend-02/browser_matrix.py 64 80
python tests/frontend-02/browser_matrix.py 80 96
python tests/frontend-02/interactions.py en
python tests/frontend-02/interactions.py it
python tests/frontend-02/interactions.py es
python tests/frontend-02/form_states.py
python tests/frontend-02/contrast.py
```

The range arguments split the 96 pages for constrained execution environments. The interaction runner waits for native dialog close events before subsequent keyboard steps. Mocked form tests replace `window.fetch` in temporary browser documents only and do not edit the delivered preview.

The image and script inlining performed by `render.py` is a test-environment accommodation, not the website's production loading strategy. It does not test real HTTP routing, caching or headers. Full running-application tests remain separate.
