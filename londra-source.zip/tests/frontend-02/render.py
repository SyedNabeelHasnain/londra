import base64,json,argparse
from pathlib import Path
import os
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
ROOT=Path(os.environ.get('LONDRA_PREVIEW_DIR', str(Path(__file__).resolve().parents[2]/'design-preview')))
CACHE={}
def inline(path):
    soup=BeautifulSoup(path.read_text(),'html.parser')
    for tag in list(soup.select('link[rel=stylesheet]')):
        style=soup.new_tag('style');style.string=(ROOT/tag['href']).read_text();tag.replace_with(style)
    for script in list(soup.select('script[src]')):
        fn=script['src'];script.string=(ROOT/fn).read_text();script.attrs.pop('src',None);script.attrs.pop('defer',None);script.attrs.pop('type',None)
        if fn.endswith('site.js'):
            script.extract();soup.body.append(script)
    for image in soup.select('img'):
        path=ROOT/image['src'];key=str(path)
        if key not in CACHE:
            mime='webp' if path.suffix=='.webp' else 'png';CACHE[key]='data:image/'+mime+';base64,'+base64.b64encode(path.read_bytes()).decode()
        image['src']=CACHE[key];image['loading']='eager';image.attrs.pop('srcset',None)
    return str(soup)
if __name__=='__main__':
    Path(os.environ.get('LONDRA_SCREENSHOT_DIR', str(Path(__file__).resolve().parents[2]/'reports/frontend-02/screenshots'))).mkdir(parents=True,exist_ok=True)
    parser=argparse.ArgumentParser();parser.add_argument('--page',default='en--home.html');parser.add_argument('--width',type=int,default=1440);parser.add_argument('--theme',default='dark');parser.add_argument('--name',default='home');parser.add_argument('--dialog');args=parser.parse_args()
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=os.environ.get('LONDRA_CHROMIUM', '/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':args.width,'height':1000 if args.width>600 else 844},device_scale_factor=1,is_mobile=args.width<600,has_touch=args.width<600)
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content(inline(ROOT/args.page),wait_until='load');page.evaluate('Promise.all(Array.from(document.images,x=>x.decode().catch(()=>null)))')
        if args.theme=='light':page.locator('[data-theme-toggle]').click()
        if args.dialog:page.locator(args.dialog).first.click()
        page.wait_for_timeout(700)
        info=page.evaluate('''()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,height:document.body.scrollHeight,missing:[...document.images].filter(x=>!x.complete||!x.naturalWidth).length,font:getComputedStyle(document.querySelector('h1')).fontFamily})''')
        print(info,errors)
        page.screenshot(path=str(Path(os.environ.get('LONDRA_SCREENSHOT_DIR', str(Path(__file__).resolve().parents[2]/'reports/frontend-02/screenshots')))/args.name)+'-full.png',full_page=not bool(args.dialog))
        page.screenshot(path=str(Path(os.environ.get('LONDRA_SCREENSHOT_DIR', str(Path(__file__).resolve().parents[2]/'reports/frontend-02/screenshots')))/args.name)+'-top.png')
        browser.close()
