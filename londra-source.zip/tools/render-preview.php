<?php
declare(strict_types=1);
require __DIR__.'/../app/Presentation/Html.php';
require __DIR__.'/../app/Presentation/SiteViewModel.php';
use App\Presentation\SiteViewModel;
$root=dirname(__DIR__);
$out=$argv[1]??($root.'/preview');
if(!is_dir($out)&&!mkdir($out,0755,true)){throw new RuntimeException('Cannot create preview directory.');}
$read=static fn(string $file)=>json_decode(file_get_contents($file),true,512,JSON_THROW_ON_ERROR);
$pages=$read($root.'/database/content/pages.json');
$vehicles=$read($root.'/database/content/vehicles.json');
$media=array_column($read($root.'/database/content/media.json'),null,'key');
$alts=$read($root.'/database/content/media-alt.json');
foreach($media as $key=>&$item){$item['alt']=$alts[$key]??['en'=>'','it'=>'','es'=>''];}unset($item);
$render=static function(array $v,string $root): string { ob_start(); require $root.'/resources/views/site.blade.php'; return (string) ob_get_clean(); };
$count=0;
foreach(['en','it','es'] as $locale){
 $ui=$read($root.'/lang/'.$locale.'/ui.json');
 foreach($pages as $page){
  if(!$page['translations'][$locale]['ready']||$page['approval_required']){continue;}
  $v=SiteViewModel::build($pages,$vehicles,$media,$ui,$locale,$page['key'],true);
  $v['css_url']='assets/site.css';$v['js_url']='assets/site.js';
  $html=$render($v,$root);
  file_put_contents($out.'/'.$locale.'--'.$page['key'].'.html',$html);$count++;
 }
}
copy($out.'/en--home.html',$out.'/index.html');
echo json_encode(['pages'=>$count,'output'=>$out],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES).PHP_EOL;
$copyTree=static function(string $source,string $destination) use (&$copyTree): void {
    if(!is_dir($destination)&&!mkdir($destination,0755,true)){throw new RuntimeException('Cannot create asset directory.');}
    foreach(new DirectoryIterator($source) as $entry){
        if($entry->isDot()||$entry->isLink()){continue;}
        $target=$destination.'/'.$entry->getFilename();
        if($entry->isDir()){$copyTree($entry->getPathname(),$target);}
        elseif(!copy($entry->getPathname(),$target)){throw new RuntimeException('Cannot copy preview asset.');}
    }
};
if(!is_dir($out.'/assets')&&!mkdir($out.'/assets',0755,true)){throw new RuntimeException('Cannot create preview asset directory.');}
copy($root.'/resources/css/site.css',$out.'/assets/site.css');
copy($root.'/resources/js/app.js',$out.'/assets/site.js');
copy($root.'/public/assets/theme.js',$out.'/assets/theme.js');
$copyTree($root.'/public/assets/artwork',$out.'/assets/artwork');
if(!is_dir($out.'/assets/photos')&&!mkdir($out.'/assets/photos',0755,true)){throw new RuntimeException('Cannot create preview photograph directory.');}
foreach(glob($root.'/public/assets/photos/*.webp') as $image){copy($image,$out.'/assets/photos/'.basename($image));}
file_put_contents($out.'/robots.txt',"User-agent: *\nDisallow: /\n");
file_put_contents($out.'/README.txt',"LONDRA TRANSFERS - BESPOKE FRONTEND 04.1 PREVIEW\n\nExtract this ZIP fully to a folder on your computer, then open index.html.\nUse the language and theme controls, expanded navigation, service image selector, four-vehicle showcase, fleet comparison, photograph viewer and enquiry drawer. Navigation leads to the corresponding language page. No scene advances automatically.\nThere are 32 substantive page designs in each of three languages, plus the default English entry.\n\nThis is a static design preview, NOT a deployable Laravel application.\nIt cannot store or submit enquiries. Submission buttons are deliberately disabled.\nIt contains no administrator simulation, real user records or credentials.\nThe five policy pages remain excluded until their business rules are approved.\nAutomatic country detection is not active. Choose a language using the menu.\nDo not replace the live website with this preview.\n\nThe main development source ZIP contains the application code, plan and test evidence.\n");
