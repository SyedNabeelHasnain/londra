#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
php -r 'if (PHP_VERSION_ID < 80504 || PHP_VERSION_ID >= 80600) { fwrite(STDERR, "Use PHP 8.5.4 or a later PHP 8.5 patch.\n"); exit(1); }'
command -v composer >/dev/null
command -v npm >/dev/null
if [ ! -f composer.lock ] || [ ! -f package-lock.json ]; then
    printf '%s\n' 'Dependency locks are not present. Resolve and review dependencies in a trusted connected build environment first.'
    exit 1
fi
composer install --prefer-dist --no-interaction
composer check-platform-reqs
composer audit
npm ci
npm audit
npm run build
php artisan filament:assets
php tests/domain-checks.php
if [ ! -f .env.testing ]; then
    printf '%s\n' 'Configure an isolated MySQL test database before running framework tests. Never use the live database.'
    exit 1
fi
php artisan config:clear
php artisan test
printf '%s\n' 'Build and framework tests completed. Production packaging, hosting checks and acceptance testing are still separate steps.'
