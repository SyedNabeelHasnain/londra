#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-${ROOT}/dist}"
command -v php >/dev/null
command -v composer >/dev/null
command -v zip >/dev/null
php -r 'if (PHP_VERSION_ID < 80504 || PHP_VERSION_ID >= 80600) { fwrite(STDERR, "PHP 8.5.4–8.5.x required\n"); exit(1); } foreach (["curl", "dom", "intl", "mbstring", "pdo_mysql", "xmlwriter"] as $ext) { if (!extension_loaded($ext)) { fwrite(STDERR, "Missing extension: $ext\n"); exit(1); } }'
cd "$ROOT"
composer validate --strict
if [[ ! -f composer.lock ]]; then
  printf 'Missing composer.lock. Resolve and audit dependencies on a connected PHP 8.5 builder first.\n' >&2
  exit 1
fi
composer install --no-dev --prefer-dist --no-interaction --optimize-autoloader
composer audit --locked
php artisan filament:assets
for target in public/build/manifest.json public/assets/theme.js vendor/autoload.php; do
  if [[ ! -f "$target" ]]; then printf 'Missing %s\n' "$target" >&2; exit 1; fi
done
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
mkdir -p "$work/londra-private" "$work/public_html" "$OUT"
cp -a app bootstrap config database lang resources routes storage vendor artisan composer.json composer.lock .env.example "$work/londra-private/"
cp -a public/. "$work/public_html/"
cat > "$work/public_html/index.php" <<'PHP'
<?php
declare(strict_types=1);
use Illuminate\Http\Request;
define('LARAVEL_START', microtime(true));
if (file_exists($maintenance = __DIR__.'/../londra-private/storage/framework/maintenance.php')) {
    require $maintenance;
}
require __DIR__.'/../londra-private/vendor/autoload.php';
$app = require_once __DIR__.'/../londra-private/bootstrap/app.php';
$app->handleRequest(Request::capture());
PHP
rm -f "$work/londra-private/.env"
find "$work/londra-private/storage" -type f ! -name '.gitignore' -delete
(cd "$work" && zip -qr "$OUT/Londra_Hostinger_Private_Public_Release.zip" londra-private public_html)
printf 'Created private/public staging release: %s\n' "$OUT/Londra_Hostinger_Private_Public_Release.zip"
printf 'This build is not a first-install wizard. A private .env, migrations, administrator creation, and live tests remain necessary.\n'
