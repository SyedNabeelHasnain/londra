import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import tailwindcss from '@tailwindcss/vite';
export default defineConfig({
    plugins: [laravel({input: ['resources/css/app.css', 'resources/css/admin.css', 'resources/js/app.js'], refresh: true}), tailwindcss()],
    build: {sourcemap: false, target: ['chrome111', 'firefox128', 'safari16.4']}
});
